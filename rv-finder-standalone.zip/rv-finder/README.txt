RV FINDER v4 - rates options relative value (GBP, EUR, USD)
============================================================

What it is
----------
A standalone web app for relative value in rates: swaption vol, options on
STIR futures, STIR futures, bond futures and swaps. 870 candidate strategies
in 34 families are scanned through history, backtested (options delta-hedged
with full revaluation unless a strategy says otherwise, futures and swaps with
carry and roll-down, costs throughout), graded with five statistical gates and
combined in a walk-forward portfolio.

The full mathematical specification (every rule, proofs of the key results,
the data-generating process, the validation protocol and references) is the
document "RV Finder v4 - Mathematical Specification of the Strategy Set".

Views
  Surface            the swaption vol surface cell by cell: vol premium, carry,
                     forward vol, richness z-scores, and the market-making
                     quote shade; drill-down per cell
  Futures & curves   SONIA (SFI) / Euribor (ER) / SOFR (SR3) strips and their
                     options (implied vs ageing-adjusted fair, same-contract
                     term structure), bond futures curves and swap spreads
  Ideas              live ideas today, formulas with today's numbers, legs,
                     P&L attribution, five gates, robust ratios, trade log
  Portfolio          walk-forward selection out of sample vs hindsight, the
                     current book, its live vega / gamma / DV01 by currency,
                     correlation of the picks, families picked over time
  Statistics         Sharpe distribution vs luck, beta to benchmark, gate
                     funnel, results by family and currency
  Method             exact mathematics, derivations and 50 references
  Data & settings    load your own data, trading rules, CSV templates, exports

Strategy families
  Swaption vol   S1 implied vs realised, S2 smile-adjusted breakeven,
                 S3 grid carry, S4 forward vol, S5 cross-ccy / tail ratios,
                 S6 implied correlation, S7 event premium, S8 vol vs curve,
                 S9 skew vs realised spot-vol correlation (SABR),
                 S10 wings vs vol-of-vol (SABR), S11 surface PCA residual,
                 S12 vol momentum,
                 S13 theta-neutral gamma calendar (breakevens across expiries),
                 S14 regime-filtered short vol (5 ex-ante filters),
                 S15 conditional curve trades, zero-cost, DV01-matched, unhedged,
                 S16 vega-neutral calendar carry (term structure of the premium)
  STIR options   O1 option vs ageing-adjusted realised, O2 same-contract
                 calendar (mid-curve vs quarterly), theta-neutral,
                 O3 STIR options vs swaption (basket vol)
  STIR futures   F1 carry & roll-down, F2 trend, F3 calendar, F4 1:2:1 fly,
                 F5 regression-weighted fly
  Bonds, swaps   B1 trend, B2 carry & roll-down, B3 curve, B4 PCA-neutral fly,
                 B5 cross-market 10y, B6 swap spread (future vs swap),
                 B7 cross-sectional carry-to-risk, B8 blended trend + carry,
                 B9 policy-cycle curve rule

How to run it
-------------
1. Unzip the whole folder. Keep the files together: index.html, run.bat and
   the assets folder.
2. Double-click run.bat. It opens index.html in Edge, or Chrome, or your
   default browser.
   If .bat files are blocked on your PC, double-click index.html instead.
   It is the same page.
3. The app starts on illustrative (synthetic) data. To use real data, open
   "Data & settings" and load your files. The template buttons give examples.

No installation, no server, no internet. Everything runs inside the browser
on your machine, and no data leaves it. A full scan takes a few seconds.

Files
-----
run.bat               launcher
index.html            the page: views and Method
assets/engine.js      swaption data, signals S1-S8, statistics
assets/ext.js         futures data, S9-S12, F1-F4, B1-B5, the general engine
                      (straddles, payers/receivers, spread options, STIR options,
                      DV01-sized and unhedged legs, futures and swaps)
assets/ext2.js        STIR options and swap data, S13-S16, O1-O3, F5, B6-B9,
                      robust ratios, walk-forward portfolio, live-book risk
assets/ui.js          charts, heatmap colours, tooltips, maths rendering
assets/app.js         views, scanning, exports
assets/style.css      styling
assets/katex/         maths typesetting (KaTeX 0.16, MIT licence), stored locally

Data formats (long CSV)
-----------------------
Surface (required):
  date,ccy,expiry,tail,fwd_pct,vol_bp,annuity,skew,curv
  2026-11-06,GBP,3M,2Y,3.8125,94.20,1.9312,0.0400,1.5e-4
  Required: date, ccy, expiry, tail, fwd_pct, vol_bp. Optional: annuity, skew,
  curv (take skew and curv from your ZABR fit at the money).
  Grid: expiries 1M 3M 6M 1Y 2Y 5Y 10Y; tails 1Y 2Y 5Y 10Y 30Y.
Events (optional): date,ccy,event - include future meeting dates.
2s10s spread-option vols (optional): date,ccy,expiry,spread_vol_bp
Futures and swaps (optional): date,ccy,type,tenor,rate_pct
  STIR = implied 3m rate (100 - price) at constant horizon 0.25..3y;
  BOND = CTD-equivalent yield of the 2/5/10/30y future;
  SWAP = OIS par swap rate for the tenor (drives B6).
STIR options (optional): date,ccy,horizon_y,expiry_y,vol_bp
  horizon_y = years to the start of the contract's reference quarter
  (0.5 .. 3); expiry_y = option expiry 0.0833, 0.25, 0.5, 0.75 or 1 (quarterly,
  serial and mid-curve options all fit); vol_bp = ATM normal vol.
At least 400 business days of history are needed; three years or more is better.

Notes
-----
- Example data are synthetic, with effects planted on purpose. Results on them
  test the code, not the strategies. Validate on your own data and costs with
  the protocol in the specification (section 14) before trading anything.
- Costs are flat by bucket; replace them with your own fills before sizing.
- Nothing here is investment advice.
- Tested in current Edge and Chrome. Internet Explorer is not supported.
