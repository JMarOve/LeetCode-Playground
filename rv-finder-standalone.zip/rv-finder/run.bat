@echo off
rem ---------------------------------------------------------------
rem  RV Finder - opens the page in a browser. No install and no
rem  internet connection are needed; everything runs locally.
rem ---------------------------------------------------------------
cd /d "%~dp0"
set "PAGE=%~dp0index.html"
if not exist "%PAGE%" (
  echo Could not find index.html next to this file.
  echo Keep run.bat inside the rv-finder folder and try again.
  pause
  exit /b 1
)
rem Prefer Microsoft Edge, then Google Chrome, then the default browser.
reg query "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe" >nul 2>&1
if %errorlevel%==0 (
  start "" msedge "%PAGE%"
  exit /b 0
)
reg query "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe" >nul 2>&1
if %errorlevel%==0 (
  start "" chrome "%PAGE%"
  exit /b 0
)
start "" "%PAGE%"
exit /b 0
