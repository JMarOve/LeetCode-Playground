# RV Finder v4 — plugging in internal desk data

This doc is for the Claude (or person) at work who has access to the desk's internal data. Its job: produce up to five CSV files in exactly the formats below, check them, and load them on the app's **Data & settings** page (rv-finder → run.bat). Nothing leaves the PC; the app is offline HTML.

Only file 1 is required. Each optional file switches on more strategy families.

| # | File | Required? | Switches on |
|---|---|---|---|
| 1 | Swaption surface history | yes | S1–S5, S8–S16 (S2, S9, S10, S13 need skew/curv) |
| 2 | Event dates | optional | S7 (event premium); improves S14 |
| 3 | 2s10s spread-option vols | optional | S6 (implied vs realised correlation) |
| 4 | STIR futures, bond futures, OIS swaps | optional | F1–F5, B1–B9, benchmark for S15 and futures ideas |
| 5 | STIR options (SFI quarterlies, serials, 0N mid-curves) | optional | O1–O3 |

## General rules for every file

- Plain CSV, comma separated, one header row, UTF-8, no thousands separators, `.` as decimal point.
- `date` = ISO `YYYY-MM-DD`, business days only, end-of-day marks. The surface file defines the calendar.
- `ccy` = `GBP`, `EUR` or `USD` (GBP alone is fine).
- History: at least 400 business days; 3+ years recommended. The first 260 days are warm-up.
- Long format: one row per date × ccy × instrument. Missing values: leave the row out.
- Rates in **percent** (`3.8125`). Vols in **normal (Bachelier) bp per year** (`94.20`). Never lognormal or shifted-lognormal vols: convert first.

## 1. Swaption surface (required)

```
date,ccy,expiry,tail,fwd_pct,vol_bp,annuity,skew,curv
2026-11-06,GBP,3M,2Y,3.8125,94.20,1.9312,0.0400,1.5e-4
```

| Column | Meaning |
|---|---|
| `expiry` | `1M 3M 6M 1Y 2Y 5Y 10Y` (all 7) |
| `tail` | `1Y 2Y 5Y 10Y 30Y` (all 5) |
| `fwd_pct` | ATM forward swap rate, % (OIS: SONIA / €STR / SOFR — be consistent) |
| `vol_bp` | ATM normal implied vol, bp/yr |
| `annuity` | forward PV01 per unit notional, years (optional) |
| `skew` | dσ_N/dK at ATM, bp vol per bp strike (typically 0.01–0.10) |
| `curv` | ½·d²σ_N/dK² at ATM, bp vol per bp² (typically 0.5e-4 to 3e-4) |

35 rows per currency per date; fill missing nodes from the cube's own interpolation.

**skew and curv from ZABR.** Don't send ZABR parameters. Evaluate the calibrated smile as normal vols at F − h, F, F + h (h = 10 bp):

```
skew = (s_plus - s_minus) / (2*h)
curv = (s_plus - 2*s_0 + s_minus) / (2*h*h)
```

Check: s_0 + skew·(±25) + curv·25² should be within ~0.3 bp of ZABR at F ± 25 bp.

## 2. Event dates (optional)

```
date,ccy,event
2026-12-18,GBP,MPC
```

Decision days and big data days. Include future scheduled dates up to a year ahead.

## 3. 2s10s spread-option vols (optional)

```
date,ccy,expiry,spread_vol_bp
2026-11-06,GBP,1Y,38.5
```

## 4. Futures and swaps (optional)

```
date,ccy,type,tenor,rate_pct
2026-11-06,GBP,STIR,0.25,3.8131
2026-11-06,GBP,BOND,10,4.4520
2026-11-06,GBP,SWAP,10,3.9810
```

- `STIR`: 100 − price at constant horizons 0.25 … 3.0 years (12 points). For each date compute h = (start of reference quarter − date)/365.25 for every listed contract and interpolate linearly onto the grid.
- `BOND`: CTD-equivalent yield of the front future, tenors 2, 5, 10, 30 (GBP: 2, 5, 10). Keep rolls consistent.
- `SWAP`: OIS par swap rate at the same tenors.

## 5. STIR options (optional; SFI and 0N)

```
date,ccy,horizon_y,expiry_y,vol_bp
2026-11-06,GBP,1.0,0.25,96.4
```

- `horizon_y`: years to the start of the contract's reference quarter, grid 0.5 … 3.0 (snaps within 0.06).
- `expiry_y`: 0.0833, 0.25, 0.5, 0.75 or 1.0 (snaps within 0.06). Only rows with expiry ≤ horizon.
- `vol_bp`: ATM normal vol (invert from settlement prices if needed). Interpolate bilinearly from listed series onto the grid; use series with real open interest.

## Settings on the Data page

Replace default costs with the desk's half bid-offers by bucket; run at cost multiplier 1, 2 and 3. Set vega and DV01 per unit. Leave entry/exit at 1.5 / 0.25 / 20 days until the frozen-spec test is done (spec §14).

## Checks before loading

1. No duplicate keys; 35 surface rows per ccy per date.
2. Ranges: `fwd_pct` −1 to 10; `vol_bp` 10 to 300; |`skew`| < 0.3; `curv` 0 to 1e-3.
3. No lognormal vols.
4. Flag day-on-day moves > 15 bp vol or > 40 bp rate.
5. STIR strip smooth in horizon, no steps at rolls.
6. Same calendar across files; events include future dates.
7. After loading, the status line reads "Your data: … futures, swaps, STIR options"; the scan reports 852 candidates without events and spread vols, 870 with everything.

## What not to do

- Don't mix normal and lognormal vols, or OIS and IBOR forwards.
- Don't change rules after seeing real results without counting it as a new trial.
- Nothing here is investment advice; validate with spec §14 before trading.
