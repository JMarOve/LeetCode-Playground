# RV Finder v4 — overview

Offline HTML app for relative value in GBP, EUR and USD rates. 870 candidates in 34 families, each backtested with full revaluation and costs, graded with five gates, and combined in a walk-forward portfolio.

- Thesis specification: https://claude.ai/artifact/Ax9FTw5foA8azNrzHn7W6N (export to Word or PDF from the doc)
- Data inputs: see `rv-finder-internal-data-integration.md`

## Families
- Swaption vol S1–S16: implied vs realised, smile breakeven, grid carry, forward vol, ratio pairs, correlation, events, curve residual, skew, wings, surface PCA, vol momentum, theta-neutral gamma calendar, regime-filtered short vol, zero-cost conditional curve trades, vega-neutral calendar carry.
- STIR options O1–O3: option vs ageing-adjusted realised, same-contract calendar (mid-curve vs quarterly), STIR options vs swaption basket vol.
- STIR futures F1–F5: carry, trend, calendar, 1:2:1 fly, regression-weighted fly.
- Bonds and swaps B1–B9: trend, carry, curve, PCA fly, cross-market, swap spread, carry-to-risk rank, blended trend + carry, policy-cycle curve rule.

## Key results
- Skew-adjusted breakeven: σ_BE = σ / sqrt((1 − x√τ·σ_F)² + 2cστ), σ_F = β − s − 2cm. At the money the slope drops out; off the money it does not.
- Theta-neutral calendar carry has the sign of (realised/implied)²_front − (realised/implied)²_back.
- Conditional trades: expected payoff depends only on the marginal vols; correlation enters only the variance.
- Synthetic data: walk-forward out-of-sample Sharpe 1.80 vs hindsight 4.40; luck Sharpe 1.44 for 870 trials.

## Gates
1. Predictive: rank IC of z vs 5/10/20-day P&L > 0.05.
2. Significant: Newey–West t > 2 (deflated Sharpe shown).
3. Not benchmark beta: alpha t > 2 vs short 3m2y straddle (vol) or long 10y future (futures).
4. Robust: positive at 2× costs; best year ≤ 60% of P&L.
5. Tail-sized: worst 20-day loss < 6 months of average P&L.

## Next candidates from the research library
Consensus rich/cheap screen (Lehman 2005), option triangles, cap/floor vs swaption wedge, skew as a duration positioning signal (BofA 2014), clustered-PCA z-scores (BofA 2019), long-dated conditional vega slide (Nomura), straddle P&L decomposition (SocGen 2022).
