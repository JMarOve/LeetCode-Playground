// UI toolkit for RV Finder: DOM helpers, maths rendering, colour scales,
// tooltips and SVG charts (line, bar, histogram, scatter, sparkline, smile).
(function (W) {
  "use strict";
  var fmt = W.RVF.fmt;
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var esc = function (s) { return String(s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); };

  // ---------------------------------------------------------------- maths
  function tex(src, display) {
    try { return W.katex ? katex.renderToString(src, { displayMode: !!display, throwOnError: false }) : esc(src); } catch (e) { return esc(src); }
  }
  function renderMath(root) {
    $$(".texd", root).forEach(function (el) { if (!el.dataset.done) { el.innerHTML = tex(el.textContent, true); el.dataset.done = 1; } });
    var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null), nodes = [], n;
    while ((n = walker.nextNode())) if (n.nodeValue.indexOf("\\(") >= 0 && !(n.parentNode.closest && n.parentNode.closest(".katex,script,textarea"))) nodes.push(n);
    nodes.forEach(function (node) {
      var parts = node.nodeValue.split(/\\\((.+?)\\\)/), frag = document.createDocumentFragment();
      parts.forEach(function (p, i) {
        if (i % 2 === 0) { if (p) frag.appendChild(document.createTextNode(p)); }
        else { var s = document.createElement("span"); s.innerHTML = tex(p, false); frag.appendChild(s); }
      });
      node.parentNode.replaceChild(frag, node);
    });
  }

  // ---------------------------------------------------------------- colour
  function lerp(a, b, t) { return Math.round(a + (b - a) * t); }
  function mix(c1, c2, t) { return "rgb(" + lerp(c1[0], c2[0], t) + "," + lerp(c1[1], c2[1], t) + "," + lerp(c1[2], c2[2], t) + ")"; }
  var RICH = [196, 64, 22], CHEAP = [24, 100, 171], MID = [246, 247, 250], SEQ0 = [238, 242, 255], SEQ1 = [22, 36, 92];
  function lum(c) { var m = c.match(/\d+/g).map(Number); return (0.299 * m[0] + 0.587 * m[1] + 0.114 * m[2]) / 255; }
  function divColor(v, lim) { // v > 0 rich (warm), v < 0 cheap (cool)
    if (!isFinite(v)) return { bg: "var(--sunk)", fg: "var(--muted)" };
    var t = Math.max(-1, Math.min(1, v / (lim || 1))), bg = t >= 0 ? mix(MID, RICH, Math.pow(t, 0.8)) : mix(MID, CHEAP, Math.pow(-t, 0.8));
    return { bg: bg, fg: lum(bg) < 0.55 ? "#fff" : "#16181D" };
  }
  function seqColor(v, lo, hi) {
    if (!isFinite(v)) return { bg: "var(--sunk)", fg: "var(--muted)" };
    var t = Math.max(0, Math.min(1, (v - lo) / Math.max(hi - lo, 1e-9))), bg = mix(SEQ0, SEQ1, 0.08 + 0.85 * t);
    return { bg: bg, fg: lum(bg) < 0.55 ? "#fff" : "#16181D" };
  }
  var GOOD = [7, 148, 85], BAD = [217, 45, 32];
  function pnlColor(v, lim) {
    if (!isFinite(v)) return { bg: "var(--sunk)", fg: "var(--muted)" };
    var t = Math.max(-1, Math.min(1, v / (lim || 1))), bg = t >= 0 ? mix(MID, GOOD, 0.15 + 0.75 * t) : mix(MID, BAD, 0.15 + 0.75 * -t);
    return { bg: bg, fg: lum(bg) < 0.55 ? "#fff" : "#16181D" };
  }
  var FAMCOL = { S1: "#2F5BEA", S2: "#7A5AF8", S3: "#0E9384", S4: "#DC6803", S5x: "#C11574", S5t: "#E04F16", S6: "#15B79E", S7: "#6172F3", S8: "#667085",
    S9: "#9E77ED", S10: "#D444F1", S11: "#4E5BA6", S12: "#B54708", S13: "#3538CD", S14: "#BA24D5", S15: "#F79009", S16: "#1D2939",
    O1: "#DD2590", O2: "#9B1C59", O3: "#F670C7",
    F1: "#039855", F2: "#027A48", F3: "#3CCB7F", F4: "#05603A", F5: "#73E2A3",
    B1: "#0086C9", B2: "#026AA2", B3: "#36BFFA", B4: "#065986", B5: "#7CD4FD", B6: "#0BA5EC", B7: "#155B75", B8: "#2E90FA", B9: "#53B1FD" };
  var CCYCOL = { GBP: "#7F56D9", EUR: "#1570EF", USD: "#079455" };

  // ---------------------------------------------------------------- tooltip
  var tip;
  function showTip(html, x, y) {
    if (!tip) { tip = document.createElement("div"); tip.className = "tip"; document.body.appendChild(tip); }
    tip.innerHTML = html; tip.style.display = "block";
    var w = tip.offsetWidth, h = tip.offsetHeight, vx = W.innerWidth;
    tip.style.left = Math.min(x + 14, vx - w - 8) + "px"; tip.style.top = Math.max(8, y - h - 12) + "px";
  }
  function hideTip() { if (tip) tip.style.display = "none"; }

  // ---------------------------------------------------------------- scales
  function ticks(lo, hi, k) {
    if (!(hi > lo)) hi = lo + 1;
    var span = hi - lo, step = Math.pow(10, Math.floor(Math.log10(span / k))), err = span / k / step;
    if (err >= 7.5) step *= 10; else if (err >= 3.5) step *= 5; else if (err >= 1.5) step *= 2;
    var t = []; for (var v = Math.ceil(lo / step) * step; v <= hi + step * 1e-9; v += step) t.push(Math.abs(v) < step * 1e-9 ? 0 : v);
    return t;
  }
  function tickLabel(t) { var a = Math.abs(t); return a >= 1000 ? fmt(t, 0) : a >= 10 || t === 0 || t % 1 === 0 ? fmt(t, 0) : a >= 1 ? fmt(t, 1) : fmt(t, 2); }
  var CHARTS = {}, cid = 0;

  // line chart with optional area, hover crosshair and a vertical marker
  function line(o) {
    var id = "c" + (++cid), Wd = o.w || 760, H = o.h || 240, ml = 56, mr = 14, mt = 22, mb = 28;
    var xs = o.x, ys = [];
    o.series.forEach(function (s) { s.y.forEach(function (v) { if (isFinite(v)) ys.push(v); }); });
    (o.hlines || []).forEach(function (h) { ys.push(h.y); });
    if (o.zero) ys.push(0);
    if (!ys.length) ys = [0, 1];
    var xmin = o.xmin != null ? o.xmin : xs[0], xmax = o.xmax != null ? o.xmax : xs[xs.length - 1];
    var ymin = Math.min.apply(null, ys), ymax = Math.max.apply(null, ys), pad = (ymax - ymin) * 0.08 || Math.abs(ymax) * 0.1 || 1;
    ymin -= pad; ymax += pad;
    var X = function (v) { return ml + (v - xmin) / (xmax - xmin || 1) * (Wd - ml - mr); }, Y = function (v) { return mt + (ymax - v) / (ymax - ymin) * (H - mt - mb); };
    var s = '<svg class="chart" id="' + id + '" viewBox="0 0 ' + Wd + " " + H + '" role="img" aria-label="' + esc(o.label || "chart") + '">';
    s += "<defs>" + o.series.map(function (sr, k) { return sr.area ? '<linearGradient id="' + id + "g" + k + '" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="' + sr.color + '" stop-opacity=".22"/><stop offset="1" stop-color="' + sr.color + '" stop-opacity="0"/></linearGradient>' : ""; }).join("") + "</defs>";
    ticks(ymin, ymax, 5).forEach(function (t) { s += '<line class="gr" x1="' + ml + '" x2="' + (Wd - mr) + '" y1="' + Y(t) + '" y2="' + Y(t) + '"/><text class="yt" x="' + (ml - 8) + '" y="' + (Y(t) + 4) + '" text-anchor="end">' + (o.yf ? o.yf(t) : tickLabel(t)) + "</text>"; });
    ticks(xmin, xmax, o.xticks || 6).forEach(function (t) { if (t >= xmin && t <= xmax) s += '<text class="xt" x="' + X(t) + '" y="' + (H - 8) + '" text-anchor="middle">' + (o.xf ? o.xf(t) : tickLabel(t)) + "</text>"; });
    if (ymin < 0 && ymax > 0) s += '<line class="zero" x1="' + ml + '" x2="' + (Wd - mr) + '" y1="' + Y(0) + '" y2="' + Y(0) + '"/>';
    (o.hlines || []).forEach(function (h) { s += '<line x1="' + ml + '" x2="' + (Wd - mr) + '" y1="' + Y(h.y) + '" y2="' + Y(h.y) + '" stroke="' + (h.color || "#98A2B3") + '" stroke-dasharray="4 4" stroke-width="1"/>' + (h.label ? '<text class="yt" x="' + (Wd - mr - 4) + '" y="' + (Y(h.y) - 4) + '" text-anchor="end">' + esc(h.label) + "</text>" : ""); });
    o.series.forEach(function (sr, k) {
      var d = "", pen = false, first = null, lastX = null;
      sr.y.forEach(function (v, i) { if (!isFinite(v)) { pen = false; return; } var px = X(xs[i]).toFixed(1), py = Y(v).toFixed(1); d += (pen ? "L" : "M") + px + " " + py; if (first === null) first = px; lastX = px; pen = true; });
      if (sr.area && first !== null) { var base = Y(Math.max(ymin, Math.min(ymax, 0))).toFixed(1); s += '<path d="' + d + "L" + lastX + " " + base + "L" + first + " " + base + 'Z" fill="url(#' + id + "g" + k + ')"/>'; }
      s += '<path d="' + d + '" fill="none" stroke="' + sr.color + '" stroke-width="' + (sr.width || 1.8) + '"' + (sr.dash ? ' stroke-dasharray="' + sr.dash + '"' : "") + ' stroke-linejoin="round"/>';
    });
    if (o.marker != null) s += '<line x1="' + X(o.marker) + '" x2="' + X(o.marker) + '" y1="' + mt + '" y2="' + (H - mb) + '" stroke="#F79009" stroke-width="1.5"/>';
    if (o.yl) s += '<text class="lab" x="' + ml + '" y="13">' + esc(o.yl) + "</text>";
    s += '<line class="cross" x1="0" x2="0" y1="' + mt + '" y2="' + (H - mb) + '" style="display:none"/><rect class="hit" x="' + ml + '" y="' + mt + '" width="' + (Wd - ml - mr) + '" height="' + (H - mt - mb) + '" fill="transparent"/>';
    s += "</svg>";
    CHARTS[id] = { o: o, X: X, ml: ml, mr: mr, W: Wd, xmin: xmin, xmax: xmax };
    return s;
  }
  function legend(items) { return '<div class="legend">' + items.map(function (i) { return '<span><i style="background:' + i[1] + (i[2] ? ";height:0;border-top:2px dashed " + i[1] + ";background:none" : "") + '"></i>' + esc(i[0]) + "</span>"; }).join("") + "</div>"; }

  document.addEventListener("mousemove", function (e) {
    var svg = e.target.closest && e.target.closest("svg.chart");
    if (!svg || !CHARTS[svg.id]) { if (!e.target.closest || !e.target.closest("[data-tip]")) hideTip(); return; }
    var C = CHARTS[svg.id], o = C.o, r = svg.getBoundingClientRect(), sx = (e.clientX - r.left) * C.W / r.width;
    var xv = C.xmin + (sx - C.ml) / (C.W - C.ml - C.mr) * (C.xmax - C.xmin), xs = o.x, best = 0, bd = Infinity;
    for (var i = 0; i < xs.length; i++) { var dd = Math.abs(xs[i] - xv); if (dd < bd) { bd = dd; best = i; } }
    var cross = svg.querySelector(".cross"); cross.setAttribute("x1", C.X(xs[best])); cross.setAttribute("x2", C.X(xs[best])); cross.style.display = "";
    var h = "<b>" + esc(o.xf ? o.xf(xs[best], true) : xs[best]) + "</b>" + o.series.filter(function (s) { return s.name; }).map(function (s) { return '<div><i style="background:' + s.color + '"></i>' + esc(s.name) + ": <b>" + (o.tf ? o.tf(s.y[best]) : fmt(s.y[best], 2)) + "</b></div>"; }).join("");
    showTip(h, e.clientX, e.clientY);
  });
  document.addEventListener("mouseout", function (e) {
    var svg = e.target.closest && e.target.closest("svg.chart"); if (svg && !svg.contains(e.relatedTarget)) { var c = svg.querySelector(".cross"); if (c) c.style.display = "none"; hideTip(); }
  });
  document.addEventListener("mouseover", function (e) {
    var t = e.target.closest && e.target.closest("[data-tip]"); if (t) { var r = t.getBoundingClientRect(); showTip(t.getAttribute("data-tip"), r.left + r.width / 2, r.top); }
  });
  document.addEventListener("mouseleave", hideTip);

  // grouped bar chart: cats, series [{name, y:[...], color}]
  function bars(o) {
    var Wd = o.w || 760, H = o.h || 230, ml = 56, mr = 14, mt = 22, mb = 34, ys = [0];
    o.series.forEach(function (s) { s.y.forEach(function (v) { if (isFinite(v)) ys.push(v); }); });
    var ymin = Math.min.apply(null, ys), ymax = Math.max.apply(null, ys), pad = (ymax - ymin) * 0.1 || 1; if (ymin < 0) ymin -= pad; ymax += pad;
    var Y = function (v) { return mt + (ymax - v) / (ymax - ymin) * (H - mt - mb); }, n = o.cats.length, gw = (Wd - ml - mr) / n, k = o.series.length, bw = Math.min(46, gw * 0.72 / k);
    var s = '<svg class="chart bars" viewBox="0 0 ' + Wd + " " + H + '" role="img" aria-label="' + esc(o.label || "bars") + '">';
    ticks(ymin, ymax, 5).forEach(function (t) { s += '<line class="gr" x1="' + ml + '" x2="' + (Wd - mr) + '" y1="' + Y(t) + '" y2="' + Y(t) + '"/><text class="yt" x="' + (ml - 8) + '" y="' + (Y(t) + 4) + '" text-anchor="end">' + (o.yf ? o.yf(t) : tickLabel(t)) + "</text>"; });
    s += '<line class="zero" x1="' + ml + '" x2="' + (Wd - mr) + '" y1="' + Y(0) + '" y2="' + Y(0) + '"/>';
    o.cats.forEach(function (c, i) {
      var cx = ml + gw * (i + 0.5);
      o.series.forEach(function (sr, j) {
        var v = sr.y[i]; if (!isFinite(v)) return;
        var x0 = cx - k * bw / 2 + j * bw, y0 = Y(Math.max(v, 0)), y1 = Y(Math.min(v, 0)), col = typeof sr.color === "function" ? sr.color(v, i) : sr.color;
        s += '<rect x="' + (x0 + 1).toFixed(1) + '" y="' + y0.toFixed(1) + '" width="' + (bw - 2).toFixed(1) + '" height="' + Math.max(0.8, y1 - y0).toFixed(1) + '" rx="3" fill="' + col + '" data-tip="' + esc("<b>" + esc(c) + "</b><div>" + esc(sr.name || "") + " " + (o.tf ? o.tf(v) : fmt(v, 2)) + "</div>") + '"/>';
        if (o.labels) s += '<text class="lab" x="' + (x0 + bw / 2).toFixed(1) + '" y="' + (v >= 0 ? y0 - 5 : y1 + 13).toFixed(1) + '" text-anchor="middle">' + (o.tf ? o.tf(v) : fmt(v, 1)) + "</text>";
      });
      s += '<text class="xt" x="' + cx + '" y="' + (H - 12) + '" text-anchor="middle">' + esc(c) + "</text>";
    });
    if (o.yl) s += '<text class="lab" x="' + ml + '" y="13">' + esc(o.yl) + "</text>";
    return s + "</svg>";
  }

  // histogram with optional density overlay and vertical lines
  function histogram(o) {
    var Wd = o.w || 760, H = o.h || 240, ml = 48, mr = 14, mt = 22, mb = 30, v = o.values.filter(isFinite);
    var lo = o.lo != null ? o.lo : Math.min.apply(null, v), hi = o.hi != null ? o.hi : Math.max.apply(null, v), nb = o.bins || 30, bw = (hi - lo) / nb, cnt = new Array(nb).fill(0);
    v.forEach(function (x) { var b = Math.min(nb - 1, Math.max(0, Math.floor((x - lo) / bw))); cnt[b]++; });
    var dens = o.density ? cnt.map(function (_, i) { return o.density(lo + (i + 0.5) * bw) * v.length * bw; }) : [];
    var ymax = Math.max.apply(null, cnt.concat(dens)) * 1.1 || 1;
    var X = function (x) { return ml + (x - lo) / (hi - lo) * (Wd - ml - mr); }, Y = function (c) { return mt + (1 - c / ymax) * (H - mt - mb); };
    var s = '<svg class="chart" viewBox="0 0 ' + Wd + " " + H + '" role="img" aria-label="' + esc(o.label || "histogram") + '">';
    ticks(0, ymax, 4).forEach(function (t) { s += '<line class="gr" x1="' + ml + '" x2="' + (Wd - mr) + '" y1="' + Y(t) + '" y2="' + Y(t) + '"/><text class="yt" x="' + (ml - 8) + '" y="' + (Y(t) + 4) + '" text-anchor="end">' + tickLabel(t) + "</text>"; });
    ticks(lo, hi, 8).forEach(function (t) { s += '<text class="xt" x="' + X(t) + '" y="' + (H - 9) + '" text-anchor="middle">' + tickLabel(t) + "</text>"; });
    cnt.forEach(function (c, i) { var x0 = lo + i * bw; s += '<rect x="' + (X(x0) + 0.5).toFixed(1) + '" y="' + Y(c).toFixed(1) + '" width="' + Math.max(0.5, X(x0 + bw) - X(x0) - 1).toFixed(1) + '" height="' + (Y(0) - Y(c)).toFixed(1) + '" rx="2" fill="' + (o.color ? o.color(x0 + bw / 2) : "#2F5BEA") + '" data-tip="' + esc(fmt(x0, 2) + " to " + fmt(x0 + bw, 2) + ": <b>" + c + "</b>") + '"/>'; });
    if (dens.length) s += '<path d="' + dens.map(function (d, i) { return (i ? "L" : "M") + X(lo + (i + 0.5) * bw).toFixed(1) + " " + Y(d).toFixed(1); }).join("") + '" fill="none" stroke="#101828" stroke-width="1.5" stroke-dasharray="5 4"/>';
    (o.vlines || []).forEach(function (l) { s += '<line x1="' + X(l.x) + '" x2="' + X(l.x) + '" y1="' + mt + '" y2="' + (H - mb) + '" stroke="' + l.color + '" stroke-width="2"/><text class="lab" x="' + (X(l.x) + 5) + '" y="' + (mt + 10) + '" fill="' + l.color + '">' + esc(l.label) + "</text>"; });
    if (o.xl) s += '<text class="lab" x="' + (Wd - mr) + '" y="13" text-anchor="end">' + esc(o.xl) + "</text>";
    return s + "</svg>";
  }

  // scatter: points [{x,y,color,id,tip}]
  function scatter(o) {
    var Wd = o.w || 760, H = o.h || 300, ml = 52, mr = 16, mt = 22, mb = 34, p = o.points.filter(function (q) { return isFinite(q.x) && isFinite(q.y); });
    var xs = p.map(function (q) { return q.x; }), ys = p.map(function (q) { return q.y; });
    var xlo = Math.min.apply(null, xs.concat([0])), xhi = Math.max.apply(null, xs.concat([0])), ylo = Math.min.apply(null, ys.concat([0])), yhi = Math.max.apply(null, ys.concat([0]));
    var px = (xhi - xlo) * 0.06 || 1, py = (yhi - ylo) * 0.08 || 1; xlo -= px; xhi += px; ylo -= py; yhi += py;
    var X = function (v) { return ml + (v - xlo) / (xhi - xlo) * (Wd - ml - mr); }, Y = function (v) { return mt + (yhi - v) / (yhi - ylo) * (H - mt - mb); };
    var s = '<svg class="chart" viewBox="0 0 ' + Wd + " " + H + '" role="img" aria-label="' + esc(o.label || "scatter") + '">';
    ticks(ylo, yhi, 5).forEach(function (t) { s += '<line class="gr" x1="' + ml + '" x2="' + (Wd - mr) + '" y1="' + Y(t) + '" y2="' + Y(t) + '"/><text class="yt" x="' + (ml - 8) + '" y="' + (Y(t) + 4) + '" text-anchor="end">' + tickLabel(t) + "</text>"; });
    ticks(xlo, xhi, 7).forEach(function (t) { s += '<line class="gr" x1="' + X(t) + '" x2="' + X(t) + '" y1="' + mt + '" y2="' + (H - mb) + '"/><text class="xt" x="' + X(t) + '" y="' + (H - 12) + '" text-anchor="middle">' + tickLabel(t) + "</text>"; });
    s += '<line class="zero" x1="' + ml + '" x2="' + (Wd - mr) + '" y1="' + Y(0) + '" y2="' + Y(0) + '"/><line class="zero" x1="' + X(0) + '" x2="' + X(0) + '" y1="' + mt + '" y2="' + (H - mb) + '"/>';
    (o.hlines || []).forEach(function (h) { s += '<line x1="' + ml + '" x2="' + (Wd - mr) + '" y1="' + Y(h.y) + '" y2="' + Y(h.y) + '" stroke="' + h.color + '" stroke-dasharray="5 4" stroke-width="1.5"/><text class="lab" x="' + (Wd - mr - 4) + '" y="' + (Y(h.y) - 5) + '" text-anchor="end" fill="' + h.color + '">' + esc(h.label) + "</text>"; });
    p.forEach(function (q) { s += '<circle class="pt" cx="' + X(q.x).toFixed(1) + '" cy="' + Y(q.y).toFixed(1) + '" r="' + (q.r || 4) + '" fill="' + q.color + '" fill-opacity=".75" stroke="#fff" stroke-width="1"' + (q.id ? ' data-idea="' + esc(q.id) + '"' : "") + ' data-tip="' + esc(q.tip || "") + '"/>'; });
    if (o.xl) s += '<text class="lab" x="' + (Wd - mr) + '" y="13" text-anchor="end">' + esc("→ " + o.xl) + "</text>";
    if (o.yl) s += '<text class="lab" x="' + ml + '" y="13">' + esc("↑ " + o.yl) + "</text>";
    return s + "</svg>";
  }

  function spark(y, color) {
    var v = y.filter(isFinite); if (v.length < 2) return "";
    var lo = Math.min.apply(null, v.concat([0])), hi = Math.max.apply(null, v.concat([0])), Wd = 96, H = 26, n = y.length;
    var X = function (i) { return 1 + i / (n - 1) * (Wd - 2); }, Y = function (x) { return 2 + (hi - x) / (hi - lo || 1) * (H - 4); };
    var d = y.map(function (x, i) { return (i ? "L" : "M") + X(i).toFixed(1) + " " + Y(x).toFixed(1); }).join("");
    return '<svg class="spark" viewBox="0 0 ' + Wd + " " + H + '" width="' + Wd + '" height="' + H + '"><line x1="0" x2="' + Wd + '" y1="' + Y(0) + '" y2="' + Y(0) + '" stroke="#D0D5DD" stroke-width="1"/><path d="' + d + '" fill="none" stroke="' + (color || (v[v.length - 1] >= 0 ? "#079455" : "#D92D20")) + '" stroke-width="1.5"/></svg>';
  }

  W.UI = { $: $, $$: $$, esc: esc, tex: tex, renderMath: renderMath, divColor: divColor, seqColor: seqColor, pnlColor: pnlColor, FAMCOL: FAMCOL, CCYCOL: CCYCOL,
    line: line, legend: legend, bars: bars, histogram: histogram, scatter: scatter, spark: spark, showTip: showTip, hideTip: hideTip };
})(window);
