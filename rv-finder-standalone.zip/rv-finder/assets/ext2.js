// RV Finder, module 3 (v4):
//  - STIR option vol surface (options on SONIA / Euribor / SOFR futures) and swap curves
//  - strategy families S13-S16 (swaption vol), O1-O3 (STIR options), F5 (STIR), B6-B9 (bonds and swaps)
//  - robust (non-parametric) performance ratios, walk-forward portfolio, live-book risk, leg descriptions
// Every formula is written out on the Method page and in the specification document; section
// references in comments (§) match the Method page.
(function (W) {
  "use strict";
  var R = W.RVF, X = W.RVX, fmt = R.fmt, IX = R.IX, ET = R.ET, EXPN = R.EXPN, TAILS = R.TAILS, NE = R.NE, NT = R.NT, nn = R.nodeName;
  var HS = X.HS, NS = HS.length, OT = X.OT, NO = OT.length, DT = 1 / 252, lin = X.lin, stir = X.stir, bond = X.bond, nanArr = X.nanArr, cache = X.cache, hLbl = X.hLbl;
  var FAM3 = {
    S13: ["Theta-neutral gamma calendar", "vol"], S14: ["Regime-filtered short vol", "vol"], S15: ["Conditional curve (zero-cost)", "vol"], S16: ["Vega-neutral calendar carry", "vol"],
    O1: ["STIR option vs ageing-adjusted realised", "sopt"], O2: ["STIR option same-contract calendar", "sopt"], O3: ["STIR options vs swaption basis", "sopt"],
    F5: ["Regression-weighted STIR butterfly", "stir"],
    B6: ["Swap spread (bond future vs swap)", "bond"], B7: ["Cross-sectional carry-to-risk", "bond"], B8: ["Blended duration timing", "bond"], B9: ["Policy-cycle curve rule", "bond"]
  };
  Object.keys(FAM3).forEach(function (k) { X.FAMX[k] = FAM3[k]; });
  var CODE = { GBP: "SFI", EUR: "ER", USD: "SR3" };

  // ================================================================ data (illustrative)
  // instantaneous normal vol of a fixed STIR contract h years from its reference start, per unit factor vol (§9)
  function uStrip(h, ev) {
    var ld = R.loadings(h + 0.125), l = ld[0] * (ev ? 2.6 : 1), s = ld[1] * (ev ? 1.8 : 1);
    return Math.sqrt(l * l + 0.2025 * s * s + 2 * 0.45 * 0.3025 * l * s);
  }
  function ouPath(r, n, hl, sd, mu) { var k = Math.log(2) / (hl / 252), sg = sd * Math.sqrt(2 * k), x = new Float64Array(n); x[0] = mu || 0; for (var i = 1; i < n; i++) x[i] = x[i - 1] - k * (x[i - 1] - (mu || 0)) * DT + sg * Math.sqrt(DT) * r.normal(); return x; }
  // expected log-vol level along the option's life: lv mean-reverts at 3 a year towards 0.18, the same
  // long-run level the swaption surface uses (§9); no log-normal convexity term, as for swaptions
  var MLV = 0.18, VLV = 0;
  function genSopt(md, seed) {
    md.so = {};
    md.ccys.forEach(function (c, ci) {
      if (!md.fac || !md.fac[c] || !md.stir || !md.stir[c]) return;
      var r = R.rng((seed || 27) * 131 + 17 * ci + 5), Lv = R.LEVELS[c], lv = md.fac[c].lv, n = md.n, evx = md.evx[c];
      var u0 = R.loadings(1.125), kS = (Lv.grid[3][0] / 1.12 / Math.sqrt(1.151)) / Math.sqrt(u0[0] * u0[0] + 0.2025 * u0[1] * u0[1]);
      var vrp = ouPath(r, n, 60, 0.03, 0.06), z1 = ouPath(r, n, 40, 1), z2 = ouPath(r, n, 25, 0.05), z3 = ouPath(r, n, 50, 0.04);
      var a = new Float64Array(n * NS * NO), noise = new Float64Array(NS * NO), cum = new Int32Array(evx.length + 1);
      for (var i0 = 0; i0 < evx.length; i0++) cum[i0 + 1] = cum[i0] + (evx[i0] ? 1 : 0);
      var rich = function (H) { // planted contract richness (what O1 should find)
        if (c === "GBP") return Math.exp(-Math.pow((H - 1.25) / 0.4, 2));
        if (c === "USD") return -0.6 * Math.exp(-Math.pow((H - 2.5) / 0.5, 2));
        return 0.3 * Math.exp(-Math.pow((H - 0.75) / 0.3, 2));
      };
      var m = 8, P = []; // ageing path of each (contract, expiry) cell: decay weights, factor and fly variances
      for (var k0 = 0; k0 < NS; k0++) for (var j0 = 0; j0 < NO; j0++) {
        var cell = { e3: [], e6: [], u2: [], f2: 0, hm: Math.max(HS[k0] - OT[j0] / 2, 0.02) };
        for (var q0 = 0; q0 < m; q0++) { var u = (q0 + 0.5) * OT[j0] / m, h = Math.max(HS[k0] - u, 0.02); cell.e3.push(Math.exp(-3 * u)); cell.e6.push(VLV * (1 - Math.exp(-6 * u))); cell.u2.push(kS * kS * Math.pow(uStrip(h, false), 2)); cell.f2 += Math.pow(13.65 * Math.exp(-Math.pow((h - 1.5) / 0.35, 2)), 2) / m; }
        cell.dU = kS * kS * (Math.pow(uStrip(cell.hm, true), 2) - Math.pow(uStrip(cell.hm, false), 2)); cell.e15 = Math.exp(-1.5 * OT[j0]); P.push(cell);
      }
      for (var d = 0; d < n; d++) for (var k = 0; k < NS; k++) for (var j = 0; j < NO; j++) {
        var H = HS[k], tau = OT[j], v = 0, nEv = 0, hEnd = Math.round(tau * 252), pc = P[k * NO + j], lq = lv[d] - MLV;
        for (var q = 0; q < m; q++) { var mb = Math.exp(2 * (MLV + lq * pc.e3[q]) + 2 * pc.e6[q]); v += mb * pc.u2[q]; }
        v = v / m + pc.f2;
        nEv = cum[Math.min(evx.length, d + hEnd + 1)] - cum[d + 1];
        if (nEv) { var mm = Math.exp(MLV + lq * pc.e15); v += nEv * mm * mm * pc.dU * DT / tau; }
        var x = k * NO + j; noise[x] = 0.92 * noise[x] + 0.45 * r.normal();
        a[(d * NS + k) * NO + j] = Math.max(5, Math.sqrt(v) * (1 + vrp[d]) * (1 + 0.05 * rich(H) * (1 + z1[d])) * (1 + 2 * z2[d] * (0.5 - tau)) * (1 + z3[d]) + noise[x]);
      }
      md.so[c] = a; md.soFac = md.soFac || {}; md.soFac[c] = { vrp: vrp, z1: z1, z2: z2, z3: z3 };
    });
    md.hasSO = Object.keys(md.so).length > 0;
    return md;
  }
  function genSwap(md, seed) {
    md.swap = {};
    var base = { USD: { 2: -18, 5: -30, 10: -42, 30: -78 }, EUR: { 2: 25, 5: 18, 10: 8, 30: -5 }, GBP: { 2: 4, 5: -8, 10: -22, 30: -45 } };
    md.ccys.forEach(function (c, ci) {
      if (!md.bond || !md.bond[c]) return;
      var r = R.rng((seed || 27) * 977 + 13 * ci + 1), b = md.bt[c], nb = b.length, n = md.n, common = ouPath(r, n, 120, 6), sw = new Float64Array(n * nb);
      var own = b.map(function () { return ouPath(r, n, 45, 4); });
      for (var d = 0; d < n; d++) for (var k = 0; k < nb; k++) sw[d * nb + k] = md.bond[c][d * nb + k] + (base[c] ? base[c][b[k]] : 0) + common[d] + own[k][d];
      md.swap[c] = sw;
    });
    return md;
  }
  function soFromCSV(md, txt) { // date, ccy, horizon_y, expiry_y, vol_bp  ->  md.so on the (HS x OT) grid
    var lines = String(txt).replace(/\r/g, "").split("\n").filter(function (l) { return l.trim(); });
    var head = lines.shift().split(",").map(function (h) { return h.trim().toLowerCase(); }), di = {}, near = function (arr, v) { var b = -1, e = 1e9; arr.forEach(function (x, i) { if (Math.abs(x - v) < e) { e = Math.abs(x - v); b = i; } }); return e < 0.06 ? b : -1; };
    md.dates.forEach(function (d, i) { di[d] = i; });
    md.so = {};
    lines.forEach(function (l) {
      var p = l.split(","), o = {}; head.forEach(function (h, i) { o[h] = (p[i] || "").trim(); });
      var c = String(o.ccy).toUpperCase(), d = di[o.date], k = near(HS, parseFloat(o.horizon_y || o.horizon)), j = near(OT, parseFloat(o.expiry_y || o.expiry)), v = parseFloat(o.vol_bp || o.vol);
      if (d === undefined || k < 0 || j < 0 || !isFinite(v)) return;
      (md.so[c] = md.so[c] || nanArr(md.n * NS * NO))[(d * NS + k) * NO + j] = v;
    });
    Object.keys(md.so).forEach(function (c) { // forward-fill in time, then fill gaps along expiry
      var a = md.so[c];
      for (var x = 0; x < NS * NO; x++) { var last = NaN; for (var d = 0; d < md.n; d++) { var y = d * NS * NO + x; if (a[y] === a[y]) last = a[y]; else a[y] = last; } }
      for (var d2 = 0; d2 < md.n; d2++) for (var k2 = 0; k2 < NS; k2++) for (var j2 = 1; j2 < NO; j2++) { var y2 = (d2 * NS + k2) * NO + j2; if (a[y2] !== a[y2]) a[y2] = a[y2 - 1]; }
      if (!(a[0] === a[0])) delete md.so[c];
    });
    md.hasSO = Object.keys(md.so).length > 0;
    return md;
  }

  // ================================================================ shared measures
  function stripHar(md, c) { // HAR forecast of realised vol of a fixed contract at each strip horizon (§4d)
    return cache(md, "sh" + c, function () {
      var o = []; for (var k = 0; k < NS; k++) { var a = X.rvSeries(md, "S", c, k, 5), b = X.rvSeries(md, "S", c, k, 22), g = X.rvSeries(md, "S", c, k, 66), f = new Float64Array(md.n); for (var d = 0; d < md.n; d++) f[d] = Math.sqrt(0.3 * a[d] * a[d] + 0.4 * b[d] * b[d] + 0.3 * g[d] * g[d]); o.push(f); }
      return o;
    });
  }
  var KV = Math.log(2) / 0.5; // mean reversion of variance forecasts: half-life six months
  function stripLR(md, c) { return cache(md, "sl" + c, function () { var o = []; for (var k = 0; k < NS; k++) o.push(X.rvSeries(md, "S", c, k, 252)); return o; }); }
  function soFair(md, c, d, H, tau) { // ageing-adjusted fair vol: sqrt( (1/tau) * integral_0^tau v_d(H-u, u) du ),
    // v_d(h, u) = vLR(h) + (vHAR(h) - vLR(h)) exp(-KV u): HAR variance decaying to the one-year realised variance
    var f = stripHar(md, c), g = stripLR(md, c), ys = f.map(function (s) { return s[d]; }), yl = g.map(function (s) { return s[d]; }), m = 8, v = 0;
    for (var k = 0; k < m; k++) {
      var u = (k + 0.5) * tau / m, h = Math.max(H - u, HS[0]), a = lin(HS, ys, h), b = lin(HS, yl, h);
      v += (b === b ? b * b + (a * a - b * b) * Math.exp(-KV * u) : a * a);
    }
    return Math.sqrt(v / m);
  }
  function soRichZ(md, c, H, tau) { // z-score of ln(implied / fair) against its own trailing year
    return cache(md, "srz" + c + H + "_" + tau, function () { var g = nanArr(md.n); for (var d = 0; d < md.n; d++) g[d] = Math.log(soIV(md, c, d, H, tau) / soFair(md, c, d, H, tau)); return z252(g); });
  }
  function soIV(md, c, d, H, tau) { return X.soVol(md, c, d, H, tau); }
  function z252(x) { var r = R.roll(x, 252, 60), o = nanArr(x.length); for (var i = 0; i < x.length; i++) if (r.s[i] > 0) o[i] = (x[i] - r.m[i]) / r.s[i]; return o; }
  function carryRoll(md, c, d, T) { // quarterly carry + roll-down of a bond future, in yield bp (§4c, B2)
    var y = bond(md, c, d, T); return (y - X.repo(md, c, d)) * 0.25 / X.dur(y, T) + (y - bond(md, c, d, T - 0.25));
  }
  function crRatio(md, c, k, T) { // carry-to-risk: quarterly carry+roll over quarterly realised vol
    return cache(md, "cr" + c + T, function () { var rv = X.rvSeries(md, "B", c, k, 66), g = nanArr(md.n); for (var d = 0; d < md.n; d++) if (rv[d] > 0) g[d] = carryRoll(md, c, d, T) / (rv[d] * 0.5); return g; });
  }
  function bachelier(F, K, s, tau, kind) { return X.optPrice(F, K, s, tau, kind).p; }
  function smileVol(md, c, d, e, t, off) { var x = IX(d, e, t); return Math.max(1, md.V[c][x] + (md.S[c] ? md.S[c][x] : 0) * off + (md.C[c] ? md.C[c][x] : 0) * off * off); }
  function zeroCostOff(md, c, d, e, tS, tL, kind) { // strike offset of the short-tail option making the DV01-matched package costless
    var FL = md.F[c][IX(d, e, tL)], FS = md.F[c][IX(d, e, tS)], E = ET[e], target = bachelier(FL, FL, smileVol(md, c, d, e, tL, 0), E, kind);
    var f = function (off) { return bachelier(FS, FS + off, smileVol(md, c, d, e, tS, off), E, kind) - target; };
    if (!isFinite(target)) return NaN;
    var x = 0, fx = f(x); for (var it = 0; it < 12 && Math.abs(fx) > 1e-7; it++) { var dx = 0.01, df = (f(x + dx) - fx) / dx; if (!(Math.abs(df) > 1e-9)) break; var nx = Math.max(-400, Math.min(400, x - fx / df)); x = nx; fx = f(x); }
    if (Math.abs(fx) <= 1e-6) return x;
    var lo = -400, hi = 400, flo = f(lo), fhi = f(hi); if (!(flo * fhi < 0)) return NaN;
    for (var i = 0; i < 60; i++) { var mid = 0.5 * (lo + hi), fm = f(mid); if (fm * flo > 0) { lo = mid; flo = fm; } else hi = mid; }
    return 0.5 * (lo + hi);
  }
  function regW3(dx, w, ks, n, Wn) { // rolling OLS of belly changes on the two wings -> weights [-b1, 1, -b2] (minimum-variance fly)
    var out = []; for (var d = 0; d < n; d++) out.push(null);
    for (d = Wn; d < n; d++) {
      if ((d - Wn) % 5 !== 0 && out[d - 1]) { out[d] = out[d - 1]; continue; }
      var S = [0, 0, 0, 0, 0, 0, 0, 0, 0], mu = [0, 0, 0], k = 0, i, a, b;
      for (i = d - Wn + 1; i <= d; i++) { var r = [dx[i * w + ks[0]], dx[i * w + ks[2]], dx[i * w + ks[1]]]; if (!r.every(isFinite)) continue; k++; for (a = 0; a < 3; a++) { mu[a] += r[a]; for (b = 0; b < 3; b++) S[a * 3 + b] += r[a] * r[b]; } }
      if (k < 120) continue;
      var cv = function (a, b) { return (S[a * 3 + b] - mu[a] * mu[b] / k) / (k - 1); }, s11 = cv(0, 0), s12 = cv(0, 1), s22 = cv(1, 1), y1 = cv(0, 2), y2 = cv(1, 2), det = s11 * s22 - s12 * s12;
      if (!(det > 1e-12)) continue;
      out[d] = [-(s22 * y1 - s12 * y2) / det, 1, -(s11 * y2 - s12 * y1) / det];
    }
    return out;
  }
  function pcaW3(dx, w, ks, n, Wn) { // rolling PCA of three columns of daily changes -> weights [w1, 1, w3] neutral to PC1 and PC2
    var out = []; for (var d = 0; d < n; d++) out.push(null);
    for (d = Wn; d < n; d++) {
      if ((d - Wn) % 5 !== 0 && out[d - 1]) { out[d] = out[d - 1]; continue; }
      var mu = [0, 0, 0], M = [];
      for (var i = d - Wn + 1; i <= d; i++) { var row = ks.map(function (k) { return dx[i * w + k]; }); if (row.some(function (v) { return !isFinite(v); })) continue; M.push(row); mu[0] += row[0]; mu[1] += row[1]; mu[2] += row[2]; }
      if (M.length < 120) continue; mu = mu.map(function (v) { return v / M.length; });
      var C = new Float64Array(9); M.forEach(function (row) { for (var a = 0; a < 3; a++) for (var b = 0; b < 3; b++) C[a * 3 + b] += (row[a] - mu[a]) * (row[b] - mu[b]) / (M.length - 1); });
      var E = X.jacobi(Array.prototype.slice.call(C), 3), p1 = E.vec[0], p2 = E.vec[1], det = p1[0] * p2[2] - p1[2] * p2[0];
      if (Math.abs(det) < 1e-9) continue;
      out[d] = [(-p1[1] * p2[2] + p1[2] * p2[1]) / det, 1, (-p1[0] * p2[1] + p1[1] * p2[0]) / det];
    }
    return out;
  }

  // ================================================================ candidates
  function cand(o, bm) { X.cand(o); if (bm) o.bm = bm; return o; }
  function optLeg(c, e, t, w, extra) { var L = { c: c, E: ET[e], t: t, w: w, kind: "straddle", off: 0 }; if (extra) for (var k in extra) L[k] = extra[k]; return L; }
  function soLeg(c, H, tau, w) { return { c: c, prod: "so", H: H, E: tau, w: w, kind: "straddle", off: 0 }; }
  function futLeg(c, inst, x, w) { return { c: c, kind: "fut", inst: inst, x: x, w: w }; }
  var bName = function (c, T) { return (X.BNAME[c] && X.BNAME[c][T]) || c + " " + T + "y"; };
  var soName = function (c, H, tau) { return CODE[c] + " " + hLbl(H) + " contract, " + hLbl(tau) + " option"; };

  function candidates3(md) {
    var C = [], push = function (o, bm) { C.push(cand(o, bm)); };
    md.ccys.forEach(function (c) {
      var hasVol = md.V && md.V[c];
      if (hasVol) {
        // ---- S13 theta-neutral gamma calendar (same tail, two expiries)
        var be = function (d, e, t) { var x = IX(d, e, t), v = md.V[c][x]; return md.hasSmile && md.C[c] ? v / Math.sqrt(Math.max(0.2, 1 + 2 * md.C[c][x] * v * ET[e])) : v; };
        [[0, 1], [1, 2], [1, 3], [2, 3], [3, 4]].forEach(function (p) { for (var t = 0; t < NT; t++) (function (e1, e2, t) {
          var w2 = function (d) { var s1 = md.V[c][IX(d, e1, t)], s2 = md.V[c][IX(d, e2, t)]; return -(s1 / ET[e1]) / (s2 / ET[e2]); };
          push({ id: "S13." + c + EXPN[e1] + EXPN[e2] + TAILS[t], fam: "S13", ccy: c, cells: [[e1, t], [e2, t]], name: c + " " + EXPN[e1] + " vs " + EXPN[e2] + " on the " + TAILS[t] + "y tail, theta-neutral",
            longTxt: "buy " + nn(e1, t) + " straddle, sell " + nn(e2, t) + " straddle, theta-neutral (long front gamma)", shortTxt: "sell " + nn(e1, t) + " straddle, buy " + nn(e2, t) + " straddle, theta-neutral (short front gamma)",
            compute: function () { var f1 = R.forecast(md, c, e1, t), f2 = R.forecast(md, c, e2, t), g = nanArr(md.n); for (var d = 0; d < md.n; d++) g[d] = Math.log(be(d, e2, t) / f2[d]) - Math.log(be(d, e1, t) / f1[d]); return R.scoreFrom(g, "z"); },
            legs: function (d) { return [optLeg(c, e1, t, 1), optLeg(c, e2, t, w2(d))]; },
            why: function (d) { var b1 = be(d, e1, t), b2 = be(d, e2, t), f1 = R.forecast(md, c, e1, t)[d], f2 = R.forecast(md, c, e2, t)[d]; return "Breakevens " + fmt(b1, 1) + "bp (" + EXPN[e1] + ") and " + fmt(b2, 1) + "bp (" + EXPN[e2] + ") against forecast realised " + fmt(f1, 1) + " and " + fmt(f2, 1) + "bp: richness " + fmt(b1 / f1, 2) + "× vs " + fmt(b2 / f2, 2) + "×. Theta-neutral ratio " + fmt(-w2(d), 2) + " units of " + EXPN[e2] + " vega per unit of " + EXPN[e1] + " vega."; } });
        })(p[0], p[1], t); });

        // ---- S14 regime-filtered short vol (ex-ante on/off filters)
        [[0, 1], [0, 3], [0, 4], [1, 1], [1, 3], [1, 4]].forEach(function (q) { (function (e, t) {
          var fl = function () { return cache(md, "f14" + c + e + t, function () {
            var iv = R.series(md, md.V, c, e, t), rv22 = R.realised(md, c, e, t, 22), rv21 = R.realised(md, c, 0, t, 21), zl = z252(iv), F = [];
            for (var d = 0; d < md.n; d++) {
              if (d < 21 || !(rv22[d] > 0) || !(zl[d] === zl[d]) || !(rv21[d] > 0)) { F.push(null); continue; }
              var spill = md.ccys.every(function (c2) { var a = md.V[c2][IX(d, e, t)], b = md.V[c2][IX(d - 5, e, t)]; return a / b < 1.10; });
              F.push([iv[d] / rv22[d] > 1.2, zl[d] > 0.5, md.V[c][IX(d, 0, t)] - md.V[c][IX(d, 1, t)] > 0, md.V[c][IX(d - 21, 0, t)] > rv21[d], spill]);
            }
            return F; }); };
          var NM = ["vol carry > 1.2×", "level z > 0.5", "1m above 3m", "last month's short paid", "no spillover"];
          push({ id: "S14." + c + nn(e, t), fam: "S14", ccy: c, node: [e, t], name: c + " " + nn(e, t) + " short straddle, regime filters",
            longTxt: "buy " + c + " " + nn(e, t) + " straddle", shortTxt: "sell " + c + " " + nn(e, t) + " straddle (filters on)",
            compute: function () { var F = fl(), g = nanArr(md.n); for (var d = 0; d < md.n; d++) if (F[d]) g[d] = -3 * F[d].filter(Boolean).length / 5; return R.scoreFrom(g, "raw"); },
            legs: function () { return [optLeg(c, e, t, 1)]; },
            why: function (d) { var F = fl()[d]; return F ? "Filters on: " + F.map(function (b, i) { return (b ? "✓ " : "✗ ") + NM[i]; }).join(" · ") + ". Score −3 × (filters on)/5." : ""; } });
        })(q[0], q[1]); });

        // ---- S15 conditional curve trades (zero-cost, DV01-matched, unhedged)
        var lam = 1; // drift assumption: forwards roll to spot (lambda = 1) ... martingale (lambda = 0)
        [1, 2, 3].forEach(function (e) { [[1, 3], [2, 4]].forEach(function (pr) { ["payer", "receiver"].forEach(function (kind) { (function (e, tS, tL, kind) {
          var key = "s15" + c + e + tS + tL + kind, offs = function () { return cache(md, key, function () { var o = nanArr(md.n); for (var d = 0; d < md.n; d++) o[d] = zeroCostOff(md, c, d, e, tS, tL, kind); return o; }); };
          var sprd = TAILS[tS] + "s" + TAILS[tL] + "s", bear = kind === "payer";
          var ep = function (d) {
            var off = offs()[d], E = ET[e], FS = md.F[c][IX(d, e, tS)], FL = md.F[c][IX(d, e, tL)];
            var muS = lam * (md.F[c][IX(d, 0, tS)] - FS), muL = lam * (md.F[c][IX(d, 0, tL)] - FL), fS = R.forecast(md, c, e, tS)[d], fL = R.forecast(md, c, e, tL)[d];
            return bachelier(FS + muS, FS + off, fS, E, kind) - bachelier(FL + muL, FL, fL, E, kind);
          };
          push({ id: "S15." + c + EXPN[e] + sprd + (bear ? "P" : "R"), fam: "S15", ccy: c, cells: [[e, tS], [e, tL]], name: c + " " + EXPN[e] + " " + sprd + " conditional " + (bear ? "bear flattener (payers)" : "bull steepener (receivers)"),
            longTxt: "buy " + nn(e, tS) + " " + kind + " at the zero-cost strike, sell " + nn(e, tL) + " ATMF " + kind + ", DV01-matched (" + (bear ? "bear flattener" : "bull steepener") + ")",
            shortTxt: "sell " + nn(e, tS) + " " + kind + ", buy " + nn(e, tL) + " ATMF " + kind + ", DV01-matched (" + (bear ? "bear steepener" : "bull flattener") + ")",
            compute: function () { var g = nanArr(md.n); for (var d = 0; d < md.n; d++) g[d] = ep(d); return R.scoreFrom(g, "level"); },
            legs: function (d) { var off = offs()[d]; return [optLeg(c, e, tS, 1, { kind: kind, off: isFinite(off) ? off : 0, size: "dv01", hedge: false }), optLeg(c, e, tL, -1, { kind: kind, off: 0, size: "dv01", hedge: false })]; },
            why: function (d) { var off = offs()[d], FS = md.F[c][IX(d, e, tS)], FL = md.F[c][IX(d, e, tL)]; return "Zero-cost strike on the " + TAILS[tS] + "y leg: " + fmt((FS + off) / 100, 3) + "% (forward " + fmt(FS / 100, 3) + "%, moneyness " + fmt(-off, 1) + "bp). Entry spread " + fmt(FL - FS - off, 1) + "bp vs forward spread " + fmt(FL - FS, 1) + "bp. Expected payoff per DV01 under forecast realised vols and roll to spot: " + fmt(ep(d), 2) + "bp."; } }, "dur");
        })(e, pr[0], pr[1], kind); }); }); });

        // ---- S16 vega-neutral calendar carry (term structure of the vol premium)
        var carryE = function (d, e, t) { var x = IX(d, e, t), v = md.V[c][x], f = R.forecast(md, c, e, t)[d], roll = e >= 1 ? (v - md.V[c][IX(d, e - 1, t)]) / (ET[e] - ET[e - 1]) : 0; return (f * f - v * v) / (2 * v * ET[e]) - roll; };
        [[0, 1], [1, 3], [2, 4]].forEach(function (p) { [1, 3, 4].forEach(function (t) { (function (e1, e2, t) {
          push({ id: "S16." + c + EXPN[e1] + EXPN[e2] + TAILS[t], fam: "S16", ccy: c, cells: [[e1, t], [e2, t]], name: c + " " + EXPN[e2] + " vs " + EXPN[e1] + " on the " + TAILS[t] + "y tail, vega-neutral",
            longTxt: "buy " + nn(e2, t) + " straddle, sell " + nn(e1, t) + " straddle, vega-neutral (short front gamma)", shortTxt: "sell " + nn(e2, t) + " straddle, buy " + nn(e1, t) + " straddle, vega-neutral",
            compute: function () { var g = nanArr(md.n); for (var d = 0; d < md.n; d++) g[d] = carryE(d, e2, t) - carryE(d, e1, t); return R.scoreFrom(g, "level"); },
            legs: function () { return [optLeg(c, e2, t, 1), optLeg(c, e1, t, -1)]; },
            why: function (d) { return "Expected carry per unit of vega (gamma minus theta at forecast realised, plus roll-down): " + EXPN[e2] + " " + fmt(carryE(d, e2, t), 2) + ", " + EXPN[e1] + " " + fmt(carryE(d, e1, t), 2) + " vol bp a year."; } });
        })(p[0], p[1], t); }); });
      }

      // ---- STIR options
      if (md.so && md.so[c] && md.stir && md.stir[c]) {
        [[0.5, [0.25, 0.5]], [1, [0.25, 0.5, 1]], [1.5, [0.25, 0.5, 1]], [2, [0.25, 0.5, 1]]].forEach(function (q) { q[1].forEach(function (tau) { (function (H, tau) {
          push({ id: "O1." + c + hLbl(H) + "." + hLbl(tau), fam: "O1", ccy: c, so: [H, tau], name: soName(c, H, tau) + " straddle vs ageing-adjusted realised",
            longTxt: "buy " + soName(c, H, tau) + " straddle, delta-hedged with the future", shortTxt: "sell " + soName(c, H, tau) + " straddle, delta-hedged with the future",
            compute: function () { var g = nanArr(md.n); for (var d = 0; d < md.n; d++) g[d] = soFair(md, c, d, H, tau) - soIV(md, c, d, H, tau); return R.scoreFrom(g, "level"); },
            legs: function () { return [soLeg(c, H, tau, 1)]; },
            why: function (d) { return "Implied " + fmt(soIV(md, c, d, H, tau), 1) + "bp. Realised vol forecast along the contract's ageing path, from " + hLbl(H) + " down to " + hLbl(Math.max(H - tau, 0)) + " before its reference period: " + fmt(soFair(md, c, d, H, tau), 1) + "bp."; } }, "vol");
        })(q[0], tau); }); });
        [[0.5, 0.25, 0.5], [1, 0.25, 0.5], [1, 0.25, 1], [1, 0.5, 1], [1.5, 0.25, 0.5], [1.5, 0.25, 1], [1.5, 0.5, 1], [2, 0.25, 0.5], [2, 0.25, 1], [2, 0.5, 1]].forEach(function (q) { (function (H, t1, t2) {
          var rich = function (d, tau) { return Math.log(soIV(md, c, d, H, tau) / soFair(md, c, d, H, tau)); };
          var w2 = function (d) { return -(soIV(md, c, d, H, t1) / t1) / (soIV(md, c, d, H, t2) / t2); };
          push({ id: "O2." + c + hLbl(H) + "." + hLbl(t1) + hLbl(t2), fam: "O2", ccy: c, so: [H, t1, t2], name: CODE[c] + " " + hLbl(H) + " contract: " + hLbl(t1) + " vs " + hLbl(t2) + " options, theta-neutral",
            longTxt: "buy " + hLbl(t1) + " straddle, sell " + hLbl(t2) + " straddle on the same " + CODE[c] + " " + hLbl(H) + " contract, theta-neutral", shortTxt: "sell " + hLbl(t1) + " straddle, buy " + hLbl(t2) + " straddle on the same contract, theta-neutral",
            compute: function () { var g = nanArr(md.n); for (var d = 0; d < md.n; d++) g[d] = rich(d, t2) - rich(d, t1); return R.scoreFrom(g, "z"); },
            legs: function (d) { return [soLeg(c, H, t1, 1), soLeg(c, H, t2, w2(d))]; },
            why: function (d) { return "Same underlying contract. " + hLbl(t1) + " option " + fmt(soIV(md, c, d, H, t1), 1) + "bp vs fair " + fmt(soFair(md, c, d, H, t1), 1) + "bp; " + hLbl(t2) + " option " + fmt(soIV(md, c, d, H, t2), 1) + "bp vs fair " + fmt(soFair(md, c, d, H, t2), 1) + "bp. Theta-neutral ratio " + fmt(-w2(d), 2) + "."; } }, "vol");
        })(q[0], q[1], q[2]); });
        if (md.V && md.V[c]) [1, 2, 3].forEach(function (e) { (function (e) {
          var E = ET[e], Hs = [0, 1, 2, 3].map(function (i) { return E + 0.25 * i; }), ks = Hs.map(function (h) { return HS.indexOf(h); });
          if (ks.some(function (k) { return k < 0; })) return;
          var rho = function () { return cache(md, "o3r" + c + e, function () { var dx = X.dStir(md, c), cols = ks.map(function (k) { var a = new Float64Array(md.n); for (var d = 0; d < md.n; d++) a[d] = dx[d * NS + k]; return a; }), M = {}; for (var i = 0; i < 4; i++) for (var j = i + 1; j < 4; j++) M[i + "" + j] = R.rollCorr(cols[i], cols[j], 66); return M; }); };
          var basket = function (d) {
            var s = Hs.map(function (h) { return soIV(md, c, d, h, E); }), M = rho(), r = function (i, j) { return i === j ? 1 : M[Math.min(i, j) + "" + Math.max(i, j)][d]; }, v = 0, gr = [0, 0, 0, 0];
            for (var i = 0; i < 4; i++) for (var j = 0; j < 4; j++) { v += r(i, j) * s[i] * s[j] / 16; gr[i] += r(i, j) * s[j] / 16; }
            var sb = Math.sqrt(v); return { sb: sb, w: gr.map(function (x) { return -x / sb; }), s: s };
          };
          push({ id: "O3." + c + EXPN[e] + "1y", fam: "O3", ccy: c, cells: [[e, 0]], name: c + " " + nn(e, 0) + " swaption vs the " + CODE[c] + " strip options (basket vol)",
            longTxt: "buy " + nn(e, 0) + " swaption straddle, sell the four " + CODE[c] + " straddles on the underlying strip, vega-weighted", shortTxt: "sell " + nn(e, 0) + " swaption straddle, buy the four strip straddles, vega-weighted",
            compute: function () { var g = nanArr(md.n); for (var d = 0; d < md.n; d++) { var b = basket(d); g[d] = b.sb - md.V[c][IX(d, e, 0)]; } return R.scoreFrom(g, "z"); },
            legs: function (d) { var b = basket(d); return [optLeg(c, e, 0, 1)].concat(Hs.map(function (h, i) { return soLeg(c, h, E, isFinite(b.w[i]) ? b.w[i] : -0.25); })); },
            why: function (d) { var b = basket(d); return "Swaption " + fmt(md.V[c][IX(d, e, 0)], 1) + "bp vs strip-implied basket vol " + fmt(b.sb, 1) + "bp (contract vols " + b.s.map(function (x) { return fmt(x, 0); }).join(", ") + "bp, realised correlations, equal weights)."; } }, "vol");
        })(e); });
      }

      // ---- F5 PCA-neutral STIR butterfly
      if (md.stir && md.stir[c]) [1, 1.5, 2].forEach(function (h) { (function (h) {
        var tens = [h - 0.5, h, h + 0.5], ks = tens.map(function (x) { return HS.indexOf(x); }); if (ks.some(function (k) { return k < 0; })) return;
        var Wt = function () { return cache(md, "f5w" + c + h, function () { return regW3(X.dStir(md, c), NS, ks, md.n, 252); }); };
        var lvl = function (d) { var w = Wt()[d]; return w ? w[0] * stir(md, c, d, tens[0]) + stir(md, c, d, h) + w[2] * stir(md, c, d, tens[2]) : NaN; };
        push({ id: "F5." + c + hLbl(h), fam: "F5", ccy: c, name: X.SNAME[c] + " " + hLbl(tens[0]) + "/" + hLbl(h) + "/" + hLbl(tens[2]) + " regression-weighted fly",
          longTxt: "buy the " + hLbl(h) + " contract (receive), sell the wings in regression weights", shortTxt: "sell the " + hLbl(h) + " contract, buy the wings in regression weights",
          compute: function () { var g = nanArr(md.n); for (var d = 0; d < md.n; d++) g[d] = lvl(d); return R.scoreFrom(g, "z"); },
          legs: function (d) { var w = Wt()[d] || [-0.5, 1, -0.5]; return [futLeg(c, "stir", tens[0], w[0]), futLeg(c, "stir", h, 1), futLeg(c, "stir", tens[2], w[2])]; },
          why: function (d) { var w = Wt()[d]; return w ? "Weights from a trailing-year regression of the belly's daily changes on the wings': " + fmt(w[0], 2) + " : 1 : " + fmt(w[2], 2) + " (minimum-variance hedge). Fly " + fmt(lvl(d), 1) + "bp." : ""; } });
      })(h); });

      // ---- bonds and swaps
      if (md.bond && md.bond[c]) {
        var b = md.bt[c];
        if (md.swap && md.swap[c]) b.forEach(function (T) { (function (T) {
          var ss = function (d) { return X.swapR(md, c, d, T) - bond(md, c, d, T); };
          push({ id: "B6." + c + T, fam: "B6", ccy: c, name: c + " " + T + "y swap spread (" + bName(c, T) + " vs " + T + "y swap)",
            longTxt: "buy " + bName(c, T) + ", pay " + T + "y swap, DV01-matched (spread widener)", shortTxt: "sell " + bName(c, T) + ", receive " + T + "y swap, DV01-matched (spread tightener)",
            compute: function () { var g = nanArr(md.n); for (var d = 0; d < md.n; d++) g[d] = -ss(d); return R.scoreFrom(g, "z"); },
            legs: function () { return [futLeg(c, "bond", T, 1), futLeg(c, "swap", T, -1)]; },
            why: function (d) { var y = bond(md, c, d, T); return "Swap " + fmt(X.swapR(md, c, d, T) / 100, 3) + "% vs bond " + fmt(y / 100, 3) + "%: spread " + fmt(ss(d), 1) + "bp. Carry of the widener " + fmt((y - X.swapR(md, c, d, T)) * 0.25 / X.dur(y, T), 2) + "bp a quarter."; } });
        })(T); });
        // B8 blended duration timing
        b.forEach(function (T, k) { (function (T, k) {
          var comp = function () { return cache(md, "b8" + c + T, function () {
            var y = new Float64Array(md.n), rv = X.rvSeries(md, "B", c, k, 66), cr = crRatio(md, c, k, T), H = [21, 63, 126, 252], g = nanArr(md.n), parts = [];
            for (var d = 0; d < md.n; d++) y[d] = bond(md, c, d, T);
            var ma = H.map(function (h) { return R.roll(y, h, h).m; });
            for (d = 0; d < md.n; d++) { if (!(rv[d] > 0)) { parts.push(null); continue; } var p = H.map(function (h, i) { return (ma[i][d] - y[d]) / (rv[d] * Math.sqrt(h / 252)); }); p.push(cr[d]); if (p.every(isFinite)) { parts.push(p); g[d] = p.reduce(function (a, x) { return a + x; }, 0) / 5; } else parts.push(null); }
            return { g: g, parts: parts }; }); };
          push({ id: "B8." + c + T, fam: "B8", ccy: c, name: bName(c, T) + " blended trend and carry",
            longTxt: "buy " + bName(c, T) + " (long duration)", shortTxt: "sell " + bName(c, T) + " (short duration)",
            compute: function () { return R.scoreFrom(comp().g, "level"); },
            legs: function () { return [futLeg(c, "bond", T, 1)]; },
            why: function (d) { var p = comp().parts[d]; return p ? "Trend vs 1, 3, 6, 12-month averages (risk units): " + p.slice(0, 4).map(function (x) { return fmt(x, 2); }).join(", ") + "; carry-to-risk " + fmt(p[4], 2) + "." : ""; } });
        })(T, k); });
        // B9 policy-cycle curve rule
        [[2, 10], [5, 30]].filter(function (p) { return b.indexOf(p[0]) >= 0 && b.indexOf(p[1]) >= 0; }).forEach(function (p) { (function (T1, T2) {
          var TH = 15, mom = function (d) { return md.stir && md.stir[c] && d >= 63 ? stir(md, c, d, 0.5) - stir(md, c, d - 63, 0.5) : NaN; };
          var carry = function (d) { return carryRoll(md, c, d, T1) - carryRoll(md, c, d, T2); };
          push({ id: "B9." + c + T1 + "s" + T2 + "s", fam: "B9", ccy: c, name: c + " " + T1 + "s" + T2 + "s policy-cycle rule",
            longTxt: "buy " + bName(c, T1) + ", sell " + bName(c, T2) + " DV01-matched (steepener)", shortTxt: "sell " + bName(c, T1) + ", buy " + bName(c, T2) + " DV01-matched (flattener)",
            compute: function () { var g = nanArr(md.n); for (var d = 0; d < md.n; d++) { var m = mom(d), cy = carry(d); if (!isFinite(m) || !isFinite(cy)) continue; g[d] = Math.abs(m) >= TH ? Math.max(-3, Math.min(3, -m / TH)) : 1.6 * (cy > 0 ? 1 : -1); } return R.scoreFrom(g, "raw"); },
            legs: function () { return [futLeg(c, "bond", T1, 1), futLeg(c, "bond", T2, -1)]; },
            why: function (d) { var m = mom(d); return "6m-ahead " + CODE[c] + " rate moved " + fmt(m, 1) + "bp in 3 months (" + (m >= TH ? "tightening: flattener" : m <= -TH ? "easing: steepener" : "on hold: trade the carry") + "). Steepener carry " + fmt(carry(d), 2) + "bp a quarter."; } });
        })(p[0], p[1]); });
        // B7 within-currency carry-to-risk (long best, short worst)
        if (b.length >= 3) push({ id: "B7." + c, fam: "B7", ccy: c, name: c + " curve: best vs worst carry-to-risk future",
          longTxt: "buy the highest carry-to-risk future, sell the lowest, DV01-matched", shortTxt: "sell the highest carry-to-risk future, buy the lowest",
          compute: function () { var g = nanArr(md.n); for (var d = 0; d < md.n; d++) { var v = b.map(function (T, k) { return crRatio(md, c, k, T)[d]; }); if (v.every(isFinite)) g[d] = Math.max.apply(null, v) - Math.min.apply(null, v); } return R.scoreFrom(g, "level"); },
          legs: function (d) { var v = b.map(function (T, k) { return crRatio(md, c, k, T)[d]; }), hi = v.indexOf(Math.max.apply(null, v)), lo = v.indexOf(Math.min.apply(null, v)); return [futLeg(c, "bond", b[hi], 1), futLeg(c, "bond", b[lo], -1)]; },
          why: function (d) { return "Carry-to-risk: " + b.map(function (T, k) { return T + "y " + fmt(crRatio(md, c, k, T)[d], 2); }).join(", ") + "."; } });
      }
    });
    // B7 global: top three vs bottom three across all bond futures
    var U = []; md.ccys.forEach(function (c) { if (md.bond && md.bond[c]) md.bt[c].forEach(function (T, k) { U.push([c, T, k]); }); });
    if (U.length >= 6) {
      var rank = function (d) { var v = U.map(function (u) { return { u: u, v: crRatio(md, u[0], u[2], u[1])[d] }; }).filter(function (q) { return isFinite(q.v); }).sort(function (a, b) { return b.v - a.v; }); return v.length >= 6 ? v : null; };
      push({ id: "B7.G", fam: "B7", ccy: md.ccys.join("/"), name: "Global bond futures: top 3 vs bottom 3 carry-to-risk",
        longTxt: "buy the three highest carry-to-risk futures, sell the three lowest, DV01-matched", shortTxt: "sell the three highest carry-to-risk futures, buy the three lowest",
        compute: function () { var g = nanArr(md.n); for (var d = 0; d < md.n; d++) { var v = rank(d); if (v) g[d] = (v[0].v + v[1].v + v[2].v - v[v.length - 1].v - v[v.length - 2].v - v[v.length - 3].v) / 3; } return R.scoreFrom(g, "level"); },
        legs: function (d) { var v = rank(d) || []; return v.slice(0, 3).map(function (q) { return futLeg(q.u[0], "bond", q.u[1], 1 / 3); }).concat(v.slice(-3).map(function (q) { return futLeg(q.u[0], "bond", q.u[1], -1 / 3); })); },
        why: function (d) { var v = rank(d); return v ? "Top: " + v.slice(0, 3).map(function (q) { return bName(q.u[0], q.u[1]) + " " + fmt(q.v, 2); }).join(", ") + ". Bottom: " + v.slice(-3).map(function (q) { return bName(q.u[0], q.u[1]) + " " + fmt(q.v, 2); }).join(", ") + "." : ""; } });
    }
    return C;
  }

  // ================================================================ robust ratios (Younger et al. 2016)
  function quant(a, p) { if (!a.length) return NaN; var s = a.slice().sort(function (x, y) { return x - y; }), i = (s.length - 1) * p, lo = Math.floor(i), hi = Math.ceil(i); return s[lo] + (s[hi] - s[lo]) * (i - lo); }
  function robust(daily, from) {
    var M = [], all = 0; for (var d = from; d + 21 <= daily.length; d += 21) { var s = 0, on = false; for (var k = d; k < d + 21; k++) { s += daily[k]; if (daily[k] !== 0) on = true; } all++; if (on) M.push(s); } // blocks with a position only
    var med = quant(M, 0.5), iqr = quant(M, 0.75) - quant(M, 0.25), losses = M.filter(function (x) { return x < 0; }), ml = quant(losses, 0.5), q5 = quant(M, 0.05);
    var np = iqr > 0 ? med / iqr : NaN, st = ml < 0 ? med / -ml : NaN, dr = q5 < 0 ? med / -q5 : NaN;
    return { months: M.length, blocks: all, median: med, npSharpe: np, sterling: st, ddRatio: dr, composite: (np + st + dr) / 3 };
  }

  // ================================================================ walk-forward portfolio (§11)
  function sharpeWin(a, d0, d1) { var m = 0, n = d1 - d0, k; if (n < 20) return NaN; for (k = d0; k < d1; k++) m += a[k]; m /= n; var v = 0; for (k = d0; k < d1; k++) v += (a[k] - m) * (a[k] - m); v /= (n - 1); return v > 0 ? { sr: m / Math.sqrt(v) * Math.sqrt(252), sd: Math.sqrt(v) } : NaN; }
  function walkForward(md, scan, opt) {
    opt = opt || {}; var K = opt.K || 10, step = opt.step || 63, look = opt.look || 252, maxFam = opt.maxFam || 2, maxCorr = opt.maxCorr == null ? 0.7 : opt.maxCorr, o = scan.o, n = md.n, res = scan.res;
    var corrW = function (a, b, d0, d1) { var ma = 0, mb = 0, k, m = d1 - d0; for (k = d0; k < d1; k++) { ma += a[k]; mb += b[k]; } ma /= m; mb /= m; var sab = 0, saa = 0, sbb = 0; for (k = d0; k < d1; k++) { var x = a[k] - ma, y = b[k] - mb; sab += x * y; saa += x * x; sbb += y * y; } return saa > 0 && sbb > 0 ? sab / Math.sqrt(saa * sbb) : 0; };
    var start = o.from + look, oos = new Float64Array(n), cost = new Float64Array(n), hind = new Float64Array(n), naive = new Float64Array(n), picks = [], turn = 0, prev = {};
    var choose = function (d0, d1) {
      var sc = res.map(function (r, i) { var s = sharpeWin(r.bt.daily, d0, d1); return { i: i, sr: s && s.sr, sd: s && s.sd }; }).filter(function (q) { return isFinite(q.sr) && q.sr > 0 && q.sd > 0; }).sort(function (a, b) { return b.sr - a.sr; });
      var fam = {}, out = [];
      for (var j = 0; j < sc.length && out.length < K; j++) {
        var f = res[sc[j].i].cand.fam, a = res[sc[j].i].bt.daily; if ((fam[f] || 0) >= maxFam) continue;
        if (maxCorr < 1 && out.some(function (q) { return Math.abs(corrW(a, res[q.i].bt.daily, d0, d1)) > maxCorr; })) continue; // greedy de-duplication on trailing data
        fam[f] = (fam[f] || 0) + 1; out.push(sc[j]);
      }
      var sbar = out.reduce(function (a, q) { return a + q.sd; }, 0) / Math.max(1, out.length);
      out.forEach(function (q) { q.w = sbar / q.sd / out.length; }); return out;
    };
    for (var r0 = start; r0 < n; r0 += step) {
      var sel = choose(r0 - look, r0), r1 = Math.min(n, r0 + step), now = {};
      sel.forEach(function (q) { now[res[q.i].cand.id] = q.w; for (var d = r0; d < r1; d++) { oos[d] += q.w * res[q.i].bt.daily[d]; cost[d] += q.w * res[q.i].bt.cost[d]; } });
      if (picks.length) { var ch = Object.keys(now).filter(function (id) { return !(id in prev); }).length; turn += ch / Math.max(1, Object.keys(now).length); }
      prev = now; picks.push({ d: r0, sel: sel.map(function (q) { return { id: res[q.i].cand.id, w: q.w, sr: q.sr }; }) });
    }
    var hsel = choose(o.from, n); hsel.forEach(function (q) { for (var d = start; d < n; d++) hind[d] += q.w * res[q.i].bt.daily[d]; });
    var all = res.map(function (r) { var s = sharpeWin(r.bt.daily, o.from, n); return s && s.sd > 0 ? s.sd : NaN; }), sb = 0, cnt = 0; all.forEach(function (s) { if (isFinite(s)) { sb += s; cnt++; } }); sb /= Math.max(1, cnt);
    res.forEach(function (r, i) { if (!isFinite(all[i])) return; var w = sb / all[i] / cnt * K; for (var d = start; d < n; d++) naive[d] += w * r.bt.daily[d]; });
    var mk = function (a, cst) { var z = new Float64Array(n); var st = R.stats(md, { daily: a, trades: [], comp: { cost: cst ? Array.prototype.reduce.call(cst.subarray(start), function (x, y) { return x + y; }, 0) : 0 } }, z, { from: start }); st.rob = robust(a, start); return st; };
    return { start: start, K: K, step: step, look: look, maxCorr: maxCorr, oos: oos, hind: hind, naive: naive, cost: cost, picks: picks, turnover: turn / Math.max(1, picks.length - 1), st: { oos: mk(oos, cost), hind: mk(hind), naive: mk(naive) }, hsel: hsel.map(function (q) { return { id: res[q.i].cand.id, w: q.w, sr: q.sr }; }) };
  }

  // ================================================================ live book: aggregate today's risk (§11)
  function liveBook(md, scan, ids) {
    var o = scan.o, d = md.n - 1, rows = [], agg = {};
    ids.forEach(function (it) {
      var r = scan.byId[it.id]; if (!r) return; var z = r.cand.score[d], dir = z >= o.zin ? 1 : z <= -o.zin ? -1 : 0; if (!dir) return;
      var legs; try { legs = X.openLegs(md, r.cand, d, dir, o); } catch (e) { return; }
      legs.forEach(function (L) {
        var c = L.c, a = agg[c] = agg[c] || { vega: 0, vegaS: 0, vegaL: 0, gamma: 0, dv01: 0, soVega: 0 }, wt = it.w || 1;
        if (L.kind === "fut") { a.dv01 += wt * L.N; return; }
        var vg = wt * L.last.Vg; if (L.prod === "so") a.soVega += vg; else { a.vega += vg; if ((L.E || 0) <= 1) a.vegaS += vg; else a.vegaL += vg; }
        a.gamma += wt * L.last.G; if (L.unh) a.dv01 += -wt * L.last.D;
      });
      rows.push({ id: it.id, dir: dir, z: z, w: it.w || 1 });
    });
    return { rows: rows, agg: agg };
  }
  function corrMatrix(md, scan, ids, look) {
    var n = md.n, d0 = Math.max(scan.o.from, n - (look || 252)), S = ids.map(function (id) { return scan.byId[id].bt.daily; }), k = ids.length, M = [];
    var mu = S.map(function (a) { var m = 0; for (var d = d0; d < n; d++) m += a[d]; return m / (n - d0); });
    for (var i = 0; i < k; i++) { M.push([]); for (var j = 0; j < k; j++) { var sxy = 0, sxx = 0, syy = 0; for (var d = d0; d < n; d++) { var x = S[i][d] - mu[i], y = S[j][d] - mu[j]; sxy += x * y; sxx += x * x; syy += y * y; } M[i].push(sxx > 0 && syy > 0 ? sxy / Math.sqrt(sxx * syy) : NaN); } }
    return M;
  }

  // ================================================================ leg description for the idea panel
  function legInfo(md, L, d, o, dir) {
    var w = L.w * (dir || 1), out = { w: w, side: w > 0 ? "buy" : "sell" };
    if (L.kind === "fut") {
      var rate = L.inst === "stir" ? stir(md, L.c, d, L.x) : L.inst === "swap" ? X.swapR(md, L.c, d, L.x) : bond(md, L.c, d, L.x);
      out.name = L.inst === "stir" ? CODE[L.c] + " " + hLbl(L.x) + " contract" : L.inst === "swap" ? L.c + " " + L.x + "y swap (" + (w > 0 ? "receive" : "pay") + ")" : bName(L.c, L.x);
      out.level = L.inst === "stir" ? fmt(100 - rate / 100, 3) + " px" : fmt(rate / 100, 3) + "%"; out.vol = "–"; out.size = "DV01 " + fmt(w * o.dv01, 0); return out;
    }
    if (L.prod === "so") {
      var F = stir(md, L.c, d, L.H), s = X.soVol(md, L.c, d, L.H, L.E), vpn = 2 * Math.sqrt(L.E) * R.pdf(0) * 1e-4;
      out.name = soName(L.c, L.H, L.E) + " straddle"; out.level = fmt(100 - F / 100, 3) + " px"; out.vol = fmt(s, 1); out.size = "vega " + fmt(w * o.vega, 0) + " · " + fmt(w * o.vega / vpn * 1e-4 / 25, 0) + " lots"; return out; // 25 per bp per contract (SFI, ER, SR3)
    }
    var e = ET.indexOf(L.E), off = L.off || 0;
    if (L.kind === "spread") { out.name = L.c + " " + EXPN[e] + " 2s10s spread straddle"; out.level = fmt((md.F[L.c][IX(d, e, L.t2)] - md.F[L.c][IX(d, e, L.t)]), 1) + "bp"; out.vol = fmt(md.spread[L.c][d * NE + e], 1); out.size = "vega " + fmt(w * o.vega, 0); return out; }
    var x = IX(d, e, L.t), Fs = md.F[L.c][x], A = md.A[L.c][x], vol = smileVol(md, L.c, d, e, L.t, off), K = Fs + off;
    var nm = L.c + " " + nn(e, L.t) + " " + (L.kind === "straddle" ? "straddle" : L.kind + (off ? " " + (off > 0 ? "+" : "−") + fmt(Math.abs(off), 0) + "bp" : " ATMF"));
    if (L.size === "dv01") { out.size = "DV01 " + fmt(w * o.dv01, 0) + " · " + fmt(w * o.dv01 / (A * 1e-4) / 1e6, 1) + "m"; nm += L.hedge === false ? " (unhedged)" : ""; }
    else { var zz = (Fs - K) / (vol * Math.sqrt(L.E)), N = w * o.vega / ((L.kind === "straddle" ? 2 : 1) * Math.sqrt(L.E) * R.pdf(zz) * A * 1e-4); out.size = "vega " + fmt(w * o.vega, 0) + " · " + fmt(N / 1e6, 1) + "m"; }
    out.name = nm; out.level = fmt(K / 100, 3) + "%"; out.vol = fmt(vol, 1); return out;
  }

  W.RVX3 = { FAM3: FAM3, CODE: CODE, genSopt: genSopt, genSwap: genSwap, soFromCSV: soFromCSV, candidates3: candidates3, stripHar: stripHar, soFair: soFair, soIV: soIV, soRichZ: soRichZ, KV: KV,
    robust: robust, walkForward: walkForward, liveBook: liveBook, corrMatrix: corrMatrix, legInfo: legInfo, zeroCostOff: zeroCostOff, quant: quant, uStrip: uStrip };
})(window);
