// RV Finder application: state, scan, routing and the four interactive views.
(function () {
  "use strict";
  var R = window.RVF, X = window.RVX, X3 = window.RVX3, U = window.UI, fmt = R.fmt, IX = R.IX, ET = R.ET, EXPN = R.EXPN, TAILS = R.TAILS, NE = R.NE, NT = R.NT;
  var $ = U.$, $$ = U.$$, esc = U.esc;
  var FAMS = ["S1", "S2", "S3", "S4", "S5x", "S5t", "S6", "S7", "S8", "S9", "S10", "S11", "S12", "S13", "S14", "S15", "S16", "O1", "O2", "O3", "F1", "F2", "F3", "F4", "F5", "B1", "B2", "B3", "B4", "B5", "B6", "B7", "B8", "B9"];
  var ASSET = {}; FAMS.forEach(function (f) { ASSET[f] = f[0] === "F" ? "stir" : f[0] === "B" ? "bond" : f[0] === "O" ? "sopt" : "vol"; });
  Object.keys(X.FAMX).forEach(function (f) { R.FAM[f] = X.FAMX[f][0]; });
  var BMNAME = { vol: "short 3m2y straddle", dur: "long 10y bond future" };
  var SHORT = { S1: "Implied vs realised", S2: "Smile breakeven", S3: "Grid carry", S4: "Forward vol", S5x: "Cross-ccy", S5t: "Tail ratio", S6: "Correlation", S7: "Events", S8: "Curve residual",
    S9: "Skew", S10: "Wings", S11: "Surface PCA", S12: "Vol momentum", S13: "Theta-neutral calendar", S14: "Filtered short vol", S15: "Conditional curve", S16: "Vega-neutral calendar",
    O1: "STIR option vs realised", O2: "STIR option calendar", O3: "STIR vs swaption", F1: "STIR carry", F2: "STIR trend", F3: "STIR calendar", F4: "STIR fly", F5: "Regression fly",
    B1: "Bond trend", B2: "Bond carry", B3: "Curve", B4: "PCA fly", B5: "Cross-market", B6: "Swap spread", B7: "Carry rank", B8: "Trend + carry", B9: "Policy cycle" };
  var famLabel = function (f) { return f.replace("S5x", "S5·x").replace("S5t", "S5·t"); };
  var famChip = function (f) { return '<span class="fam" style="background:' + U.FAMCOL[f] + '" title="' + esc(R.FAM[f]) + '">' + famLabel(f) + "</span>"; };
  var ccyChip = function (c) { return c.split("/").map(function (x) { return '<span class="ccy" style="color:' + (U.CCYCOL[x] || "#475467") + '">' + x + "</span>"; }).join(" "); };
  var money = function (v) { return isFinite(v) ? (v < 0 ? "−" : "") + fmt(Math.abs(v) / 1e3, 0) + "k" : "–"; };
  var cls = function (v) { return v > 0 ? "pos" : v < 0 ? "neg" : ""; };

  // ================================================================ state
  var ST = { md: null, scan: null, gen: 0, busy: false,
    sf: { ccy: null, d: null, metric: "comp", cell: [3, 3], tsTail: 3 },
    id: { fam: "", ccy: "", asset: "", live: true, sort: "quality", sel: null, tab: "overview" },
    fu: { ccy: null, d: null, soH: 1 }, pf: { K: 10, step: 63, look: 252, maxFam: 2, maxCorr: 0.7 }, wf: null };

  function opts() {
    var g = function (id, dflt) { var v = parseFloat($(id).value); return isFinite(v) ? v : dflt; };
    return { zin: g("#p-zin", 1.5), zout: g("#p-zout", 0.25), hold: Math.max(1, Math.round(g("#p-hold", 20))), cost: g("#p-cost", 1), vega: g("#p-vega", 10000), dv01: g("#p-dv01", 2500), from: 260 };
  }
  function setStatus(txt, busy) { var s = $("#status"); s.className = "pill" + (busy ? " busy" : ""); s.querySelector("span").textContent = txt; }

  function scan() {
    if (!ST.md) { ST.md = R.generate(27); X.genFutures(ST.md, 27); X3.genSopt(ST.md, 27); X3.genSwap(ST.md, 27); }
    var md = ST.md, o = opts(), gen = ++ST.gen;
    if (md.n < o.from + 140) { setStatus("Need ≥ 400 days", false); return; }
    var C = R.candidates(md).map(function (c) { c.asset = "vol"; c.bm = "vol"; return c; }).concat(X.candidatesExt(md)).concat(X3.candidates3(md)), bench = { vol: {}, dur: {} }, res = [], i = 0;
    md.ccys.forEach(function (c) { bench.vol[c] = X.benchmark(md, c, o, "vol"); bench.dur[c] = X.benchmark(md, c, o, "dur"); });
    ST.busy = true; setStatus("Scanning 0 / " + C.length, true);
    var step = function () {
      if (gen !== ST.gen || md !== ST.md) return;
      var t0 = Date.now();
      while (i < C.length && Date.now() - t0 < 45) {
        var c = C[i++], bt = X.backtest(md, c, o), cum = [], run = 0;
        for (var d = o.from; d < md.n; d++) { run += bt.daily[d]; if ((d - o.from) % 10 === 0 || d === md.n - 1) cum.push(run); }
        res.push({ cand: c, bt: bt, st: R.stats(md, bt, bench[c.bm][c.ccy.slice(0, 3)], o), today: c.score[md.n - 1], spark: cum, rob: X3.robust(bt.daily, o.from) });
      }
      $("#prog").style.width = (100 * i / C.length).toFixed(1) + "%";
      setStatus("Scanning " + i + " / " + C.length, true);
      if (i < C.length) { setTimeout(step, 0); return; }
      var byId = {}; res.forEach(function (r) { byId[r.cand.id] = r; });
      ST.scan = { res: res, byId: byId, bench: bench, o: o, N: C.length, T: md.n - o.from };
      ST.wf = md.n > o.from + ST.pf.look + 63 ? X3.walkForward(md, ST.scan, ST.pf) : null;
      ST.busy = false;
      if (ST.sf.ccy === null || md.ccys.indexOf(ST.sf.ccy) < 0) ST.sf.ccy = md.ccys[0];
      ST.sf.d = md.n - 1; ST.fu.d = md.n - 1; if (!ST.fu.ccy || md.ccys.indexOf(ST.fu.ccy) < 0) ST.fu.ccy = md.ccys[0];
      setStatus(C.length + " candidates · " + res.filter(function (r) { return Math.abs(r.today) >= o.zin; }).length + " live", false);
      $("#scan-note").textContent = "Last scan: " + C.length + " candidates, rules zin " + o.zin + ", zout " + o.zout + ", hold " + o.hold + "d, cost ×" + o.cost + ".";
      $("#id-rules").textContent = "Entry |z| ≥ " + o.zin + " · exit z < " + o.zout + " · hold ≤ " + o.hold + "d · costs ×" + o.cost + " · vega " + fmt(o.vega, 0) + " · DV01 " + fmt(o.dv01, 0);
      setupSurfaceControls();
      route();
    };
    setTimeout(step, 0);
  }

  // ================================================================ lookups for the surface
  function cand(id) { return ST.scan && ST.scan.byId[id]; }
  function scoreOf(id, d) { var r = cand(id); return r ? r.cand.score[d] : NaN; }
  var nn = R.nodeName;
  function others(c) { return ST.md.ccys.filter(function (x) { return x !== c; }); }
  function xccyRich(c, e, t, d, other) { // richness of c vs other at the same cell
    var ccys = ST.md.ccys, a = ccys.indexOf(c) < ccys.indexOf(other) ? c : other, b = a === c ? other : c;
    var z = scoreOf("S5x." + a + " " + nn(e, t) + "/" + b + " " + nn(e, t), d);
    return a === c ? -z : z;
  }
  function tailRich(c, e, t, d) { return t >= 1 ? -scoreOf("S5t." + c + " " + nn(e, t) + "/" + c + " " + nn(e, t - 1), d) : NaN; }
  function carryAt(c, e, t, d) {
    if (e < 1 || e > 5) return NaN; var md = ST.md, v = md.V[c][IX(d, e, t)], f = R.forecast(md, c, e, t)[d], vp = md.V[c][IX(d, e - 1, t)];
    return 100 * ((f * f - v * v) / (2 * v * ET[e]) - (v - vp) / (ET[e] - ET[e - 1])) / 252;
  }
  function fwdAt(c, e, t, d) { if (e >= NE - 1) return NaN; var md = ST.md, s1 = md.V[c][IX(d, e, t)], s2 = md.V[c][IX(d, e + 1, t)]; return Math.sqrt(Math.max(1, (s2 * s2 * ET[e + 1] - s1 * s1 * ET[e]) / (ET[e + 1] - ET[e]))); }
  function composite(c, e, t, d) {
    var v = [-scoreOf("S1." + c + nn(e, t), d), tailRich(c, e, t, d)].concat(others(c).map(function (o) { return xccyRich(c, e, t, d, o); })).filter(isFinite);
    return v.length ? v.reduce(function (a, b) { return a + b; }, 0) / v.length : NaN;
  }
  var METRICS = [
    { k: "comp", g: "Rich / cheap (z)", n: "Composite richness", type: "z", f: composite, sub: function (c, e, t, d) { return fmt(ST.md.V[c][IX(d, e, t)], 0) + "bp"; },
      tex: "\\bar R=\\operatorname{mean}\\{-z^{S1},\\,-z^{S5t},\\,\\pm z^{S5x}\\}", note: "Average richness against realised vol, the next shorter tail and the same cell in the other currencies (§5)." },
    { k: "r1", g: "Rich / cheap (z)", n: "Richness vs realised (S1)", type: "z", f: function (c, e, t, d) { return -scoreOf("S1." + c + nn(e, t), d); }, sub: function (c, e, t, d) { return fmt(ST.md.V[c][IX(d, e, t)] - R.forecast(ST.md, c, e, t)[d], 0); },
      tex: "-z^{S1},\\quad g=\\hat\\sigma-\\sigma\\ \\text{(level mode)}", note: "How unusual today's vol premium is for this cell. The small number is implied minus forecast realised, in bp." },
    { k: "r2", g: "Rich / cheap (z)", n: "Smile-adjusted richness (S2)", type: "z", f: function (c, e, t, d) { return -scoreOf("S2." + c + nn(e, t), d); },
      tex: "-z^{S2},\\quad g=\\hat\\sigma-\\sigma/\\sqrt{1+2c\\sigma E}", note: "As S1, but against the breakeven of a fixed-strike straddle on a convex smile." },
    { k: "tail", g: "Rich / cheap (z)", n: "Tail richness vs shorter tail (S5t)", type: "z", f: tailRich,
      tex: "-z^{S5t},\\quad g=\\ln\\frac{\\sigma^B}{\\sigma^A}-\\ln\\frac{RV^B}{RV^A}", note: "Richness of this tail against the next shorter tail at the same expiry, after realised." },
    { k: "xccy", g: "Rich / cheap (z)", n: "Cross-currency richness (S5x)", type: "z", f: function (c, e, t, d) { var v = others(c).map(function (o) { return xccyRich(c, e, t, d, o); }).filter(isFinite); return v.length ? v.reduce(function (a, b) { return a + b; }, 0) / v.length : NaN; },
      tex: "\\pm z^{S5x}\\ \\text{averaged over the other currencies}", note: "Richness of the cell against the same cell in each other currency, after realised ratios." },
    { k: "fwdr", g: "Rich / cheap (z)", n: "Forward-vol richness (S4)", type: "z", f: function (c, e, t, d) { return e >= 1 && e <= 4 ? -scoreOf("S4." + c + EXPN[e] + EXPN[e + 1] + TAILS[t], d) : NaN; },
      tex: "-z^{S4},\\quad g=\\sigma(E_2-E_1)-\\sigma^{\\text{fwd}}", note: "Richness of the forward vol from this expiry to the next, against spot vol for the same horizon." },
    { k: "vrp", g: "Premia", n: "Vol premium: implied − realised fcst (bp)", type: "bp", f: function (c, e, t, d) { return ST.md.V[c][IX(d, e, t)] - R.forecast(ST.md, c, e, t)[d]; }, sub: function (c, e, t, d) { return fmt(ST.md.V[c][IX(d, e, t)] / R.forecast(ST.md, c, e, t)[d], 2) + "×"; },
      tex: "\\sigma-\\hat\\sigma,\\quad \\hat\\sigma=\\sqrt{0.3RV_5^2+0.4RV_{22}^2+0.3RV_{66}^2}", note: "Implied minus the HAR forecast of realised vol on the fixed forward. Positive means implied is above realised." },
    { k: "carry", g: "Premia", n: "Long-vol carry (vol bp / 100d)", type: "carry", f: carryAt,
      tex: "100\\,C=\\frac{100}{252}\\Big[\\frac{\\hat\\sigma^2-\\sigma^2}{2\\sigma E}-\\frac{\\partial\\sigma}{\\partial E}\\Big]", note: "Expected carry of a long hedged ATM straddle per unit of vega: gamma minus theta, plus roll-down. Shaded as cheap when positive." },
    { k: "shade", g: "Market making", n: "Quote shade: move mid by (bp vol)", type: "shade", f: shadeAt, sub: function (c, e, t, d) { return "½BO " + fmt(halfBOcell(e, t), 1); },
      tex: "\\Delta m=-\\kappa\\,h\\,\\operatorname{clip}(\\bar R/2,\\,-1,\\,1),\\quad \\kappa=\\tfrac12", note: "Where to lean a two-way price: lower the mid on rich cells (more willing to sell), raise it on cheap ones; never by more than half the half bid-offer h (§5)." },
    { k: "iv", g: "Levels", n: "Implied normal vol (bp)", type: "seq", f: function (c, e, t, d) { return ST.md.V[c][IX(d, e, t)]; }, tex: "\\sigma_d(e,j)", note: "ATM normal implied vol." },
    { k: "rv", g: "Levels", n: "Forecast realised, HAR (bp)", type: "seq", f: function (c, e, t, d) { return R.forecast(ST.md, c, e, t)[d]; }, tex: "\\hat\\sigma_d(e,j)", note: "HAR forecast of realised vol on the fixed forward." },
    { k: "fwd", g: "Levels", n: "Forward vol to next expiry (bp)", type: "seq", f: fwdAt, tex: "\\sigma^{\\text{fwd}}=\\sqrt{\\frac{\\sigma_2^2E_2-\\sigma_1^2E_1}{E_2-E_1}}", note: "Forward vol between this expiry and the next on the same tail." }
  ];
  var MET = {}; METRICS.forEach(function (m) { MET[m.k] = m; });
  function halfBOcell(e, t) { return (ET[e] >= 2 ? 0.7 : 0.4) + (TAILS[t] >= 30 ? 0.3 : 0); }
  function shadeAt(c, e, t, d) { var z = composite(c, e, t, d); return isFinite(z) ? -0.5 * halfBOcell(e, t) * Math.max(-1, Math.min(1, z / 2)) : NaN; }

  // ================================================================ routing
  function route() {
    var h = (location.hash || "#surface").slice(1), parts = h.split(":"), v = parts[0];
    if (["surface", "futures", "ideas", "portfolio", "stats", "method", "data"].indexOf(v) < 0) v = "surface";
    $$(".view").forEach(function (el) { el.classList.toggle("on", el.id === "v-" + v); });
    $$("#nav a").forEach(function (a) { a.classList.toggle("on", a.getAttribute("data-v") === v); });
    if (v === "method") { if (parts[1]) { var el = document.getElementById(parts[1]); if (el) el.scrollIntoView({ block: "start" }); } else window.scrollTo(0, 0); return; }
    if (!ST.scan) return;
    if (v === "surface") renderSurface();
    else if (v === "ideas") renderIdeas();
    else if (v === "futures") renderFutures();
    else if (v === "stats") renderStats();
    else if (v === "portfolio") renderPortfolio();
  }

  // ================================================================ SURFACE
  function setupSurfaceControls() {
    var md = ST.md, sf = ST.sf;
    $("#sf-ccy").innerHTML = md.ccys.map(function (c) { return '<button type="button" data-c="' + c + '"' + (c === sf.ccy ? ' class="on"' : "") + ">" + c + "</button>"; }).join("");
    var sl = $("#sf-date"); sl.min = ST.scan.o.from; sl.max = md.n - 1; sl.value = sf.d;
    $("#sf-metric").innerHTML = ["Rich / cheap (z)", "Premia", "Market making", "Levels"].map(function (g) { return '<optgroup label="' + g + '">' + METRICS.filter(function (m) { return m.g === g; }).map(function (m) { return '<option value="' + m.k + '"' + (m.k === sf.metric ? " selected" : "") + ">" + esc(m.n) + "</option>"; }).join("") + "</optgroup>"; }).join("");
    $("#sf-ts-tail").innerHTML = TAILS.map(function (t, j) { return '<button type="button" data-t="' + j + '"' + (j === sf.tsTail ? ' class="on"' : "") + ">" + t + "y</button>"; }).join("");
    $("#srcline").textContent = md.source === "illustrative" ? "Illustrative data (§9)" : "Your data · " + md.ccys.join(", ");
  }
  function liveCells(c, d) {
    var o = ST.scan.o, set = {};
    ST.scan.res.forEach(function (r) {
      var cd = r.cand; if (cd.ccy.indexOf(c) < 0 || !(Math.abs(cd.score[d]) >= o.zin)) return;
      var cells = cellsOf(cd, c); cells.forEach(function (k) { set[k] = (set[k] || 0) + 1; });
    });
    return set;
  }
  function cellsOf(cd, c) { // grid cells (in currency c) a candidate trades
    if (cd.node) return [cd.node[0] + "," + cd.node[1]];
    if (cd.cells) return cd.ccy === c ? cd.cells.map(function (p) { return p[0] + "," + p[1]; }) : [];
    if (cd.pair) return cd.pair.filter(function (p) { return p[0] === c; }).map(function (p) { return p[1] + "," + p[2]; });
    var m = cd.id.match(/^S4\.\w{3}(\d+[my])(\d+[my])(\d+)$/); if (m) { var t = TAILS.indexOf(+m[3]); return [EXPN.indexOf(m[1]) + "," + t, EXPN.indexOf(m[2]) + "," + t]; }
    m = cd.id.match(/^S6\.\w{3}(\d+[my])$/); if (m) { var e = EXPN.indexOf(m[1]); return [e + ",1", e + ",3"]; }
    return [];
  }
  function renderSurface() {
    var md = ST.md, sf = ST.sf, c = sf.ccy, d = sf.d, m = MET[sf.metric], o = ST.scan.o;
    $("#sf-datelbl").textContent = md.dates[d];
    $$("#sf-ccy button").forEach(function (b) { b.classList.toggle("on", b.getAttribute("data-c") === c); });
    // values
    var vals = [], lo = Infinity, hi = -Infinity, mx = 0;
    for (var e = 0; e < NE; e++) { vals.push([]); for (var t = 0; t < NT; t++) { var v = m.f(c, e, t, d); vals[e].push(v); if (isFinite(v)) { lo = Math.min(lo, v); hi = Math.max(hi, v); mx = Math.max(mx, Math.abs(v)); } } }
    var lim = m.type === "z" ? 2.5 : mx || 1, live = liveCells(c, d);
    var col = function (v) { return m.type === "seq" ? U.seqColor(v, lo, hi) : m.type === "carry" || m.type === "shade" ? U.divColor(-v, lim) : U.divColor(v, lim); };
    var h = '<div class="hm" style="grid-template-columns:44px repeat(' + NT + ',minmax(0,1fr))"><div></div>' + TAILS.map(function (t) { return '<div class="hd">' + t + "y</div>"; }).join("");
    for (e = 0; e < NE; e++) {
      h += '<div class="rl">' + EXPN[e] + "</div>";
      for (t = 0; t < NT; t++) {
        var v2 = vals[e][t], cc = col(v2), sel = sf.cell[0] === e && sf.cell[1] === t, nlive = live[e + "," + t] || 0;
        var tipTxt = "<b>" + c + " " + nn(e, t) + "</b><div>" + esc(m.n) + ": <b>" + fmt(v2, m.type === "z" ? 2 : 1) + "</b></div><div>Implied " + fmt(md.V[c][IX(d, e, t)], 1) + "bp · realised fcst " + fmt(R.forecast(md, c, e, t)[d], 1) + "bp</div>" + (nlive ? "<div>" + nlive + " live idea" + (nlive > 1 ? "s" : "") + " on this cell</div>" : "");
        h += '<div class="c' + (sel ? " sel" : "") + '" data-cell="' + e + "," + t + '" style="background:' + cc.bg + ";color:" + cc.fg + '" data-tip="' + esc(tipTxt) + '">' + (nlive ? '<span class="dot"></span>' : "") + "<b>" + (isFinite(v2) ? fmt(v2, m.type === "z" || m.type === "shade" ? 2 : m.type === "seq" ? 0 : 1) : "–") + "</b>" + (m.sub && isFinite(v2) ? "<small>" + m.sub(c, e, t, d) + "</small>" : "") + "</div>";
      }
    }
    h += "</div>";
    var grad = m.type === "seq" ? "linear-gradient(90deg,rgb(238,242,255),rgb(22,36,92))" : "linear-gradient(90deg,rgb(24,100,171),rgb(246,247,250),rgb(196,64,22))";
    h += '<div class="scale">' + (m.type === "seq" ? "<span>" + fmt(lo, 0) + "</span>" : m.type === "carry" ? "<span>long vol earns (cheap)</span>" : m.type === "shade" ? "<span>raise mid · lean bid</span>" : "<span>cheap · buy</span>") + '<span class="bar" style="background:' + grad + '"></span>' + (m.type === "seq" ? "<span>" + fmt(hi, 0) + "</span>" : m.type === "carry" ? "<span>long vol pays (rich)</span>" : m.type === "shade" ? "<span>lower mid · lean offer</span>" : "<span>rich · sell</span>") + '<span style="margin-left:auto">● live idea on cell</span></div>';
    $("#sf-heat").innerHTML = h;
    $("#sf-title").textContent = c + " · " + m.n;
    $("#sf-sub").textContent = md.dates[d] + (d === md.n - 1 ? " (latest)" : "") + (m.type === "z" ? " · colour scale ±2.5 sd" : "");
    $("#sf-def").innerHTML = '<div class="texd">' + esc(m.tex) + "</div>" + esc(m.note);
    // KPIs
    var vrpAll = [], comps = [];
    for (e = 0; e <= 5; e++) for (t = 0; t < NT; t++) { vrpAll.push(md.V[c][IX(d, e, t)] - R.forecast(md, c, e, t)[d]); var cp = composite(c, e, t, d); if (isFinite(cp)) comps.push({ e: e, t: t, v: cp }); }
    comps.sort(function (a, b) { return b.v - a.v; });
    var vm = vrpAll.filter(isFinite), avgV = vm.reduce(function (a, b) { return a + b; }, 0) / vm.length;
    var nLive = ST.scan.res.filter(function (r) { return r.cand.ccy.indexOf(c) >= 0 && Math.abs(r.cand.score[d]) >= o.zin; }).length;
    var rich = comps[0], cheap = comps[comps.length - 1];
    $("#sf-kpis").innerHTML = kpi("1y10y implied", fmt(md.V[c][IX(d, 3, 3)], 1) + "bp", "realised fcst " + fmt(R.forecast(md, c, 3, 3)[d], 1) + "bp", true) + kpi("Average vol premium", (avgV > 0 ? "+" : "") + fmt(avgV, 1) + "bp", "implied − realised fcst, 1m–5y") +
      kpi("Richest cell", rich ? nn(rich.e, rich.t) : "–", rich ? "composite " + fmt(rich.v, 2) : "") + kpi("Cheapest cell", cheap ? nn(cheap.e, cheap.t) : "–", cheap ? "composite " + fmt(cheap.v, 2) : "") +
      kpi("Live signals", String(nLive), "|z| ≥ " + o.zin + " on " + md.dates[d]);
    renderCell(); renderTS(); renderX(); renderCorr(); renderEvent();
    U.renderMath($("#v-surface"));
  }
  function kpi(label, val, small, hl) { return '<div class="kpi' + (hl ? " hl" : "") + '"><span>' + esc(label) + "</span><b>" + val + "</b>" + (small ? "<small>" + esc(small) + "</small>" : "") + "</div>"; }

  function renderCell() {
    var md = ST.md, sf = ST.sf, c = sf.ccy, d = sf.d, e = sf.cell[0], t = sf.cell[1], o = ST.scan.o, from = o.from;
    var x = [], iv = [], rv = [], r1 = [], rt = [], rx = [];
    var fc = R.forecast(md, c, e, t);
    for (var k = from; k < md.n; k++) {
      x.push(k); iv.push(md.V[c][IX(k, e, t)]); rv.push(fc[k]);
      r1.push(-scoreOf("S1." + c + nn(e, t), k)); rt.push(tailRich(c, e, t, k));
      var xs = others(c).map(function (oc) { return xccyRich(c, e, t, k, oc); }).filter(isFinite); rx.push(xs.length ? xs.reduce(function (a, b) { return a + b; }, 0) / xs.length : NaN);
    }
    var xf = function (v) { var dd = md.dates[Math.max(0, Math.min(md.n - 1, Math.round(v)))]; return dd ? dd.slice(0, 7) : ""; };
    var xfd = function (v) { return md.dates[Math.max(0, Math.min(md.n - 1, Math.round(v)))]; };
    var v0 = md.V[c][IX(d, e, t)], f0 = fc[d], comp = composite(c, e, t, d);
    // smile at the cell
    var F = md.F[c][IX(d, e, t)], s = md.S[c][IX(d, e, t)], cv = md.C[c][IX(d, e, t)], mx = [], sm = [];
    for (var mm = -200; mm <= 200; mm += 10) { mx.push(mm); sm.push(Math.max(1, v0 + s * mm + cv * mm * mm)); }
    // candidates on the cell
    var list = ST.scan.res.filter(function (r) { return r.cand.ccy.indexOf(c) >= 0 && cellsOf(r.cand, c).indexOf(e + "," + t) >= 0; }).sort(function (a, b) { return Math.abs(b.cand.score[d] || 0) - Math.abs(a.cand.score[d] || 0); });
    var h = '<div class="card-h"><div><h3>' + c + " " + nn(e, t) + ' · cell drill-down</h3><p class="sub">Forward ' + fmt(F / 100, 3) + "% · annuity " + fmt(md.A[c][IX(d, e, t)], 2) + " · " + md.dates[d] + "</p></div></div>";
    h += '<div class="kpis" style="grid-template-columns:repeat(4,minmax(0,1fr));margin-bottom:8px">' + kpi("Implied σ", fmt(v0, 1), "bp") + kpi("Realised fcst", fmt(f0, 1), "bp, HAR") + kpi("Premium", (v0 - f0 > 0 ? "+" : "") + fmt(v0 - f0, 1), fmt(v0 / f0, 2) + "× realised") + kpi("Composite", fmt(comp, 2), comp > 0.5 ? "rich" : comp < -0.5 ? "cheap" : "neutral") + "</div>";
    h += U.line({ x: x, series: [{ y: iv, color: "#2F5BEA", name: "Implied", area: true }, { y: rv, color: "#98A2B3", name: "Forecast realised", dash: "5 4" }], xf: function (v, full) { return full ? xfd(v) : xf(v); }, marker: d, h: 210, w: 520, yl: "bp", label: "Implied vs realised" });
    h += U.legend([["Implied σ", "#2F5BEA"], ["Forecast realised (HAR)", "#98A2B3", 1], ["Selected date", "#F79009"]]);
    h += U.line({ x: x, series: [{ y: r1, color: U.FAMCOL.S1, name: "vs realised (S1)" }, { y: rt, color: U.FAMCOL.S5t, name: "vs shorter tail (S5t)" }, { y: rx, color: U.FAMCOL.S5x, name: "vs other ccys (S5x)" }], hlines: [{ y: o.zin, label: "rich: sell" }, { y: -o.zin, label: "cheap: buy" }], xf: function (v, full) { return full ? xfd(v) : xf(v); }, marker: d, h: 200, w: 520, yl: "richness z", label: "Richness history" });
    h += U.legend([["vs realised", U.FAMCOL.S1], ["vs shorter tail", U.FAMCOL.S5t], ["vs other currencies", U.FAMCOL.S5x]]);
    h += '<div class="grid g2" style="gap:12px;margin-top:6px"><div>' + U.line({ x: mx, series: [{ y: sm, color: "#7A5AF8", name: "σ(K)" }], xf: function (v) { return (v > 0 ? "+" : "") + v; }, h: 200, w: 320, yl: "smile σ(K), bp", label: "Smile" }) + '<p class="note" style="margin:0">Strike offset K − F in bp. s = ' + fmt(s, 3) + ", c = " + fmt(cv * 1e4, 2) + "×10⁻⁴</p></div>";
    h += '<div><div class="scroll" style="max-height:220px"><table class="tbl"><tr><th>Signals on this cell</th><th class="num">z</th><th class="num">SR</th><th></th></tr>' + list.slice(0, 12).map(function (r) {
      var z = r.cand.score[d]; return '<tr class="row" data-idea="' + esc(r.cand.id) + '"><td>' + famChip(r.cand.fam) + " " + esc(shortName(r.cand)) + '</td><td class="num ' + (Math.abs(z) >= o.zin ? (z > 0 ? "pos" : "neg") : "") + '">' + fmt(z, 2) + '</td><td class="num">' + fmt(r.st.sharpe, 2) + "</td><td>" + gates(r.st) + "</td></tr>";
    }).join("") + "</table></div></div></div>";
    $("#sf-cell").innerHTML = h;
  }
  function shortName(cd) { return cd.name.replace(/^(GBP|EUR|USD)\s/, ""); }
  function gates(st) { return '<span class="gates" title="Gates 2–5">' + [1, 2, 3, 4].map(function (k) { return "<i" + (st.g[k] ? ' class="on"' : "") + "></i>"; }).join("") + "</span>"; }

  function renderTS() {
    var md = ST.md, c = ST.sf.ccy, d = ST.sf.d, j = ST.sf.tsTail, x = [], iv = [], rv = [], fw = [];
    for (var e = 0; e < NE; e++) { x.push(e); iv.push(md.V[c][IX(d, e, j)]); rv.push(R.forecast(md, c, e, j)[d]); fw.push(fwdAt(c, e, j, d)); }
    $$("#sf-ts-tail button").forEach(function (b) { b.classList.toggle("on", +b.getAttribute("data-t") === j); });
    $("#sf-ts").innerHTML = U.line({ x: x, series: [{ y: iv, color: "#2F5BEA", name: "Implied", width: 2.4 }, { y: rv, color: "#98A2B3", name: "Forecast realised", dash: "5 4", width: 2 }, { y: fw, color: "#DC6803", name: "Forward vol to next", width: 1.6 }], xf: function (v) { return EXPN[Math.round(v)] || ""; }, xticks: 7, h: 230, yl: c + " " + TAILS[j] + "y tail, bp", label: "Term structure" }) +
      U.legend([["Implied", "#2F5BEA"], ["Forecast realised", "#98A2B3", 1], ["Forward vol to next expiry", "#DC6803"]]);
  }
  function renderX() {
    var md = ST.md, d = ST.sf.d, e = ST.sf.cell[0], t = ST.sf.cell[1], cs = md.ccys;
    var iv = cs.map(function (c) { return md.V[c][IX(d, e, t)]; }), rv = cs.map(function (c) { return R.forecast(md, c, e, t)[d]; });
    $("#sf-x-sub").textContent = nn(e, t) + " on " + md.dates[d] + " · implied ÷ realised: " + cs.map(function (c, i) { return c + " " + fmt(iv[i] / rv[i], 2) + "×"; }).join(", ");
    $("#sf-x").innerHTML = U.bars({ cats: cs, series: [{ name: "Implied", y: iv, color: "#2F5BEA" }, { name: "Forecast realised", y: rv, color: "#C0C8D8" }], h: 230, yl: "bp", tf: function (v) { return fmt(v, 1) + "bp"; } }) + U.legend([["Implied", "#2F5BEA"], ["Forecast realised", "#C0C8D8"]]);
  }
  function renderCorr() {
    var md = ST.md, c = ST.sf.ccy, d = ST.sf.d;
    if (!md.spread[c]) { $("#sf-corr").innerHTML = '<div class="empty">No 2s10s spread-option vols for ' + c + ". Load a spread CSV on the Data page.</div>"; return; }
    var dF = R.dFixed(md, c), cats = [], ri = [], rr = [];
    for (var e = 1; e <= 5; e++) {
      var sa = md.V[c][IX(d, e, 1)], sb = md.V[c][IX(d, e, 3)], ss = md.spread[c][d * NE + e];
      var a = new Float64Array(md.n), b = new Float64Array(md.n); for (var k = 0; k < md.n; k++) { a[k] = dF[IX(k, e, 1)]; b[k] = dF[IX(k, e, 3)]; }
      cats.push(EXPN[e]); ri.push((sa * sa + sb * sb - ss * ss) / (2 * sa * sb)); rr.push(R.rollCorr(a, b, 66)[d]);
    }
    $("#sf-corr").innerHTML = U.bars({ cats: cats, series: [{ name: "Implied ρ", y: ri, color: "#15B79E" }, { name: "Realised ρ (66d)", y: rr, color: "#C0C8D8" }], h: 220, yl: "correlation 2y vs 10y", tf: function (v) { return fmt(v, 3); }, yf: function (v) { return fmt(v, 2); } }) + U.legend([["Implied ρ", "#15B79E"], ["Realised ρ, 66 days", "#C0C8D8"]]);
  }
  function renderEvent() {
    var md = ST.md, c = ST.sf.ccy, d = ST.sf.d, t = 0, evx = md.evx[c];
    if (!evx || !md.ev[c].some(function (x) { return x; })) { $("#sf-ev").innerHTML = '<div class="empty">No event calendar for ' + c + ". Load an events CSV on the Data page.</div>"; return; }
    var n = 0; for (var q = d + 1; q <= d + 21; q++) if (evx[q]) n++;
    var base = R.realised(md, c, 0, t, 66, true)[d], dF = R.dFixed(md, c), past = [];
    for (q = d; q >= 0 && past.length < 8; q--) if (md.ev[c][q] && isFinite(dF[IX(q, 0, t)])) past.push(dF[IX(q, 0, t)]);
    var rms = Math.sqrt(past.reduce(function (a, b) { return a + b * b; }, 0) / Math.max(1, past.length));
    var iv = md.V[c][IX(d, 0, t)], totVar = iv * iv / 12, normVar = base * base / 252 * (21 - n), evMove = n ? Math.sqrt(Math.max(0, (totVar - normVar) / n)) : NaN;
    var day = base / Math.sqrt(252);
    var h = U.bars({ cats: ["Normal day", "Event priced", "Past events (RMS)"], series: [{ name: "move", y: [day, evMove, rms], color: function (v, i) { return ["#98A2B3", "#6172F3", "#344054"][i]; } }], h: 210, yl: "daily move, bp", tf: function (v) { return fmt(v, 2) + "bp"; } });
    h += '<p class="note" style="margin:4px 0 0">' + c + " 1m1y implied " + fmt(iv, 1) + "bp: " + n + " event day" + (n === 1 ? "" : "s") + " in the next 21 business days. " + (n ? "The implied variance prices each event at " + fmt(evMove, 2) + "bp, " + fmt(evMove / day, 1) + "× a normal day, against an RMS of " + fmt(rms, 2) + "bp on the last " + past.length + " events." : "With no event in the window, all implied variance is normal-day variance.") + "</p>";
    $("#sf-ev").innerHTML = h;
  }

  // ================================================================ IDEAS
  function setupIdeaControls() {
    $("#id-asset").innerHTML = [["", "All assets"], ["vol", "Swaption vol"], ["sopt", "STIR options"], ["stir", "STIR futures"], ["bond", "Bonds & swaps"]].map(function (a) { return '<button type="button" data-a="' + a[0] + '"' + (ST.id.asset === a[0] ? ' class="on"' : "") + ">" + a[1] + "</button>"; }).join("");
    $("#id-fam").innerHTML = '<button type="button" data-f=""' + (ST.id.fam ? "" : ' class="on"') + ">All families</button>" + FAMS.filter(function (f) { return !ST.id.asset || ASSET[f] === ST.id.asset; }).map(function (f) { return '<button type="button" data-f="' + f + '"' + (ST.id.fam === f ? ' class="on"' : "") + ' title="' + esc(R.FAM[f]) + '"><span style="display:inline-block;width:8px;height:8px;border-radius:2px;background:' + U.FAMCOL[f] + ';margin-right:6px"></span>' + famLabel(f) + " " + esc(SHORT[f]) + "</button>"; }).join("");
    $("#id-ccy").innerHTML = ['', "GBP", "EUR", "USD"].map(function (c) { return '<button type="button" data-c="' + c + '"' + (ST.id.ccy === c ? ' class="on"' : "") + ">" + (c || "All") + "</button>"; }).join("");
  }
  function sideOf(r, o) { return r.today >= o.zin ? "buy" : r.today <= -o.zin ? "sell" : "flat"; }
  function actionTxt(r, o) { var s = sideOf(r, o); return s === "buy" ? r.cand.longTxt : s === "sell" ? r.cand.shortTxt : r.cand.name; }
  function renderIdeas() {
    setupIdeaControls();
    var S = ST.scan, o = S.o, F = ST.id;
    $$("#id-live button").forEach(function (b) { b.classList.toggle("on", (b.getAttribute("data-v") === "live") === F.live); });
    $("#id-sort").value = F.sort;
    var rows = S.res.filter(function (r) { return (!F.asset || r.cand.asset === F.asset) && (!F.fam || r.cand.fam === F.fam) && (!F.ccy || r.cand.ccy.indexOf(F.ccy) >= 0) && (!F.live || Math.abs(r.today) >= o.zin); });
    var sorters = { quality: function (a, b) { return b.st.passed - a.st.passed || (b.st.sharpe || -9) - (a.st.sharpe || -9); }, signal: function (a, b) { return Math.abs(b.today || 0) - Math.abs(a.today || 0); }, sharpe: function (a, b) { return (b.st.sharpe || -9) - (a.st.sharpe || -9); }, alpha: function (a, b) { return (b.st.alphaT || -9) - (a.st.alphaT || -9); } };
    rows.sort(sorters[F.sort]);
    var h = '<div class="card-h"><div><h3>' + (F.live ? "Live ideas" : "All candidates") + ' <span class="note">(' + rows.length + ")</span></h3><p class=\"sub\">Click a row for the formulas with today's numbers, charts, gates and trades. Gates ●: significant · not short-vol beta · robust · tail-sized.</p></div></div>";
    if (!rows.length) h += '<div class="empty">No candidates match these filters.</div>';
    else h += '<div class="scroll"><table class="tbl"><tr><th>Family</th><th>Idea today</th><th class="num">z</th><th>P&amp;L path</th><th class="num">Sharpe</th><th class="num">NW t</th><th class="num">α t</th><th class="num">β</th><th class="num">Trades</th><th class="num">Hit</th><th class="num">2× cost</th><th>Gates</th></tr>' + rows.slice(0, 150).map(function (r) {
      var s = r.st, sd = sideOf(r, o);
      return '<tr class="row' + (r.cand.id === F.sel ? " on" : "") + '" data-idea="' + esc(r.cand.id) + '"><td>' + famChip(r.cand.fam) + '</td><td><span class="side-tag ' + sd + '">' + (sd === "flat" ? "no pos" : sd) + "</span> " + ccyChip(r.cand.ccy) + " " + esc(actionTxt(r, o).replace(/^(buy|sell)\s/, "")) + '</td><td class="num ' + (sd === "buy" ? "pos" : sd === "sell" ? "neg" : "") + '">' + fmt(r.today, 2) + "</td><td>" + U.spark(r.spark) + '</td><td class="num ' + cls(s.sharpe) + '">' + fmt(s.sharpe, 2) + '</td><td class="num">' + fmt(s.nwt, 1) + '</td><td class="num">' + fmt(s.alphaT, 1) + '</td><td class="num">' + fmt(s.beta, 2) + '</td><td class="num">' + s.n + '</td><td class="num">' + (isFinite(s.hit) ? fmt(s.hit * 100, 0) + "%" : "–") + '</td><td class="num ' + cls(s.t2x) + '">' + money(s.t2x) + "</td><td>" + gates(s) + "</td></tr>";
    }).join("") + "</table></div>" + (rows.length > 150 ? '<p class="note">Top 150 of ' + rows.length + " shown. Download all results on the Data page.</p>" : "");
    $("#id-table").innerHTML = h;
    var r0 = F.sel && S.byId[F.sel];
    $("#id-detail").innerHTML = r0 ? detail(r0) : "";
    U.renderMath($("#v-ideas"));
  }

  function detail(r) {
    var md = ST.md, S = ST.scan, o = S.o, c = r.cand, bt = r.bt, st = r.st, last = md.n - 1, F = ST.id;
    var dir = r.today >= o.zin ? 1 : r.today <= -o.zin ? -1 : 0;
    var h = '<div class="card detail" style="margin-bottom:16px"><div class="detail-h"><div>' + famChip(c.fam) + " " + ccyChip(c.ccy) + " <span class=\"note\">" + esc(R.FAM[c.fam]) + "</span><h2>" + esc(c.name) + '</h2><p class="sub">' + (dir ? '<span class="side-tag ' + (dir > 0 ? "buy" : "sell") + '">' + (dir > 0 ? "buy" : "sell") + "</span> <b>" + esc(dir > 0 ? c.longTxt : c.shortTxt) + "</b> · " : '<span class="side-tag flat">no position</span> ') + "z = " + fmt(r.today, 2) + " on " + md.dates[last] + '</p></div><button class="btn sm" type="button" id="b-close">Close</button></div>';
    h += '<div class="tabs">' + [["overview", "Overview"], ["maths", "Mathematics"], ["trades", "Trades"]].map(function (t) { return '<button type="button" data-tab="' + t[0] + '"' + (F.tab === t[0] ? ' class="on"' : "") + ">" + t[1] + "</button>"; }).join("") + "</div>";
    if (F.tab === "maths") {
      var card = document.getElementById("sig-" + c.fam.replace(/^S5[xt]$/, "S5"));
      h += (card ? '<div class="article">' + card.outerHTML.replace(/ id="sig-[^"]+"/, "") + "</div>" : "") + '<p class="note">Full method: <a href="#method:sig-' + c.fam.replace(/^S5[xt]$/, "S5") + '">Method</a> · statistics: <a href="#method:mt-stats">§8</a>.</p>';
      return h + "</div>";
    }
    if (F.tab === "trades") {
      h += '<div class="scroll"><table class="tbl"><tr><th>Entry</th><th>Exit</th><th>Side</th><th class="num">z in</th><th class="num">z out</th><th>Exit reason</th><th class="num">Days</th><th class="num">P&amp;L</th></tr>' + bt.trades.slice().reverse().map(function (tr) { return '<tr><td class="num" style="text-align:left">' + md.dates[tr.d0] + '</td><td class="num" style="text-align:left">' + md.dates[tr.d1] + '</td><td><span class="side-tag ' + (tr.dir > 0 ? "buy" : "sell") + '">' + (tr.dir > 0 ? "long" : "short") + '</span></td><td class="num">' + fmt(tr.s0, 2) + '</td><td class="num">' + fmt(tr.s1, 2) + "</td><td>" + esc(tr.why) + '</td><td class="num">' + (tr.d1 - tr.d0) + '</td><td class="num ' + cls(tr.pnl) + '">' + money(tr.pnl) + "</td></tr>"; }).join("") + "</table></div>";
      return h + '<div class="controls mt"><button class="btn sm" type="button" id="b-trades">Download trades and daily P&amp;L (CSV)</button></div></div>';
    }
    // overview
    var x = [], sc = [], cum = [], bcum = [], cp = 0, cb = 0, bench = S.bench[c.bm][c.ccy.slice(0, 3)];
    var sdOf = function (a) { var m = 0, k, n = 0; for (k = o.from; k < md.n; k++) { m += a[k]; n++; } m /= n; var v = 0; for (k = o.from; k < md.n; k++) v += (a[k] - m) * (a[k] - m); return Math.sqrt(v / (n - 1)); };
    var bscale = sdOf(bench) > 0 ? sdOf(bt.daily) / sdOf(bench) : 1;
    for (var d = o.from; d < md.n; d++) { x.push(d); sc.push(bt.score[d]); cp += bt.daily[d]; cb += bench[d] * bscale; cum.push(cp / 1e3); bcum.push(cb / 1e3); }
    var xf = function (v, full) { var dd = md.dates[Math.max(0, Math.min(last, Math.round(v)))]; return dd ? (full ? dd : dd.slice(0, 7)) : ""; };
    var uf = X.unitForward(md, c, o), ics = [5, 10, 20].map(function (hh) { var a = uf.filter(function (q) { return isFinite(q["h" + hh]); }); return a.length > 20 ? R.spearman(a.map(function (q) { return q.s; }), a.map(function (q) { return q["h" + hh]; })) : NaN; });
    var g1 = ics.every(function (v) { return v > 0.05; }), dp = R.dsr(st.sharpe, S.T, S.N);
    var gl = [["1 Predictive", "IC 5 / 10 / 20d: " + ics.map(function (v) { return fmt(v, 3); }).join(" / "), g1], ["2 Significant", "NW t " + fmt(st.nwt, 2) + " · DSR " + fmt(dp, 3) + " (N = " + S.N + ")", st.nwt > 2 && dp > 0.95], ["3 Not benchmark beta", "α t " + fmt(st.alphaT, 2) + " · β " + fmt(st.beta, 2) + " to " + BMNAME[c.bm], st.alphaT > 2], ["4 Robust", "2× costs " + money(st.t2x) + " · best year " + (isFinite(st.maxYear) ? fmt(st.maxYear * 100, 0) + "%" : "–"), st.g[3]], ["5 Tail-sized", "worst 20d " + money(st.w20) + " = " + (isFinite(st.tail) ? fmt(st.tail, 1) : "∞") + " months", st.g[4]]];
    var g = c.gap[last], m = c.gm[last], sdv = c.gs[last];
    var zt = c.mode === "raw" ? "z_d=g_d=" + fmt(r.today, 2) + "\\quad(\\text{rule score, no rescaling})" : c.mode === "level" ? "z_d=\\dfrac{g_d}{s_d}=\\dfrac{" + fmt(g, 4) + "}{" + fmt(sdv, 4) + "}=" + fmt(r.today, 2) : "z_d=\\dfrac{g_d-\\bar g_d}{s_d}=\\dfrac{" + fmt(g, 4) + "-(" + fmt(m, 4) + ")}{" + fmt(sdv, 4) + "}=" + fmt(r.today, 2);
    var hasFut = false, hasOpt = false, hasDv = false, hasVg = false;
    var legs = c.legs(last).map(function (L) {
      var li = X3.legInfo(md, L, last, o, dir || 1); if (L.kind === "fut") hasFut = true; else { hasOpt = true; if (L.size === "dv01") hasDv = true; else hasVg = true; }
      return "<tr><td>" + esc(li.name) + '</td><td><span class="side-tag ' + li.side + '">' + li.side + '</span></td><td class="num">' + fmt(li.w, 3) + '</td><td class="num">' + li.level + '</td><td class="num">' + li.vol + '</td><td class="num">' + esc(li.size) + "</td></tr>";
    }).join("");
    var legHead = '<tr><th>Leg</th><th>Side</th><th class="num">D·w</th><th class="num">Strike / level</th><th class="num">Vol</th><th class="num">Size</th></tr>';
    var cmp = bt.comp;
    h += '<div class="grid g2"><div><div class="eyebrow">Today\'s numbers in the formulas</div><div class="formula"><div class="texd">' + esc("g_d=" + fmt(g, 4) + ",\\quad \\bar g_d=" + fmt(m, 4) + ",\\quad s_d=" + fmt(sdv, 4) + "\\quad(\\text{" + (c.mode === "level" ? "level" : "z") + " mode})") + '</div><div class="texd">' + esc(zt) + '</div><div class="texd">' + esc("|z_d|" + (Math.abs(r.today) >= o.zin ? "\\ge " : "<") + "z_{\\text{in}}=" + fmt(o.zin, 2) + "\\;\\Rightarrow\\;" + (dir ? (dir > 0 ? "D=+1\\ (\\text{buy})" : "D=-1\\ (\\text{sell})") : "\\text{no new position}")) + '</div></div><p class="note" style="margin:8px 0">' + esc(c.why(last)) + ' <a href="#method:sig-' + c.fam.replace(/^S5[xt]$/, "S5") + '">Definition and derivation →</a></p>';
    h += '<div class="scroll-x"><table class="tbl compact">' + legHead + legs + '</table></div><p class="note">' + (hasVg ? "Options: \\(N_i=D\\,w_i\\,V^{*}/(\\mathcal V_i\\,A_i\\,10^{-4})\\), \\(V^{*}=" + fmt(o.vega, 0) + "\\) per bp vol. " : "") + (hasDv ? "DV01-sized option legs: \\(N_i A_i 10^{-4}=D\\,w_i\\,\\text{DV01}^{*}\\), not delta-hedged. " : "") + (hasFut ? "Futures: DV01 \\(=D\\,w_i\\,\\text{DV01}^{*}\\), \\(\\text{DV01}^{*}=" + fmt(o.dv01, 0) + "\\) per bp; long = receive." : "") + "</p>";
    h += '<div class="kpis" style="grid-template-columns:repeat(3,minmax(0,1fr))">' + kpi("Total P&L", money(st.total), "after costs") + kpi("Sharpe", fmt(st.sharpe, 2), "luck SR₀ " + fmt(R.luckSharpe(S.N, S.T), 2)) + kpi("Gates", gl.filter(function (q) { return q[2]; }).length + " / 5", st.n + " trades · hit " + (isFinite(st.hit) ? fmt(st.hit * 100, 0) + "%" : "–")) + "</div>";
    h += '<table class="tbl">' + gl.map(function (q) { return "<tr><td><b>" + q[0] + "</b></td><td>" + esc(q[1]) + '</td><td><span class="tag ' + (q[2] ? "pass" : "fail") + '">' + (q[2] ? "pass" : "fail") + "</span></td></tr>"; }).join("") + "</table>";
    var rb = r.rob || X3.robust(bt.daily, o.from);
    h += '<p class="note" style="margin-top:8px">Non-parametric ratios on the ' + rb.months + ' of ' + rb.blocks + ' non-overlapping 21-day blocks with a position (§8): median ÷ IQR ' + fmt(rb.npSharpe, 2) + ' · Sterling (median ÷ median loss) ' + fmt(rb.sterling, 2) + ' · drawdown ratio (median ÷ 5th percentile) ' + fmt(rb.ddRatio, 2) + ".</p></div>";
    h += "<div>" + U.line({ x: x, series: [{ y: cum, color: "#2F5BEA", name: "This idea (k)", area: true, width: 2.2 }, { y: bcum, color: "#98A2B3", name: "Benchmark (k)", dash: "5 4" }], xf: xf, zero: true, h: 220, yl: "cumulative P&L after costs, thousands", label: "Cumulative P&L" }) + U.legend([["This idea", "#2F5BEA"], ["Benchmark: " + BMNAME[c.bm] + ", " + c.ccy.slice(0, 3) + ", scaled to the same daily volatility", "#98A2B3", 1]]);
    h += U.line({ x: x, series: [{ y: sc, color: U.FAMCOL[c.fam], name: "z" }], hlines: [{ y: o.zin, label: "+entry" }, { y: -o.zin, label: "−entry" }], xf: xf, h: 180, yl: "signal z", label: "Signal" });
    var isOpt = c.asset === "vol" || c.asset === "sopt", attrC = isOpt ? ["Theta", "Gamma", "Vega", "Residual", "Δ+hedge"].concat(cmp.rates ? ["Unhedged Δ"] : []).concat(cmp.carry ? ["Carry"] : []).concat(["Costs"]) : ["Rates", "Carry", "Costs"];
    var attrV = isOpt ? [cmp.theta, cmp.gamma, cmp.vega, cmp.resid, cmp.hedge].concat(cmp.rates ? [cmp.rates] : []).concat(cmp.carry ? [cmp.carry] : []).concat([cmp.cost]) : [cmp.rates, cmp.carry, cmp.cost];
    h += U.bars({ cats: attrC, series: [{ name: "P&L", y: attrV.map(function (v) { return v / 1e3; }), color: function (v) { return v >= 0 ? "#2F5BEA" : "#D92D20"; } }], h: 190, yl: "P&L attribution (§7), thousands", tf: function (v) { return fmt(v, 0) + "k"; } }) + "</div></div>";
    return h + "</div>";
  }

  // ================================================================ STATS
  function renderStats() {
    var S = ST.scan, res = S.res, T = S.T, luck = R.luckSharpe(S.N, T), sd0 = Math.sqrt(252 / T);
    var srs = res.map(function (r) { return r.st.sharpe; }).filter(isFinite).sort(function (a, b) { return a - b; });
    var med = srs[Math.floor(srs.length / 2)], above = srs.filter(function (v) { return v > luck; }).length, all4 = res.filter(function (r) { return r.st.passed === 4; }).length;
    var highBeta = res.filter(function (r) { return r.st.sharpe > 0.5 && Math.abs(r.st.beta) > 0.3; }).length;
    $("#st-kpis").innerHTML = kpi("Candidates N", String(S.N), T + " test days", true) + kpi("Luck Sharpe SR₀", fmt(luck, 2), "expected best with no skill") + kpi("Beat SR₀", String(above), "candidates") + kpi("Pass gates 2–5", String(all4), "of " + S.N) + kpi("Median Sharpe", fmt(med, 2), "all candidates") + kpi("Disguised beta", String(highBeta), "Sharpe > 0.5 with |β| > 0.3");
    $("#st-hist").innerHTML = U.histogram({ values: srs, bins: 36, lo: Math.min(-2.5, srs[0]), hi: Math.max(2.5, srs[srs.length - 1]), density: function (x) { return Math.exp(-0.5 * x * x / (sd0 * sd0)) / (sd0 * Math.sqrt(2 * Math.PI)); }, vlines: [{ x: luck, color: "#DC6803", label: "SR₀ " + fmt(luck, 2) }], color: function (x) { return x > luck ? "#079455" : "#2F5BEA"; }, xl: "annualised Sharpe", h: 260 });
    $("#st-scatter").innerHTML = U.scatter({ points: res.map(function (r) { return { x: r.st.beta, y: r.st.sharpe, color: U.FAMCOL[r.cand.fam], id: r.cand.id, r: r.st.passed === 4 ? 6 : 3.8, tip: "<b>" + esc(r.cand.name) + "</b><div>Sharpe " + fmt(r.st.sharpe, 2) + " · β " + fmt(r.st.beta, 2) + " · α t " + fmt(r.st.alphaT, 1) + "</div>" }; }), hlines: [{ y: luck, color: "#DC6803", label: "luck SR₀" }], xl: "β to own benchmark (vol: short straddle · futures: long 10y)", yl: "Sharpe", h: 300 });
    $("#st-scatter-leg").innerHTML = U.legend(FAMS.map(function (f) { return [famLabel(f) + " " + R.FAM[f], U.FAMCOL[f]]; }));
    var s1 = res.filter(function (r) { return r.st.g[1]; }), s2 = s1.filter(function (r) { return r.st.g[2]; }), s3 = s2.filter(function (r) { return r.st.g[3]; }), s4 = s3.filter(function (r) { return r.st.g[4]; });
    $("#st-funnel").innerHTML = U.bars({ cats: ["All", "NW t > 2", "+ α t > 2", "+ robust", "+ tail"], series: [{ name: "candidates", y: [res.length, s1.length, s2.length, s3.length, s4.length], color: function (v, i) { return ["#C0C8D8", "#8098F9", "#5B7BEF", "#2F5BEA", "#079455"][i]; } }], h: 240, yl: "candidates surviving", labels: true, tf: function (v) { return fmt(v, 0); } });
    // family × currency best Sharpe
    var cc = ["GBP", "EUR", "USD"], h = '<table class="tbl"><tr><th>Family</th>' + cc.map(function (c) { return '<th class="num">' + c + "</th>"; }).join("") + "</tr>";
    FAMS.forEach(function (f) {
      h += "<tr><td>" + famChip(f) + " " + esc(R.FAM[f]) + "</td>" + cc.map(function (c) {
        var g = res.filter(function (r) { return r.cand.fam === f && r.cand.ccy.slice(0, 3) === c; }); if (!g.length) return '<td class="num">–</td>';
        var b = g.reduce(function (a, r) { return r.st.sharpe > a.st.sharpe ? r : a; }), ok = g.some(function (r) { return r.st.passed === 4; }), col = U.pnlColor(b.st.sharpe, 2.5);
        return '<td class="num" style="background:' + col.bg + ";color:" + col.fg + (ok ? ";box-shadow:inset 0 0 0 2.5px #101828;font-weight:700" : "") + '" data-tip="' + esc("<b>" + esc(b.cand.name) + "</b><div>best Sharpe " + fmt(b.st.sharpe, 2) + " of " + g.length + "</div>") + '">' + fmt(b.st.sharpe, 2) + "</td>";
      }).join("") + "</tr>";
    });
    $("#st-famccy").innerHTML = h + "</table>";
    var fh = '<table class="tbl"><tr><th>Family</th><th class="num">N</th><th class="num">Mean SR</th><th class="num">Median SR</th><th class="num">% SR &gt; 0</th><th class="num">NW t &gt; 2</th><th class="num">α t &gt; 2</th><th class="num">All 4 gates</th><th class="num">Mean β</th><th class="num">Avg trades</th><th class="num">Avg hit</th></tr>';
    FAMS.forEach(function (f) {
      var g = res.filter(function (r) { return r.cand.fam === f; }); if (!g.length) return;
      var sr = g.map(function (r) { return r.st.sharpe; }).filter(isFinite).sort(function (a, b) { return a - b; }), mean = function (a) { return a.reduce(function (x, y) { return x + y; }, 0) / a.length; };
      fh += "<tr><td>" + famChip(f) + " " + esc(R.FAM[f]) + '</td><td class="num">' + g.length + '</td><td class="num ' + cls(mean(sr)) + '">' + fmt(mean(sr), 2) + '</td><td class="num">' + fmt(sr[Math.floor(sr.length / 2)], 2) + '</td><td class="num">' + fmt(100 * sr.filter(function (v) { return v > 0; }).length / sr.length, 0) + '%</td><td class="num">' + g.filter(function (r) { return r.st.nwt > 2; }).length + '</td><td class="num">' + g.filter(function (r) { return r.st.alphaT > 2; }).length + '</td><td class="num">' + g.filter(function (r) { return r.st.passed === 4; }).length + '</td><td class="num">' + fmt(mean(g.map(function (r) { return r.st.beta; })), 2) + '</td><td class="num">' + fmt(mean(g.map(function (r) { return r.st.n; })), 0) + '</td><td class="num">' + fmt(100 * mean(g.map(function (r) { return r.st.hit || 0; })), 0) + "%</td></tr>";
    });
    $("#st-fam").innerHTML = fh + "</table>";
  }

  // ================================================================ FUTURES
  function zCell(id, d) {
    var r = cand(id); if (!r) return '<td class="num">–</td>';
    var z = r.cand.score[d], col = U.pnlColor(z, 2.5), live = Math.abs(z) >= ST.scan.o.zin;
    return '<td class="num" data-idea="' + esc(id) + '" style="cursor:pointer;background:' + col.bg + ";color:" + col.fg + (live ? ";font-weight:700" : "") + '" data-tip="' + esc("<b>" + esc(r.cand.name) + "</b><div>z " + fmt(z, 2) + " · backtest Sharpe " + fmt(r.st.sharpe, 2) + "</div><div>Click to open</div>") + '">' + fmt(z, 2) + "</td>";
  }
  function renderFutures() {
    var md = ST.md, fu = ST.fu, c = fu.ccy, d = fu.d, o = ST.scan.o;
    $("#fu-ccy").innerHTML = md.ccys.map(function (x) { return '<button type="button" data-c="' + x + '"' + (x === c ? ' class="on"' : "") + ">" + x + "</button>"; }).join("");
    var sl = $("#fu-date"); sl.min = o.from; sl.max = md.n - 1; sl.value = d; $("#fu-datelbl").textContent = md.dates[d];
    var hasS = md.stir && md.stir[c], hasB = md.bond && md.bond[c];
    if (!hasS && !hasB) { $("#fu-kpis").innerHTML = ""; $("#fu-body").innerHTML = '<div class="card empty">No futures data for ' + c + ". Load a futures CSV on the Data page.</div>"; return; }
    var d1 = Math.max(0, d - 21), d3 = Math.max(0, d - 63), H = X.HS, k = "";
    if (hasS) k += kpi(X.SNAME[c] + " front (3m)", fmt(X.stir(md, c, d, 0.25) / 100, 3) + "%", "price " + fmt(100 - X.stir(md, c, d, 0.25) / 100, 3), true) + kpi("Strip slope 3y − 3m", fmt(X.stir(md, c, d, 3) - X.stir(md, c, d, 0.25), 1) + "bp", "21d change " + fmt((X.stir(md, c, d, 3) - X.stir(md, c, d, 0.25)) - (X.stir(md, c, d1, 3) - X.stir(md, c, d1, 0.25)), 1) + "bp");
    if (hasB) {
      var b = md.bt[c], T10 = b.indexOf(10) >= 0 ? 10 : b[b.length - 1], y10 = X.bond(md, c, d, T10), rp = X.repo(md, c, d);
      k += kpi((X.BNAME[c][T10] || T10 + "y") + " yield", fmt(y10 / 100, 3) + "%", "21d " + fmt(y10 - X.bond(md, c, d1, T10), 1) + "bp") + kpi("Curve " + b[0] + "s" + T10 + "s", fmt(y10 - X.bond(md, c, d, b[0]), 1) + "bp", "repo ≈ " + fmt(rp / 100, 2) + "%") +
        kpi("Carry + roll, " + T10 + "y", fmt((y10 - rp) * 0.25 / X.dur(y10, T10) + (y10 - X.bond(md, c, d, T10 - 0.25)), 1) + "bp/qtr", "of yield, per DV01");
    }
    $("#fu-kpis").innerHTML = k;
    var h = '<div class="grid g2">';
    if (hasS) {
      var x = H.map(function (_, i) { return i; }), s0 = H.map(function (q) { return X.stir(md, c, d, q) / 100; }), s1 = H.map(function (q) { return X.stir(md, c, d1, q) / 100; }), s3 = H.map(function (q) { return X.stir(md, c, d3, q) / 100; });
      h += '<div class="card"><div class="card-h"><div><h3>' + X.SNAME[c] + ' strip</h3><p class="sub">Implied 3m rate by contract horizon (100 − price). Today against 1 and 3 months ago.</p></div></div>' +
        U.line({ x: x, series: [{ y: s0, color: "#2F5BEA", name: md.dates[d], width: 2.4 }, { y: s1, color: "#98A2B3", name: "21d ago", dash: "5 4" }, { y: s3, color: "#DC6803", name: "63d ago", dash: "2 3" }], xf: function (v) { return X.hLbl(H[Math.round(v)] || 0); }, xticks: 12, h: 240, yl: "implied rate, %", yf: function (v) { return fmt(v, 2); }, tf: function (v) { return fmt(v, 3) + "%"; } }) +
        U.legend([["Today", "#2F5BEA"], ["21 days ago", "#98A2B3", 1], ["63 days ago", "#DC6803", 1]]);
      h += '<div class="scroll-x"><table class="tbl compact" style="margin-top:8px"><tr><th>Horizon</th><th class="num">Price</th><th class="num">Roll/q</th><th class="num" title="F1 carry">F1</th><th class="num" title="F2 trend">F2</th><th class="num" title="F3 calendar">F3</th><th class="num" title="F4 fly">F4</th><th class="num" title="F5 regression fly">F5</th></tr>';
      [0.5, 1, 1.5, 2, 2.5].forEach(function (q) {
        var rt = X.stir(md, c, d, q);
        h += "<tr><td><b>" + X.hLbl(q) + '</b></td><td class="num">' + fmt(100 - rt / 100, 3) + '</td><td class="num">' + fmt(rt - X.stir(md, c, d, q - 0.25), 1) + "</td>" + zCell("F1." + c + q, d) + zCell("F2." + c + q, d) + zCell("F3." + c + q, d) + zCell("F4." + c + q, d) + zCell("F5." + c + X.hLbl(q), d) + "</tr>";
      });
      h += '</table></div><p class="note">F1 carry · F2 trend · F3 calendar · F4 1:2:1 butterfly · F5 regression-weighted butterfly. Cells show today\'s z: green buys the structure, red sells it, bold is past the entry level. Roll/q is the quarterly roll-down in bp. Click a cell to open the idea.</p></div>';
    }
    if (hasB) {
      var bt = md.bt[c], y0 = bt.map(function (T) { return X.bond(md, c, d, T) / 100; }), y1 = bt.map(function (T) { return X.bond(md, c, d1, T) / 100; }), y3 = bt.map(function (T) { return X.bond(md, c, d3, T) / 100; });
      h += '<div class="card"><div class="card-h"><div><h3>Bond futures curve</h3><p class="sub">CTD-equivalent yields of the ' + c + ' futures: ' + bt.map(function (T) { return X.BNAME[c][T] || T + "y"; }).join(", ") + ".</p></div></div>" +
        U.line({ x: bt, series: [{ y: y0, color: "#2F5BEA", name: md.dates[d], width: 2.4 }, { y: y1, color: "#98A2B3", name: "21d ago", dash: "5 4" }, { y: y3, color: "#DC6803", name: "63d ago", dash: "2 3" }], xf: function (v) { return v + "y"; }, h: 240, yl: "yield, %", yf: function (v) { return fmt(v, 2); }, tf: function (v) { return fmt(v, 3) + "%"; } }) +
        U.legend([["Today", "#2F5BEA"], ["21 days ago", "#98A2B3", 1], ["63 days ago", "#DC6803", 1]]);
      h += '<div class="scroll-x"><table class="tbl compact" style="margin-top:8px"><tr><th>Future</th><th class="num">Yield</th><th class="num">Dur.</th><th class="num">Carry+roll/q</th><th class="num" title="B1 trend">B1</th><th class="num" title="B2 carry">B2</th><th class="num" title="B8 trend and carry">B8</th><th class="num" title="Swap minus bond yield">Swap sprd</th><th class="num" title="B6 swap spread signal">B6</th></tr>';
      bt.forEach(function (T) {
        var y = X.bond(md, c, d, T), rp2 = X.repo(md, c, d);
        h += "<tr><td><b>" + esc(X.BNAME[c][T] || T + "y") + '</b> <span class="note">' + T + 'y</span></td><td class="num">' + fmt(y / 100, 3) + '%</td><td class="num">' + fmt(X.dur(y, T), 2) + '</td><td class="num">' + fmt((y - rp2) * 0.25 / X.dur(y, T) + (y - X.bond(md, c, d, T - 0.25)), 1) + "bp</td>" + zCell("B1." + c + T, d) + zCell("B2." + c + T, d) + zCell("B8." + c + T, d) + '<td class="num">' + (md.swap && md.swap[c] ? fmt(X.swapR(md, c, d, T) - y, 1) : "–") + "</td>" + zCell("B6." + c + T, d) + "</tr>";
      });
      h += "</table></div>";
      var rv = ST.scan.res.filter(function (r) { return ["B3", "B4", "B5", "B7", "B9"].indexOf(r.cand.fam) >= 0 && r.cand.ccy.indexOf(c) >= 0; });
      h += '<table class="tbl" style="margin-top:10px"><tr><th>Curve, fly and cross-market</th><th class="num">z today</th><th class="num">Sharpe</th><th>Gates</th></tr>' + rv.map(function (r) { return '<tr class="row" data-idea="' + esc(r.cand.id) + '"><td>' + famChip(r.cand.fam) + " " + esc(r.cand.name) + "</td>" + zCell(r.cand.id, d).replace(' data-idea="' + esc(r.cand.id) + '"', "") + '<td class="num">' + fmt(r.st.sharpe, 2) + "</td><td>" + gates(r.st) + "</td></tr>"; }).join("") + "</table></div>";
    }
    h += "</div>";
    h += soPanel(md, c, d);
    // live futures ideas
    var live = ST.scan.res.filter(function (r) { return (r.cand.asset === "stir" || r.cand.asset === "bond" || r.cand.asset === "sopt") && r.cand.ccy.indexOf(c) >= 0 && Math.abs(r.cand.score[d]) >= o.zin; }).sort(function (a, b2) { return b2.st.passed - a.st.passed || b2.st.sharpe - a.st.sharpe; });
    h += '<div class="card mt"><div class="card-h"><div><h3>Live futures, swap and STIR-option ideas in ' + c + ' on ' + md.dates[d] + '</h3><p class="sub">Ranked by backtest gates, then Sharpe. Click to open.</p></div></div>' + (live.length ? '<table class="tbl"><tr><th>Family</th><th>Idea</th><th class="num">z</th><th>P&amp;L path</th><th class="num">Sharpe</th><th class="num">α t</th><th>Gates</th></tr>' + live.map(function (r) {
      var z = r.cand.score[d], sd = z > 0 ? "buy" : "sell";
      return '<tr class="row" data-idea="' + esc(r.cand.id) + '"><td>' + famChip(r.cand.fam) + '</td><td><span class="side-tag ' + sd + '">' + sd + "</span> " + esc((z > 0 ? r.cand.longTxt : r.cand.shortTxt).replace(/^(buy|sell)\s/, "")) + '</td><td class="num ' + (z > 0 ? "pos" : "neg") + '">' + fmt(z, 2) + "</td><td>" + U.spark(r.spark) + '</td><td class="num">' + fmt(r.st.sharpe, 2) + '</td><td class="num">' + fmt(r.st.alphaT, 1) + "</td><td>" + gates(r.st) + "</td></tr>";
    }).join("") + "</table>" : '<div class="empty">No futures signal past the entry level on this date.</div>') + "</div>";
    $("#fu-body").innerHTML = h;
  }
  function soPanel(md, c, d) { // STIR options: implied vs ageing-adjusted fair, same-contract term structure (§4d)
    if (!md.so || !md.so[c] || !md.stir || !md.stir[c]) return "";
    var OT = X.OT, H = X.HS, sel = ST.fu.soH, lim = 2.5, oname = function (t) { return X.hLbl(t); };
    var h = '<div class="grid g2 mt"><div class="card"><div class="card-h"><div><h3>' + X3.CODE[c] + ' options: implied vs ageing-adjusted fair</h3><p class="sub">Rows: the contract whose reference period starts in H years. Columns: option expiry τ. Number: implied normal vol (bp). Small figure: implied ÷ fair − 1, where fair integrates the realised-variance forecast along the contract\'s path to expiry (§4d). Colour: that richness as a z-score against its own last year. Click a row for its term structure.</p></div></div>';
    h += '<div class="hm" style="grid-template-columns:52px repeat(' + OT.length + ',minmax(0,1fr))"><div></div>' + OT.map(function (t) { return '<div class="hd">' + oname(t) + "</div>"; }).join("");
    H.forEach(function (hh) {
      if (hh < 0.5) return;
      h += '<div class="rl" data-soh="' + hh + '" style="cursor:pointer' + (hh === sel ? ';font-weight:700' : "") + '">' + X.hLbl(hh) + "</div>";
      OT.forEach(function (t) {
        if (t > hh + 1e-9) { h += '<div class="c" style="background:transparent"></div>'; return; }
        var iv = X3.soIV(md, c, d, hh, t), fv = X3.soFair(md, c, d, hh, t), rr = iv / fv - 1, zz = X3.soRichZ(md, c, hh, t)[d], cc = U.divColor(zz, lim);
        h += '<div class="c' + (hh === sel ? " sel" : "") + '" data-soh="' + hh + '" style="background:' + cc.bg + ";color:" + cc.fg + '" data-tip="' + esc("<b>" + X3.CODE[c] + " " + X.hLbl(hh) + " contract, " + oname(t) + " option</b><div>Implied " + fmt(iv, 1) + "bp · fair " + fmt(fv, 1) + "bp · ratio " + fmt(iv / fv, 2) + "× · richness z " + fmt(zz, 2) + "</div>") + '"><b>' + fmt(iv, 0) + "</b><small>" + (rr > 0 ? "+" : "") + fmt(100 * rr, 0) + "%</small></div>";
      });
    });
    h += '</div><div class="scale"><span>cheaper than usual</span><span class="bar" style="background:linear-gradient(90deg,rgb(24,100,171),rgb(246,247,250),rgb(196,64,22))"></span><span>richer than usual</span><span style="margin-left:auto">colour scale ±2.5 sd</span></div></div>';
    var ts = OT.filter(function (t) { return t <= sel + 1e-9; }), xi = ts.map(function (_, i) { return i; });
    var iv2 = ts.map(function (t) { return X3.soIV(md, c, d, sel, t); }), fv2 = ts.map(function (t) { return X3.soFair(md, c, d, sel, t); });
    h += '<div class="card"><div class="card-h"><div><h3>' + X3.CODE[c] + ' ' + X.hLbl(sel) + ' contract: one underlying, several expiries</h3><p class="sub">Implied vs the ageing-adjusted fair vol for each expiry on this contract. Where the gap differs by expiry, O2 trades it theta-neutral.</p></div></div>' +
      U.line({ x: xi, series: [{ y: iv2, color: "#2F5BEA", name: "Implied", width: 2.4 }, { y: fv2, color: "#98A2B3", name: "Fair", dash: "5 4", width: 2 }], xf: function (v) { return oname(ts[Math.round(v)] || 0); }, xticks: ts.length, h: 220, yl: "normal vol, bp", label: "Term structure" }) + U.legend([["Implied", "#2F5BEA"], ["Fair: realised forecast along the contract's ageing path", "#98A2B3", 1]]);
    var rows = ST.scan.res.filter(function (r) { return r.cand.asset === "sopt" && r.cand.ccy === c; }).sort(function (a, b) { return Math.abs(b.cand.score[d] || 0) - Math.abs(a.cand.score[d] || 0); }).slice(0, 10);
    h += '<table class="tbl compact" style="margin-top:8px"><tr><th>STIR-option signals (largest |z|)</th><th class="num">z</th><th class="num">Sharpe</th><th>Gates</th></tr>' + rows.map(function (r) { return '<tr class="row" data-idea="' + esc(r.cand.id) + '"><td>' + famChip(r.cand.fam) + " " + esc(shortName(r.cand)) + "</td>" + zCell(r.cand.id, d).replace(' data-idea="' + esc(r.cand.id) + '"', "") + '<td class="num">' + fmt(r.st.sharpe, 2) + "</td><td>" + gates(r.st) + "</td></tr>"; }).join("") + "</table></div></div>";
    return h;
  }

  // ================================================================ PORTFOLIO (walk-forward selection, live book)
  function renderPortfolio() {
    var md = ST.md, S = ST.scan, o = S.o, wf = ST.wf, P = ST.pf;
    $("#pf-k").value = P.K; $("#pf-step").value = P.step; $("#pf-look").value = P.look; $("#pf-fam").value = P.maxFam; $("#pf-corr").value = P.maxCorr;
    if (!wf) { $("#pf-body").innerHTML = '<div class="card empty">Not enough history for a walk-forward test (needs warm-up, look-back and one more quarter).</div>'; $("#pf-kpis").innerHTML = ""; return; }
    var so = wf.st.oos, sh = wf.st.hind, sn = wf.st.naive, dsr = R.dsr(so.sharpe, md.n - wf.start, 1);
    $("#pf-kpis").innerHTML = kpi("Out-of-sample Sharpe", fmt(so.sharpe, 2), "NW t " + fmt(so.nwt, 2) + " · from " + md.dates[wf.start], true) + kpi("Hindsight Sharpe", fmt(sh.sharpe, 2), "same rule, picks chosen on the full sample") +
      kpi("Selection decay", fmt(sh.sharpe - so.sharpe, 2), "hindsight − out-of-sample Sharpe") + kpi("Max drawdown", money(so.dd), "worst 20d " + money(so.w20)) + kpi("Names replaced", fmt(100 * wf.turnover, 0) + "%", "per rebalance, every " + wf.step + " days");
    var x = [], a = [], b = [], c2 = [], ca = 0, cb = 0, cc = 0, last = md.n - 1;
    for (var d = wf.start; d < md.n; d++) { ca += wf.oos[d]; cb += wf.hind[d]; cc += wf.naive[d]; x.push(d); a.push(ca / 1e3); b.push(cb / 1e3); c2.push(cc / 1e3); }
    var xf = function (v, full) { var dd = md.dates[Math.max(0, Math.min(last, Math.round(v)))]; return dd ? (full ? dd : dd.slice(0, 7)) : ""; };
    var h = '<div class="grid g2"><div class="card"><div class="card-h"><div><h3>Cumulative P&amp;L of the selection rule</h3><p class="sub">Every ' + wf.step + ' days, pick the ' + wf.K + ' candidates with the best trailing ' + wf.look + '-day Sharpe (at most ' + P.maxFam + ' per family, skipping any whose trailing correlation with an earlier pick exceeds ' + fmt(wf.maxCorr, 2) + '), size them to equal trailing risk and hold to the next rebalance. Out-of-sample uses only data before each rebalance; hindsight picks once, on the full sample.</p></div></div>' +
      U.line({ x: x, series: [{ y: a, color: "#2F5BEA", name: "Out-of-sample", area: true, width: 2.4 }, { y: b, color: "#98A2B3", name: "Hindsight", dash: "5 4" }, { y: c2, color: "#DC6803", name: "All candidates", dash: "2 3" }], xf: xf, zero: true, h: 260, yl: "cumulative P&L after costs, thousands", label: "Walk-forward" }) +
      U.legend([["Out-of-sample selection", "#2F5BEA"], ["Hindsight (look-ahead, not tradable)", "#98A2B3", 1], ["Every candidate, equal risk", "#DC6803", 1]]);
    h += '<div class="scroll-x"><table class="tbl" style="margin-top:8px"><tr><th></th><th class="num">Sharpe</th><th class="num">NW t</th><th class="num">Total</th><th class="num">Max DD</th><th class="num">Median ÷ IQR</th><th class="num">Sterling</th><th class="num">DD ratio</th></tr>' + [["Out-of-sample", so], ["Hindsight", sh], ["All, equal risk", sn]].map(function (q) { var s = q[1]; return "<tr><td><b>" + q[0] + '</b></td><td class="num">' + fmt(s.sharpe, 2) + '</td><td class="num">' + fmt(s.nwt, 2) + '</td><td class="num ' + cls(s.total) + '">' + money(s.total) + '</td><td class="num">' + money(s.dd) + '</td><td class="num">' + fmt(s.rob.npSharpe, 2) + '</td><td class="num">' + fmt(s.rob.sterling, 2) + '</td><td class="num">' + fmt(s.rob.ddRatio, 2) + "</td></tr>"; }).join("") + "</table></div>";
    h += '<p class="note">Probability that the out-of-sample Sharpe is above zero, after non-normality is ignored (DSR with one trial): ' + fmt(dsr, 3) + '. Only the selection rule is chosen here, so the out-of-sample line is the fair estimate of what the screen is worth (§11).</p></div>';
    var cur = wf.picks[wf.picks.length - 1], ids = cur.sel.map(function (q) { return { id: q.id, w: q.w }; });
    h += '<div class="card"><div class="card-h"><div><h3>Book at the last rebalance (' + md.dates[cur.d] + ')</h3><p class="sub">Weight is the risk scale applied to each idea\'s backtest. "Today" shows whether its signal is on now.</p></div></div><div class="scroll-x"><table class="tbl"><tr><th>Idea</th><th class="num">Trailing SR</th><th class="num">Weight</th><th class="num">z today</th><th>Today</th></tr>' + cur.sel.map(function (q) {
      var r = S.byId[q.id], z = r.cand.score[last], sd = z >= o.zin ? "buy" : z <= -o.zin ? "sell" : "flat";
      return '<tr class="row" data-idea="' + esc(q.id) + '"><td>' + famChip(r.cand.fam) + " " + ccyChip(r.cand.ccy) + " " + esc(shortName(r.cand)) + '</td><td class="num">' + fmt(q.sr, 2) + '</td><td class="num">' + fmt(q.w, 2) + '</td><td class="num">' + fmt(z, 2) + '</td><td><span class="side-tag ' + sd + '">' + sd + "</span></td></tr>";
    }).join("") + "</table></div>";
    var lb = X3.liveBook(md, S, ids), cc3 = Object.keys(lb.agg);
    h += '<h3 class="mt">Risk of the live part of the book today</h3><p class="sub">Picks with a live signal only, at their weights. Vega: money per bp of normal vol. DV01: money per bp, positive = long duration. Gamma: money per bp².</p>' + (cc3.length ? '<div class="scroll-x"><table class="tbl compact"><tr><th>Ccy</th><th class="num">Swaption vega ≤1y</th><th class="num">Swaption vega &gt;1y</th><th class="num">STIR-option vega</th><th class="num">Gamma</th><th class="num">DV01</th></tr>' + cc3.map(function (k) { var g = lb.agg[k]; return "<tr><td>" + ccyChip(k) + '</td><td class="num ' + cls(g.vegaS) + '">' + fmt(g.vegaS, 0) + '</td><td class="num ' + cls(g.vegaL) + '">' + fmt(g.vegaL, 0) + '</td><td class="num ' + cls(g.soVega) + '">' + fmt(g.soVega, 0) + '</td><td class="num">' + fmt(g.gamma, 1) + '</td><td class="num ' + cls(g.dv01) + '">' + fmt(g.dv01, 0) + "</td></tr>"; }).join("") + "</table></div>" : '<div class="empty">None of the current picks has a live signal today.</div>') + "</div></div>";
    var M = X3.corrMatrix(md, S, ids.map(function (q) { return q.id; }), 252), n = ids.length, avg = 0, k2 = 0;
    M.forEach(function (row, i) { row.forEach(function (v, j) { if (i !== j && isFinite(v)) { avg += Math.abs(v); k2++; } }); });
    h += '<div class="grid g2 mt"><div class="card"><div class="card-h"><div><h3>Correlation of the picks\' daily P&amp;L, last year</h3><p class="sub">Blue negative, red positive. Average |ρ| off the diagonal: ' + fmt(avg / Math.max(1, k2), 2) + '.</p></div></div><div class="scroll-x"><div class="hm" style="min-width:520px;grid-template-columns:150px repeat(' + n + ',minmax(0,1fr))"><div></div>' + ids.map(function (q, i) { return '<div class="hd" title="' + esc(q.id) + '">' + (i + 1) + "</div>"; }).join("");
    M.forEach(function (row, i) { h += '<div class="rl" title="' + esc(ids[i].id) + '" style="font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;text-align:left">' + (i + 1) + " " + esc(ids[i].id) + "</div>" + row.map(function (v) { var col = U.divColor(v, 1); return '<div class="c" style="background:' + col.bg + ";color:" + col.fg + ';font-size:11px"><b>' + fmt(v, 1) + "</b></div>"; }).join(""); });
    h += "</div></div></div>";
    var fams = {}; wf.picks.forEach(function (p) { p.sel.forEach(function (q) { var f = S.byId[q.id].cand.fam; fams[f] = (fams[f] || 0) + 1; }); });
    var fk = Object.keys(fams).sort(function (p, q) { return fams[q] - fams[p]; });
    h += '<div class="card"><div class="card-h"><div><h3>What the rule picked, by family</h3><p class="sub">Times each family was in the book over ' + wf.picks.length + ' rebalances. A screen that keeps choosing one family is one trade, not a portfolio.</p></div></div>' +
      U.bars({ cats: fk.map(famLabel), series: [{ name: "picks", y: fk.map(function (f) { return fams[f]; }), color: function (v, i) { return U.FAMCOL[fk[i]]; } }], h: 240, yl: "times selected", labels: true, tf: function (v) { return fmt(v, 0); } }) + "</div></div>";
    $("#pf-body").innerHTML = h;
  }
  function futTemplate() {
    var md = R.generate(27); X.genFutures(md, 27); var L = ["date,ccy,type,tenor,rate_pct"];
    for (var d = md.n - 3; d < md.n; d++) md.ccys.forEach(function (c) { X.HS.forEach(function (h) { L.push([md.dates[d], c, "STIR", h, (X.stir(md, c, d, h) / 100).toFixed(4)].join(",")); }); md.bt[c].forEach(function (T) { L.push([md.dates[d], c, "BOND", T, (X.bond(md, c, d, T) / 100).toFixed(4)].join(",")); }); });
    X3.genSwap(md, 27); for (d = md.n - 3; d < md.n; d++) md.ccys.forEach(function (c) { md.bt[c].forEach(function (T) { L.push([md.dates[d], c, "SWAP", T, (X.swapR(md, c, d, T) / 100).toFixed(4)].join(",")); }); });
    download("rv-finder-futures-template.csv", L.join("\n") + "\n");
  }
  function soTemplate() {
    var md = R.generate(27); X.genFutures(md, 27); X3.genSopt(md, 27); var L = ["date,ccy,horizon_y,expiry_y,vol_bp"];
    for (var d = md.n - 3; d < md.n; d++) md.ccys.forEach(function (c) { X.HS.forEach(function (h) { X.OT.forEach(function (t) { if (t <= h + 1e-9) L.push([md.dates[d], c, h, +t.toFixed(4), X.soVol(md, c, d, h, t).toFixed(2)].join(",")); }); }); });
    download("rv-finder-stir-options-template.csv", L.join("\n") + "\n");
  }

  // ================================================================ exports
  function download(name, text) { var a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([text], { type: "text/csv" })); a.download = name; document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500); }
  function exportResults() {
    var S = ST.scan; if (!S) return; var q = function (v) { return '"' + String(v).replace(/"/g, '""') + '"'; }, n = function (v, d) { return isFinite(v) ? v.toFixed(d) : ""; };
    var L = ["id,family,family_name,ccy,idea_today,z_today,sharpe,nw_t,alpha_t,beta,trades,hit_rate,total_pnl,pnl_2x_cost,max_dd,worst_20d,tail_months,best_year_share,gates_2to5,median_over_iqr,sterling,dd_ratio,asset,benchmark"];
    S.res.forEach(function (r) { var s = r.st; L.push([q(r.cand.id), r.cand.fam, q(R.FAM[r.cand.fam]), r.cand.ccy, q(actionTxt(r, S.o)), n(r.today, 3), n(s.sharpe, 3), n(s.nwt, 3), n(s.alphaT, 3), n(s.beta, 3), s.n, n(s.hit, 3), n(s.total, 0), n(s.t2x, 0), n(s.dd, 0), n(s.w20, 0), n(s.tail, 2), n(s.maxYear, 3), s.passed, n(r.rob.npSharpe, 3), n(r.rob.sterling, 3), n(r.rob.ddRatio, 3), r.cand.asset, q(BMNAME[r.cand.bm])].join(",")); });
    download("rv-finder-results-" + ST.md.dates[ST.md.n - 1] + ".csv", L.join("\n"));
  }
  function exportTrades() {
    var r = ST.scan.byId[ST.id.sel]; if (!r) return; var md = ST.md, L = ["section,date_in,date_out,side,z_in,z_out,exit_reason,pnl"];
    r.bt.trades.forEach(function (t) { L.push(["trade", md.dates[t.d0], md.dates[t.d1], t.dir > 0 ? "long" : "short", t.s0.toFixed(3), isFinite(t.s1) ? t.s1.toFixed(3) : "", t.why, t.pnl.toFixed(0)].join(",")); });
    L.push("", "section,date,z,daily_pnl,daily_cost");
    for (var d = 0; d < md.n; d++) L.push(["daily", md.dates[d], isFinite(r.bt.score[d]) ? r.bt.score[d].toFixed(4) : "", r.bt.daily[d].toFixed(2), r.bt.cost[d].toFixed(2)].join(","));
    download("rv-finder-" + r.cand.id.replace(/[^A-Za-z0-9.]+/g, "_") + ".csv", L.join("\n"));
  }
  function template() {
    var md = R.generate(27), L = ["date,ccy,expiry,tail,fwd_pct,vol_bp,annuity,skew,curv"];
    for (var d = md.n - 3; d < md.n; d++) md.ccys.forEach(function (c) { for (var e = 0; e < NE; e++) for (var t = 0; t < NT; t++) { var x = IX(d, e, t); L.push([md.dates[d], c, EXPN[e].toUpperCase(), TAILS[t] + "Y", (md.F[c][x] / 100).toFixed(4), md.V[c][x].toFixed(2), md.A[c][x].toFixed(4), md.S[c][x].toFixed(4), md.C[c][x].toExponential(3)].join(",")); } });
    download("rv-finder-template.csv", L.join("\n") + "\n");
  }

  // ================================================================ wiring
  function openIdea(id) { ST.id.sel = id; ST.id.tab = "overview"; if ((location.hash || "").indexOf("#ideas") === 0) renderIdeas(); else location.hash = "#ideas"; setTimeout(function () { var el = $("#id-detail"); if (el) el.scrollIntoView({ behavior: "smooth", block: "start" }); }, 30); }
  function init() {
    U.renderMath(document.body);
    window.addEventListener("hashchange", route);
    $("#sf-ccy").addEventListener("click", function (e) { var b = e.target.closest("button"); if (!b) return; ST.sf.ccy = b.getAttribute("data-c"); renderSurface(); });
    $("#sf-date").addEventListener("input", function (e) { ST.sf.d = +e.target.value; renderSurface(); });
    $("#sf-today").addEventListener("click", function () { ST.sf.d = ST.md.n - 1; $("#sf-date").value = ST.sf.d; renderSurface(); });
    $("#sf-metric").addEventListener("change", function (e) { ST.sf.metric = e.target.value; renderSurface(); });
    $("#sf-heat").addEventListener("click", function (e) { var c = e.target.closest("[data-cell]"); if (!c) return; ST.sf.cell = c.getAttribute("data-cell").split(",").map(Number); renderSurface(); });
    $("#sf-ts-tail").addEventListener("click", function (e) { var b = e.target.closest("button"); if (!b) return; ST.sf.tsTail = +b.getAttribute("data-t"); renderTS(); });
    document.addEventListener("click", function (e) {
      var t = e.target.closest("[data-idea]"); if (t && !e.target.closest("#id-detail .tabs")) { e.preventDefault(); openIdea(t.getAttribute("data-idea")); return; }
      if (e.target.closest("#b-close")) { ST.id.sel = null; renderIdeas(); return; }
      var tb = e.target.closest("[data-tab]"); if (tb) { ST.id.tab = tb.getAttribute("data-tab"); renderIdeas(); return; }
      if (e.target.closest("#b-trades")) exportTrades();
    });
    $("#id-fam").addEventListener("click", function (e) { var b = e.target.closest("button"); if (!b) return; ST.id.fam = b.getAttribute("data-f"); renderIdeas(); });
    $("#id-asset").addEventListener("click", function (e) { var b = e.target.closest("button"); if (!b) return; ST.id.asset = b.getAttribute("data-a"); ST.id.fam = ""; renderIdeas(); });
    $("#fu-ccy").addEventListener("click", function (e) { var b = e.target.closest("button"); if (!b) return; ST.fu.ccy = b.getAttribute("data-c"); renderFutures(); });
    $("#fu-date").addEventListener("input", function (e) { ST.fu.d = +e.target.value; renderFutures(); });
    $("#fu-today").addEventListener("click", function () { ST.fu.d = ST.md.n - 1; renderFutures(); });
    $("#id-ccy").addEventListener("click", function (e) { var b = e.target.closest("button"); if (!b) return; ST.id.ccy = b.getAttribute("data-c"); renderIdeas(); });
    $("#id-live").addEventListener("click", function (e) { var b = e.target.closest("button"); if (!b) return; ST.id.live = b.getAttribute("data-v") === "live"; renderIdeas(); });
    $("#id-sort").addEventListener("change", function (e) { ST.id.sort = e.target.value; renderIdeas(); });
    $("#b-scan").addEventListener("click", function () { scan(); });
    $("#b-demo").addEventListener("click", function () { ST.md = null; ST.scan = null; ST.id.sel = null; files = {}; $("#dt-src").textContent = "Illustrative data (§9)."; scan(); });
    $("#b-ftpl").addEventListener("click", futTemplate);
    $("#b-sotpl").addEventListener("click", soTemplate);
    $("#fu-body").addEventListener("click", function (e) { var r = e.target.closest("[data-soh]"); if (!r) return; ST.fu.soH = +r.getAttribute("data-soh"); renderFutures(); });
    $("#pf-apply").addEventListener("click", function () { var g = function (id, lo, hi, dv) { var v = Math.round(+$(id).value); return isFinite(v) ? Math.max(lo, Math.min(hi, v)) : dv; }; var mc = parseFloat($("#pf-corr").value); ST.pf = { K: g("#pf-k", 1, 40, 10), step: g("#pf-step", 5, 252, 63), look: g("#pf-look", 63, 756, 252), maxFam: g("#pf-fam", 1, 40, 2), maxCorr: isFinite(mc) ? Math.max(0.1, Math.min(1, mc)) : 0.7 }; if (ST.scan) ST.wf = ST.md.n > ST.scan.o.from + ST.pf.look + 63 ? X3.walkForward(ST.md, ST.scan, ST.pf) : null; renderPortfolio(); });
    $("#b-tpl").addEventListener("click", template);
    $("#b-export").addEventListener("click", exportResults);
    var files = {};
    var load = function () {
      if (!files.surf) return;
      try {
        var md = R.fromCSV(files.surf, files.ev, files.sp);
        if (files.fut) X.futuresFromCSV(md, files.fut);
        if (files.so) X3.soFromCSV(md, files.so);
        if (!md.ccys.length) throw new Error("no rows matched the grid; check the column names and tenors");
        ST.md = md; ST.scan = null; ST.id.sel = null; ST.sf.ccy = null;
        $("#dt-src").textContent = "Your data: " + md.ccys.join(", ") + ", " + md.dates[0] + " to " + md.dates[md.n - 1] + " (" + md.n + " days)" + (md.hasEvents ? ", events" : "") + (Object.keys(md.spread).length ? ", spread vols" : "") + (md.hasFut ? ", futures" : "") + (md.swap && Object.keys(md.swap).length ? ", swaps" : "") + (md.hasSO ? ", STIR options" : "") + ".";
      } catch (err) { $("#dt-src").innerHTML = '<span class="neg">Could not read the file: ' + esc(err.message) + "</span>"; return; }
      scan();
    };
    [["#f-surf", "surf"], ["#f-ev", "ev"], ["#f-sp", "sp"], ["#f-fut", "fut"], ["#f-so", "so"]].forEach(function (p) { $(p[0]).addEventListener("change", function (e) { var f = e.target.files[0]; if (!f) return; var rd = new FileReader(); rd.onload = function () { files[p[1]] = rd.result; load(); }; rd.readAsText(f); }); });
    $("#dt-src").textContent = "Illustrative data (§9): six years of GBP, EUR and USD swaption surfaces, events, spread vols, STIR strips and options, bond futures and swap curves.";
    route();
    scan();
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();
