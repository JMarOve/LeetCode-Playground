// RV Finder extensions:
//  - futures data: STIR strips (SONIA SFI, Euribor ER, SOFR SR3) and bond futures curves
//  - advanced vol signals S9-S12, STIR futures F1-F4, bond futures B1-B5
//  - a generalised backtest engine: straddles, OTM payers/receivers, spread options, futures
// Every formula is written out on the Method page.
(function (W) {
  "use strict";
  var R = W.RVF, fmt = R.fmt, IX = R.IX, ET = R.ET, EXPN = R.EXPN, TAILS = R.TAILS, NE = R.NE, NT = R.NT, nn = R.nodeName;
  var HS = [0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2, 2.25, 2.5, 2.75, 3], NS = HS.length, DT = 1 / 252;
  var BT = { GBP: [2, 5, 10], EUR: [2, 5, 10, 30], USD: [2, 5, 10, 30] };
  var BNAME = { GBP: { 2: "Short Gilt", 5: "Medium Gilt", 10: "Long Gilt", 30: "Ultra Long Gilt" }, EUR: { 2: "Schatz", 5: "Bobl", 10: "Bund", 30: "Buxl" }, USD: { 2: "TU 2y", 5: "FV 5y", 10: "TY 10y", 30: "UB Ultra" } };
  var SNAME = { GBP: "SONIA (SFI)", EUR: "Euribor (ER)", USD: "SOFR (SR3)" };
  var FAMX = {
    S9: ["Skew vs realised spot-vol correlation", "vol"], S10: ["Smile wings vs vol-of-vol", "vol"], S11: ["Surface PCA residual", "vol"], S12: ["Vol momentum", "vol"],
    F1: ["STIR carry and roll-down", "stir"], F2: ["STIR trend", "stir"], F3: ["STIR calendar spread", "stir"], F4: ["STIR butterfly", "stir"],
    B1: ["Bond futures trend", "bond"], B2: ["Bond futures carry", "bond"], B3: ["Bond curve steepener/flattener", "bond"], B4: ["PCA-neutral bond butterfly", "bond"], B5: ["Cross-market spread", "bond"]
  };
  var hLbl = function (h) { return h < 1 ? Math.round(h * 12) + "m" : (h % 1 ? fmt(h, 2).replace(/0$/, "") : h) + "y"; };

  // ---------------------------------------------------------------- helpers
  function lin(xs, ys, x) { // linear interpolation with linear extrapolation at both ends
    var n = xs.length; if (n === 1) return ys[0];
    var i = 1; while (i < n - 1 && x > xs[i]) i++;
    return ys[i - 1] + (ys[i] - ys[i - 1]) * (x - xs[i - 1]) / (xs[i] - xs[i - 1]);
  }
  function nanArr(n) { var a = new Float64Array(n); a.fill(NaN); return a; }
  function rollMean(x, w, minp) { return R.roll(x, w, minp).m; }
  function rollSd(x, w, minp) { return R.roll(x, w, minp).s; }
  function stir(md, c, d, h) { return lin(HS, md.stir[c].subarray(d * NS, d * NS + NS), h); }
  function bond(md, c, d, T) { var b = md.bt[c], nb = b.length; return lin(b, md.bond[c].subarray(d * nb, d * nb + nb), T); }
  var OT = [1 / 12, 0.25, 0.5, 0.75, 1], NO = OT.length; // STIR option expiries (years)
  function swapR(md, c, d, T) { var b = md.bt[c], nb = b.length; return lin(b, md.swap[c].subarray(d * nb, d * nb + nb), T); }
  function soVol(md, c, d, H, tau) { // bilinear in (contract horizon H, option expiry tau), flat beyond the grid
    var a = md.so[c], h = Math.max(HS[0], Math.min(HS[NS - 1], H)), t = Math.max(OT[0], Math.min(OT[NO - 1], Math.min(tau, h)));
    var i = 0; while (i < NS - 2 && HS[i + 1] < h) i++; var j = 0; while (j < NO - 2 && OT[j + 1] < t) j++;
    var wh = (h - HS[i]) / (HS[i + 1] - HS[i]), wt = (t - OT[j]) / (OT[j + 1] - OT[j]), b = d * NS * NO;
    var v = function (k, q) { var x = a[b + k * NO + q]; return x === x ? x : a[b + k * NO + Math.min(q, NO - 1)]; };
    return (1 - wh) * ((1 - wt) * v(i, j) + wt * v(i, j + 1)) + wh * ((1 - wt) * v(i + 1, j) + wt * v(i + 1, j + 1));
  }
  function repo(md, c, d) { return md.stir && md.stir[c] ? stir(md, c, d, 0.125) : bond(md, c, d, 0.25); }
  function dur(yBp, T) { var y = Math.max(yBp, 1) / 1e4; return (1 - Math.pow(1 + y, -T)) / y; }
  function cache(md, k, f) { return md.cache[k] || (md.cache[k] = f()); }
  function dStir(md, c) { // fixed-maturity daily change of each strip point
    return cache(md, "dS" + c, function () { var o = nanArr(md.n * NS); for (var d = 1; d < md.n; d++) for (var k = 0; k < NS; k++) o[d * NS + k] = stir(md, c, d, HS[k] - DT) - md.stir[c][(d - 1) * NS + k]; return o; });
  }
  function dBond(md, c) {
    return cache(md, "dB" + c, function () { var b = md.bt[c], nb = b.length, o = nanArr(md.n * nb); for (var d = 1; d < md.n; d++) for (var k = 0; k < nb; k++) o[d * nb + k] = bond(md, c, d, b[k] - DT) - md.bond[c][(d - 1) * nb + k]; return o; });
  }
  function colOf(arr, n, w, k) { var o = new Float64Array(n); for (var d = 0; d < n; d++) o[d] = arr[d * w + k]; return o; }
  function rvSeries(md, kind, c, k, win) { // annualised realised vol (bp) of a strip/curve point
    return cache(md, "rv" + kind + c + k + "_" + win, function () {
      var w = kind === "S" ? NS : md.bt[c].length, dx = kind === "S" ? dStir(md, c) : dBond(md, c), sq = new Float64Array(md.n);
      for (var d = 0; d < md.n; d++) { var v = dx[d * w + k]; sq[d] = v * v; }
      var m = rollMean(sq, win, win >> 1), o = new Float64Array(md.n); for (d = 0; d < md.n; d++) o[d] = Math.sqrt(252 * m[d]); return o;
    });
  }
  function ou(r, n, hlDays, sd) { // OU path with half-life (days) and stationary sd
    var k = Math.log(2) / (hlDays / 252), sig = sd * Math.sqrt(2 * k), x = new Float64Array(n);
    for (var i = 1; i < n; i++) x[i] = x[i - 1] - k * x[i - 1] * DT + sig * Math.sqrt(DT) * r.normal();
    return x;
  }

  // ---------------------------------------------------------------- futures data (illustrative)
  function genFutures(md, seed) {
    md.stir = {}; md.bond = {}; md.bt = {}; md.HS = HS;
    md.ccys.forEach(function (c, ci) {
      if (!md.fac || !md.fac[c]) return;
      var r = R.rng((seed || 27) * 31 + 7 * ci + 3), Lv = R.LEVELS[c], L = md.fac[c].L, S = md.fac[c].S, n = md.n;
      var unit = function (m) { var ld = R.loadings(m); return { l: ld[0], s: ld[1], u: Math.sqrt(ld[0] * ld[0] + 0.2025 * ld[1] * ld[1]) }; };
      // STIR strip: 3m forward rates by horizon, sharing the swaption curve factors
      var kS = (Lv.grid[3][0] / 1.12 / Math.sqrt(1.151)) / unit(1.125).u, fly = ou(r, n, 30, 4), st = new Float64Array(n * NS);
      for (var d = 0; d < n; d++) for (var k = 0; k < NS; k++) {
        var h = HS[k], u = unit(h + 0.125);
        st[d * NS + k] = Lv.rate * 100 - 25 + 35 * (1 - Math.exp(-h / 1.5)) + kS * (u.l * L[d] + u.s * S[d]) + fly[d] * Math.exp(-Math.pow((h - 1.5) / 0.35, 2));
      }
      // bond futures: CTD-equivalent yields at constant maturity
      var b = BT[c], nb = b.length, kB = (Lv.grid[3][3] / 1.12 / Math.sqrt(1.151)) / unit(4.5).u, belly = ou(r, n, 40, 5), xm = c === "EUR" ? new Float64Array(n) : ou(r, n, 60, 8), by = new Float64Array(n * nb);
      for (d = 0; d < n; d++) for (k = 0; k < nb; k++) {
        var T = b[k], ub = unit(T * 0.45);
        by[d * nb + k] = Lv.rate * 100 - 30 + 90 * (1 - Math.exp(-T / 7)) + kB * (ub.l * L[d] + ub.s * S[d]) + (T === 5 ? belly[d] : 0) + (T === 10 ? xm[d] : 0);
      }
      md.stir[c] = st; md.bond[c] = by; md.bt[c] = b;
    });
    md.hasFut = true;
    return md;
  }

  function futuresFromCSV(md, txt) {
    var lines = String(txt).replace(/\r/g, "").split("\n").filter(function (l) { return l.trim(); });
    var head = lines.shift().split(",").map(function (h) { return h.trim().toLowerCase(); }), di = {};
    md.dates.forEach(function (d, i) { di[d] = i; });
    var rows = lines.map(function (l) { var p = l.split(","), o = {}; head.forEach(function (h, i) { o[h] = (p[i] || "").trim(); }); return o; });
    md.stir = {}; md.bond = {}; md.bt = {}; md.swap = {}; md.HS = HS;
    var ccys = {}; rows.forEach(function (o) { ccys[String(o.ccy).toUpperCase()] = 1; });
    Object.keys(ccys).forEach(function (c) {
      var st = nanArr(md.n * NS), ten = {}, brows = [], srows = [];
      rows.forEach(function (o) {
        if (String(o.ccy).toUpperCase() !== c || di[o.date] === undefined) return;
        var t = parseFloat(o.tenor), v = parseFloat(o.rate_pct || o.rate || o.yield_pct) * 100, ty = String(o.type).toUpperCase();
        if (!isFinite(t) || !isFinite(v)) return;
        if (ty === "STIR") { for (var k = 0; k < NS; k++) if (Math.abs(HS[k] - t) < 0.02) st[di[o.date] * NS + k] = v; }
        else if (ty === "BOND") { ten[t] = 1; brows.push([di[o.date], t, v]); }
        else if (ty === "SWAP") srows.push([di[o.date], t, v]);
      });
      var b = Object.keys(ten).map(Number).sort(function (a, x) { return a - x; }), nb = b.length, by = nanArr(md.n * Math.max(nb, 1));
      brows.forEach(function (q) { by[q[0] * nb + b.indexOf(q[1])] = q[2]; });
      var fill = function (a, w) { for (var k = 0; k < w; k++) { var last = NaN, first = NaN, d; for (d = 0; d < md.n; d++) { var x = d * w + k; if (a[x] === a[x]) { last = a[x]; if (first !== first) first = last; } else a[x] = last; } for (d = 0; d < md.n && a[d * w + k] !== a[d * w + k]; d++) a[d * w + k] = first; } };
      fill(st, NS); if (nb) fill(by, nb);
      var stOk = isFinite(st[0]) && Array.prototype.every.call(st.subarray(0, NS), isFinite);
      if (stOk) md.stir[c] = st;
      if (nb >= 2) { md.bond[c] = by; md.bt[c] = b; }
      if (nb >= 2 && srows.length) { // swap curve, interpolated onto the bond tenors
        var byD = {}; srows.forEach(function (q) { (byD[q[0]] = byD[q[0]] || []).push([q[1], q[2]]); });
        var sw = nanArr(md.n * nb);
        Object.keys(byD).forEach(function (dk) { var pts = byD[dk].sort(function (x, y) { return x[0] - y[0]; }); if (pts.length < 2) return; b.forEach(function (T, k) { sw[+dk * nb + k] = lin(pts.map(function (q) { return q[0]; }), pts.map(function (q) { return q[1]; }), T); }); });
        fill(sw, nb); if (isFinite(sw[0])) { md.swap = md.swap || {}; md.swap[c] = sw; }
      }
    });
    md.hasFut = Object.keys(md.stir).length + Object.keys(md.bond).length > 0;
    return md;
  }

  // ---------------------------------------------------------------- PCA helpers
  function jacobi(A, n) { // eigen-decomposition of a symmetric matrix (flat array), returns {val, vec[k][i]}
    var a = A.slice(), v = new Float64Array(n * n), i, j, k;
    for (i = 0; i < n; i++) v[i * n + i] = 1;
    for (var sweep = 0; sweep < 60; sweep++) {
      var off = 0; for (i = 0; i < n; i++) for (j = i + 1; j < n; j++) off += a[i * n + j] * a[i * n + j];
      if (off < 1e-14) break;
      for (var p = 0; p < n; p++) for (var q = p + 1; q < n; q++) {
        var apq = a[p * n + q]; if (Math.abs(apq) < 1e-15) continue;
        var th = (a[q * n + q] - a[p * n + p]) / (2 * apq), t = (th >= 0 ? 1 : -1) / (Math.abs(th) + Math.sqrt(th * th + 1)), cs = 1 / Math.sqrt(t * t + 1), sn = t * cs;
        for (k = 0; k < n; k++) { var akp = a[k * n + p], akq = a[k * n + q]; a[k * n + p] = cs * akp - sn * akq; a[k * n + q] = sn * akp + cs * akq; }
        for (k = 0; k < n; k++) { var apk = a[p * n + k], aqk = a[q * n + k]; a[p * n + k] = cs * apk - sn * aqk; a[q * n + k] = sn * apk + cs * aqk; }
        for (k = 0; k < n; k++) { var vkp = v[k * n + p], vkq = v[k * n + q]; v[k * n + p] = cs * vkp - sn * vkq; v[k * n + q] = sn * vkp + cs * vkq; }
      }
    }
    var idx = []; for (i = 0; i < n; i++) idx.push(i);
    idx.sort(function (x, y) { return a[y * n + y] - a[x * n + x]; });
    return { val: idx.map(function (q) { return a[q * n + q]; }), vec: idx.map(function (q) { var e = []; for (var r = 0; r < n; r++) e.push(v[r * n + q]); return e; }) };
  }
  function surfacePCA(md, c) { // residual of each cell's vol after the first 3 PCs of the surface (trailing 252d, refit every 21d)
    return cache(md, "pca" + c, function () {
      var cells = []; for (var e = 1; e <= 5; e++) for (var t = 0; t < NT; t++) cells.push([e, t]);
      var m = cells.length, res = nanArr(md.n * m), W = 252, P = null, mu = null;
      for (var d = W; d < md.n; d++) {
        if (!P || (d - W) % 21 === 0) {
          mu = new Float64Array(m); var X = [];
          for (var i = d - W; i < d; i++) { var row = cells.map(function (q) { return md.V[c][IX(i, q[0], q[1])]; }); X.push(row); for (var j = 0; j < m; j++) mu[j] += row[j] / W; }
          var C = new Float64Array(m * m); X.forEach(function (row) { for (var a = 0; a < m; a++) { var xa = row[a] - mu[a]; for (var b = a; b < m; b++) C[a * m + b] += xa * (row[b] - mu[b]) / (W - 1); } });
          for (var a2 = 0; a2 < m; a2++) for (var b2 = 0; b2 < a2; b2++) C[a2 * m + b2] = C[b2 * m + a2];
          P = jacobi(C, m).vec.slice(0, 3);
        }
        var x = cells.map(function (q, j) { return md.V[c][IX(d, q[0], q[1])] - mu[j]; }), fit = new Float64Array(m);
        P.forEach(function (pc) { var s = 0; for (var j = 0; j < m; j++) s += pc[j] * x[j]; for (j = 0; j < m; j++) fit[j] += s * pc[j]; });
        for (var j2 = 0; j2 < m; j2++) res[d * m + j2] = x[j2] - fit[j2];
      }
      return { cells: cells, res: res };
    });
  }
  function pcaFlyWeights(md, c, tens) { // rolling 252d PCA of fixed-maturity yield changes for 3 tenors -> weights neutral to PC1, PC2
    return cache(md, "pfw" + c + tens.join("_"), function () {
      var b = md.bt[c], nb = b.length, ks = tens.map(function (T) { return b.indexOf(T); }), dx = dBond(md, c), W = 252, out = [];
      for (var d = 0; d < md.n; d++) out.push(null);
      for (d = W; d < md.n; d++) {
        if ((d - W) % 5 !== 0 && out[d - 1]) { out[d] = out[d - 1]; continue; }
        var mu = [0, 0, 0], X = [];
        for (var i = d - W + 1; i <= d; i++) { var row = ks.map(function (k) { return dx[i * nb + k]; }); if (row.some(function (v) { return !isFinite(v); })) continue; X.push(row); mu[0] += row[0]; mu[1] += row[1]; mu[2] += row[2]; }
        if (X.length < 120) continue; mu = mu.map(function (v) { return v / X.length; });
        var C = new Float64Array(9); X.forEach(function (row) { for (var a = 0; a < 3; a++) for (var bb = 0; bb < 3; bb++) C[a * 3 + bb] += (row[a] - mu[a]) * (row[bb] - mu[bb]) / (X.length - 1); });
        var E = jacobi(Array.prototype.slice.call(C), 3), p1 = E.vec[0], p2 = E.vec[1];
        var det = p1[0] * p2[2] - p1[2] * p2[0]; if (Math.abs(det) < 1e-9) continue;
        var w1 = (-p1[1] * p2[2] + p1[2] * p2[1]) / det, w3 = (-p1[0] * p2[1] + p1[1] * p2[0]) / det;
        out[d] = [w1, 1, w3];
      }
      return out;
    });
  }

  // ---------------------------------------------------------------- candidate builders
  function cand(o) { o.asset = FAMX[o.fam][1]; o.bm = o.asset === "vol" ? "vol" : "dur"; return o; }
  function optLeg(c, e, t, w, kind, off) { return { c: c, E: ET[e], t: t, w: w, kind: kind || "straddle", off: off || 0 }; }
  function futLeg(c, inst, x, w) { return { c: c, kind: "fut", inst: inst, x: x, w: w }; }

  function candidatesExt(md) {
    var C = [], push = function (o) { C.push(cand(o)); };
    md.ccys.forEach(function (c) {
      var dF = R.dFixed(md, c);
      // ---------- S9 / S10: smile vs realised spot-vol dynamics (SABR-consistent fair slope and curvature)
      if (md.hasSmile) [[1, 1], [1, 3], [3, 1], [3, 3], [4, 3]].forEach(function (p) {
        var e = p[0], t = p[1], key = "sabr" + c + e + t;
        var stats = function () {
          return cache(md, key, function () {
            var v = R.series(md, md.V, c, e, t), ds = new Float64Array(md.n), df = new Float64Array(md.n);
            ds[0] = NaN; df[0] = NaN; for (var d = 1; d < md.n; d++) { ds[d] = v[d] - v[d - 1]; df[d] = dF[IX(d, e, t)]; }
            var rho = R.rollCorr(ds, df, 66), sd = rollSd(ds, 66, 33), nu = new Float64Array(md.n), sf = new Float64Array(md.n), cf = new Float64Array(md.n);
            for (d = 0; d < md.n; d++) { nu[d] = sd[d] * Math.sqrt(252) / v[d]; sf[d] = rho[d] * nu[d] / 2; cf[d] = (2 - 3 * rho[d] * rho[d]) * nu[d] * nu[d] / (12 * v[d]); }
            return { rho: rho, nu: nu, sf: sf, cf: cf, v: v };
          });
        };
        var k = function (d) { return Math.round(0.675 * md.V[c][IX(d, e, t)] * Math.sqrt(ET[e])); };
        push({ id: "S9." + c + nn(e, t), fam: "S9", ccy: c, node: [e, t], name: c + " " + nn(e, t) + " skew vs realised spot-vol correlation", longTxt: "buy " + c + " " + nn(e, t) + " risk reversal (long payer, short receiver)", shortTxt: "sell " + c + " " + nn(e, t) + " risk reversal (short payer, long receiver)",
          compute: function () { var s = stats(), g = new Float64Array(md.n); for (var d = 0; d < md.n; d++) g[d] = s.sf[d] - md.S[c][IX(d, e, t)]; return R.scoreFrom(g, "z"); },
          legs: function (d) { var o = k(d); return [optLeg(c, e, t, 1, "payer", o), optLeg(c, e, t, -1, "receiver", -o)]; },
          why: function (d) { var s = stats(); return "Implied smile slope s = " + fmt(md.S[c][IX(d, e, t)], 4) + ". Realised corr(Δσ, ΔF) = " + fmt(s.rho[d], 2) + " and vol-of-vol ν = " + fmt(100 * s.nu[d], 0) + "% give a SABR-consistent slope ρν/2 = " + fmt(s.sf[d], 4) + ". Legs struck ±" + k(d) + "bp."; } });
        push({ id: "S10." + c + nn(e, t), fam: "S10", ccy: c, node: [e, t], name: c + " " + nn(e, t) + " smile wings vs realised vol-of-vol", longTxt: "buy " + c + " " + nn(e, t) + " wings: long strangle, short ATM straddle (vega-neutral)", shortTxt: "sell " + c + " " + nn(e, t) + " wings: short strangle, long ATM straddle",
          compute: function () { var s = stats(), g = new Float64Array(md.n); for (var d = 0; d < md.n; d++) { var cv = md.C[c][IX(d, e, t)]; g[d] = cv > 0 && s.cf[d] > 0 ? Math.log(s.cf[d] / cv) : NaN; } return R.scoreFrom(g, "z"); },
          legs: function (d) { var o = k(d); return [optLeg(c, e, t, 0.5, "payer", o), optLeg(c, e, t, 0.5, "receiver", -o), optLeg(c, e, t, -1, "straddle", 0)]; },
          why: function (d) { var s = stats(); return "Implied curvature c = " + fmt(md.C[c][IX(d, e, t)] * 1e4, 2) + "×10⁻⁴. The SABR-consistent value (2 − 3ρ²)ν²/(12σ) with realised ρ = " + fmt(s.rho[d], 2) + ", ν = " + fmt(100 * s.nu[d], 0) + "% is " + fmt(s.cf[d] * 1e4, 2) + "×10⁻⁴."; } });
      });
      // ---------- S11: surface PCA residual, traded against the neighbouring cells
      for (var e11 = 1; e11 <= 5; e11++) for (var t11 = 0; t11 < NT; t11++) (function (e, t) {
        var j = (e - 1) * NT + t, nb = [[e - 1, t], [e + 1, t], [e, t - 1], [e, t + 1]].filter(function (q) { return q[0] >= 1 && q[0] <= 5 && q[1] >= 0 && q[1] < NT; });
        push({ id: "S11." + c + nn(e, t), fam: "S11", ccy: c, node: [e, t], name: c + " " + nn(e, t) + " vs 3-factor surface (PCA residual)", longTxt: "buy " + c + " " + nn(e, t) + ", sell its neighbours (" + nb.map(function (q) { return nn(q[0], q[1]); }).join(", ") + ")", shortTxt: "sell " + c + " " + nn(e, t) + ", buy its neighbours",
          compute: function () { var P = surfacePCA(md, c), g = nanArr(md.n), m = P.cells.length; for (var d = 0; d < md.n; d++) g[d] = -P.res[d * m + j]; return R.scoreFrom(g, "z"); },
          legs: function () { return [optLeg(c, e, t, 1)].concat(nb.map(function (q) { return optLeg(c, q[0], q[1], -1 / nb.length); })); },
          why: function (d) { var P = surfacePCA(md, c); return "After the first three principal components of the surface (level, slope, curvature), fitted on the trailing year, this cell is " + fmt(P.res[d * P.cells.length + j], 1) + "bp away from the fitted surface."; } });
      })(e11, t11);
      // ---------- S12: vol momentum
      [[1, 1], [1, 3], [3, 1], [3, 3]].forEach(function (p) {
        var e = p[0], t = p[1];
        push({ id: "S12." + c + nn(e, t), fam: "S12", ccy: c, node: [e, t], name: c + " " + nn(e, t) + " implied vol momentum (21d)", longTxt: "buy " + c + " " + nn(e, t) + " straddle (vol trending up)", shortTxt: "sell " + c + " " + nn(e, t) + " straddle (vol trending down)",
          compute: function () { var v = R.series(md, md.V, c, e, t), g = nanArr(md.n); for (var d = 21; d < md.n; d++) g[d] = v[d] - v[d - 21]; return R.scoreFrom(g, "level"); },
          legs: function () { return [optLeg(c, e, t, 1)]; },
          why: function (d) { return "Implied moved " + fmt(md.V[c][IX(d, e, t)] - md.V[c][IX(Math.max(0, d - 21), e, t)], 1) + "bp over the last 21 days."; } });
      });

      // ---------- STIR futures
      if (md.stir && md.stir[c]) {
        var sk = function (h) { return HS.indexOf(h); }, code = SNAME[c];
        [0.5, 1, 1.5, 2].forEach(function (h) {
          push({ id: "F1." + c + h, fam: "F1", ccy: c, name: code + " " + hLbl(h) + " contract carry and roll-down", longTxt: "buy " + code + " " + hLbl(h) + " future (receive)", shortTxt: "sell " + code + " " + hLbl(h) + " future (pay)",
            compute: function () { var rv = rvSeries(md, "S", c, sk(h), 66), g = new Float64Array(md.n); for (var d = 0; d < md.n; d++) g[d] = (stir(md, c, d, h) - stir(md, c, d, h - 0.25)) / (rv[d] * 0.5); return R.scoreFrom(g, "level"); },
            legs: function () { return [futLeg(c, "stir", h, 1)]; },
            why: function (d) { return "Implied 3m rate " + fmt(stir(md, c, d, h) / 100, 3) + "%. Over a quarter the contract rolls down " + fmt(stir(md, c, d, h) - stir(md, c, d, h - 0.25), 1) + "bp, against " + fmt(rvSeries(md, "S", c, sk(h), 66)[d] * 0.5, 1) + "bp of quarterly realised vol."; } });
        });
        [0.5, 1, 2].forEach(function (h) {
          push({ id: "F2." + c + h, fam: "F2", ccy: c, name: code + " " + hLbl(h) + " trend (3m)", longTxt: "buy " + code + " " + hLbl(h) + " future (rates trending down)", shortTxt: "sell " + code + " " + hLbl(h) + " future (rates trending up)",
            compute: function () { var rv = rvSeries(md, "S", c, sk(h), 66), g = nanArr(md.n); for (var d = 63; d < md.n; d++) g[d] = -(stir(md, c, d, h) - stir(md, c, d - 63, h)) / (rv[d] * 0.5); return R.scoreFrom(g, "level"); },
            legs: function () { return [futLeg(c, "stir", h, 1)]; },
            why: function (d) { return "The " + hLbl(h) + " implied rate moved " + fmt(stir(md, c, d, h) - stir(md, c, Math.max(0, d - 63), h), 1) + "bp over 63 days, against " + fmt(rvSeries(md, "S", c, sk(h), 66)[d] * 0.5, 1) + "bp of quarterly realised vol."; } });
          push({ id: "F3." + c + h, fam: "F3", ccy: c, name: code + " " + hLbl(h) + " vs " + hLbl(h + 1) + " calendar spread", longTxt: "buy " + hLbl(h) + ", sell " + hLbl(h + 1) + " " + code + " (DV01-neutral steepener)", shortTxt: "sell " + hLbl(h) + ", buy " + hLbl(h + 1) + " " + code + " (DV01-neutral flattener)",
            compute: function () { var g = new Float64Array(md.n); for (var d = 0; d < md.n; d++) g[d] = -(stir(md, c, d, h + 1) - stir(md, c, d, h)); return R.scoreFrom(g, "z"); },
            legs: function () { return [futLeg(c, "stir", h, 1), futLeg(c, "stir", h + 1, -1)]; },
            why: function (d) { return "Spread " + hLbl(h + 1) + " − " + hLbl(h) + " = " + fmt(stir(md, c, d, h + 1) - stir(md, c, d, h), 1) + "bp."; } });
        });
        [1, 1.5, 2].forEach(function (h) {
          push({ id: "F4." + c + h, fam: "F4", ccy: c, name: code + " " + hLbl(h - 0.5) + "/" + hLbl(h) + "/" + hLbl(h + 0.5) + " butterfly", longTxt: "buy " + code + " " + hLbl(h) + " belly, sell wings (1 : −½ : −½ DV01)", shortTxt: "sell " + code + " " + hLbl(h) + " belly, buy wings",
            compute: function () { var g = new Float64Array(md.n); for (var d = 0; d < md.n; d++) g[d] = 2 * stir(md, c, d, h) - stir(md, c, d, h - 0.5) - stir(md, c, d, h + 0.5); return R.scoreFrom(g, "z"); },
            legs: function () { return [futLeg(c, "stir", h, 1), futLeg(c, "stir", h - 0.5, -0.5), futLeg(c, "stir", h + 0.5, -0.5)]; },
            why: function (d) { return "Fly 2·r(" + hLbl(h) + ") − r(" + hLbl(h - 0.5) + ") − r(" + hLbl(h + 0.5) + ") = " + fmt(2 * stir(md, c, d, h) - stir(md, c, d, h - 0.5) - stir(md, c, d, h + 0.5), 1) + "bp."; } });
        });
      }
      // ---------- bond futures
      if (md.bond && md.bond[c]) {
        var b = md.bt[c], bn = function (T) { return (BNAME[c] && BNAME[c][T]) || c + " " + T + "y"; };
        b.forEach(function (T, k) {
          push({ id: "B1." + c + T, fam: "B1", ccy: c, name: bn(T) + " future trend (3m)", longTxt: "buy " + bn(T) + " future", shortTxt: "sell " + bn(T) + " future",
            compute: function () { var rv = rvSeries(md, "B", c, k, 66), g = nanArr(md.n); for (var d = 63; d < md.n; d++) g[d] = -(bond(md, c, d, T) - bond(md, c, d - 63, T)) / (rv[d] * 0.5); return R.scoreFrom(g, "level"); },
            legs: function () { return [futLeg(c, "bond", T, 1)]; },
            why: function (d) { return bn(T) + " yield " + fmt(bond(md, c, d, T) / 100, 3) + "%, " + fmt(bond(md, c, d, T) - bond(md, c, Math.max(0, d - 63), T), 1) + "bp over 63 days."; } });
          push({ id: "B2." + c + T, fam: "B2", ccy: c, name: bn(T) + " future carry and roll-down", longTxt: "buy " + bn(T) + " future (positive carry)", shortTxt: "sell " + bn(T) + " future (negative carry)",
            compute: function () { var rv = rvSeries(md, "B", c, k, 66), g = new Float64Array(md.n); for (var d = 0; d < md.n; d++) { var y = bond(md, c, d, T), cq = (y - repo(md, c, d)) * 0.25 / dur(y, T) + (y - bond(md, c, d, T - 0.25)); g[d] = cq / (rv[d] * 0.5); } return R.scoreFrom(g, "level"); },
            legs: function () { return [futLeg(c, "bond", T, 1)]; },
            why: function (d) { var y = bond(md, c, d, T), rp = repo(md, c, d); return "Yield " + fmt(y / 100, 3) + "% vs repo " + fmt(rp / 100, 3) + "%: carry " + fmt((y - rp) * 0.25 / dur(y, T), 1) + "bp plus roll-down " + fmt(y - bond(md, c, d, T - 0.25), 1) + "bp of yield per quarter."; } });
        });
        var pairs = { GBP: [[2, 10], [5, 10]], EUR: [[2, 10], [5, 30], [10, 30]], USD: [[2, 10], [5, 30], [10, 30]] }[c] || [];
        pairs.filter(function (p) { return b.indexOf(p[0]) >= 0 && b.indexOf(p[1]) >= 0; }).forEach(function (p) {
          push({ id: "B3." + c + p.join("s") + "s", fam: "B3", ccy: c, name: c + " " + p[0] + "s" + p[1] + "s curve (" + bn(p[0]) + " vs " + bn(p[1]) + ")", longTxt: "steepener: buy " + bn(p[0]) + ", sell " + bn(p[1]) + " (DV01-neutral)", shortTxt: "flattener: sell " + bn(p[0]) + ", buy " + bn(p[1]) + " (DV01-neutral)",
            compute: function () { var g = new Float64Array(md.n); for (var d = 0; d < md.n; d++) g[d] = -(bond(md, c, d, p[1]) - bond(md, c, d, p[0])); return R.scoreFrom(g, "z"); },
            legs: function () { return [futLeg(c, "bond", p[0], 1), futLeg(c, "bond", p[1], -1)]; },
            why: function (d) { return p[0] + "s" + p[1] + "s slope " + fmt(bond(md, c, d, p[1]) - bond(md, c, d, p[0]), 1) + "bp."; } });
        });
        var flies = { GBP: [[2, 5, 10]], EUR: [[2, 5, 10], [5, 10, 30]], USD: [[2, 5, 10], [5, 10, 30]] }[c] || [];
        flies.filter(function (f) { return f.every(function (T) { return b.indexOf(T) >= 0; }); }).forEach(function (f) {
          var W = function () { return pcaFlyWeights(md, c, f); };
          push({ id: "B4." + c + f.join("s") + "s", fam: "B4", ccy: c, name: c + " " + f.join("s") + "s PCA-neutral butterfly", longTxt: "buy " + bn(f[1]) + " belly vs " + bn(f[0]) + " and " + bn(f[2]) + " wings (level- and slope-neutral)", shortTxt: "sell " + bn(f[1]) + " belly vs wings (level- and slope-neutral)",
            compute: function () { var w = W(), g = nanArr(md.n); for (var d = 0; d < md.n; d++) if (w[d]) g[d] = w[d][0] * bond(md, c, d, f[0]) + bond(md, c, d, f[1]) + w[d][2] * bond(md, c, d, f[2]); return R.scoreFrom(g, "z"); },
            legs: function (d) { var w = W()[d]; return [futLeg(c, "bond", f[0], w[0]), futLeg(c, "bond", f[1], 1), futLeg(c, "bond", f[2], w[2])]; },
            why: function (d) { var w = W()[d]; return w ? "Weights from a trailing-year PCA of yield changes: " + fmt(w[0], 2) + " : 1 : " + fmt(w[2], 2) + " (DV01), neutral to the first two components. Fly level " + fmt(w[0] * bond(md, c, d, f[0]) + bond(md, c, d, f[1]) + w[2] * bond(md, c, d, f[2]), 1) + "bp." : ""; } });
        });
      }
    });
    // ---------- B5: cross-market 10y spreads
    var tenY = md.ccys.filter(function (c) { return md.bond && md.bond[c] && md.bt[c].indexOf(10) >= 0; });
    var pairs5 = [["GBP", "EUR"], ["USD", "EUR"], ["GBP", "USD"]].filter(function (p) { return tenY.indexOf(p[0]) >= 0 && tenY.indexOf(p[1]) >= 0; });
    pairs5.forEach(function (p) {
      var A = p[0], B = p[1], beta = function () { return cache(md, "xb" + A + B, function () { var ya = new Float64Array(md.n), yb = new Float64Array(md.n); for (var d = 0; d < md.n; d++) { ya[d] = bond(md, A, d, 10); yb[d] = bond(md, B, d, 10); } return R.rollBeta(ya, yb, 120); }); };
      var bnA = BNAME[A][10], bnB = BNAME[B][10];
      push({ id: "B5." + A + B, fam: "B5", ccy: A + "/" + B, name: bnA + " vs " + bnB + " 10y spread", longTxt: "buy " + bnA + ", sell β × " + bnB, shortTxt: "sell " + bnA + ", buy β × " + bnB,
        compute: function () { var bt = beta(), g = nanArr(md.n); for (var d = 0; d < md.n; d++) if (isFinite(bt[d])) g[d] = bond(md, A, d, 10) - bt[d] * bond(md, B, d, 10); return R.scoreFrom(g, "z"); },
        legs: function (d) { var bt = beta()[d]; return [futLeg(A, "bond", 10, 1), futLeg(B, "bond", 10, -(isFinite(bt) ? bt : 1))]; },
        why: function (d) { return A + "−" + B + " 10y spread " + fmt(bond(md, A, d, 10) - bond(md, B, d, 10), 1) + "bp. Beta of daily changes (120d) " + fmt(beta()[d], 2) + "."; } });
    });
    return C;
  }

  // ---------------------------------------------------------------- generalised engine
  function optPrice(F, K, s, tau, kind) {
    if (kind === "straddle") return R.strad(F, K, s, tau);
    var w = kind === "payer" ? 1 : -1;
    if (tau <= 0 || s <= 0) { var iv = Math.max(w * (F - K), 0); return { p: iv, d: iv > 0 ? w : 0, g: 0, v: 0, th: 0 }; }
    var sq = Math.sqrt(tau), sd = s * sq, x = (F - K) / sd, n = R.pdf(x), N = R.cdf(x), g = n / sd;
    return { p: w * (F - K) * R.cdf(w * x) + sd * n, d: w > 0 ? N : N - 1, g: g, v: sq * n, th: -0.5 * s * s * g };
  }
  function halfBO(L) {
    if (L.kind === "fut") return L.inst === "stir" ? 0.25 : L.inst === "swap" ? 0.2 : 0.15;
    if (L.prod === "so") return 0.5;
    var bo = L.E >= 2 ? 0.7 : 0.4; if (TAILS[L.t] >= 30) bo += 0.3; return L.kind === "spread" ? bo * 1.5 : bo;
  }
  function futRate(md, L, d) { var tau = Math.max(L.x - (d - L.d0) / 252, L.inst === "stir" ? 0.05 : 0.5); return L.inst === "stir" ? stir(md, L.c, d, tau) : L.inst === "swap" ? swapR(md, L.c, d, tau) : bond(md, L.c, d, tau); }
  function mark(md, L, d) {
    if (L.kind === "fut") return { F: futRate(md, L, d), s: 0, V: 0, D: 0, G: 0, Vg: 0, Th: 0 };
    var tau = (L.exp - d) / 252, F, s, A;
    if (L.prod === "so") { var Hn = Math.max(L.H - (d - L.d0) / 252, 0.05); F = stir(md, L.c, d, Hn); A = 1; s = Math.max(1, soVol(md, L.c, d, Hn, Math.max(tau, 0))); }
    else if (L.kind === "spread") {
      F = R.interp(ET, R.col(md, md.F, L.c, d, L.t2), Math.max(tau, 0)) - R.interp(ET, R.col(md, md.F, L.c, d, L.t), Math.max(tau, 0));
      var sv = []; for (var e = 0; e < NE; e++) sv.push(md.spread[L.c][d * NE + e]); s = R.interp(ET, sv, Math.max(tau, 0)); A = 1;
    } else { var nd = R.nodeAt(md, L.c, d, Math.max(tau, 0), L.t), m = L.K - nd.F; F = nd.F; A = nd.A; s = Math.max(1, nd.V + nd.S * m + nd.C * m * m); }
    var g = optPrice(F, L.K, s, tau, L.kind === "spread" ? "straddle" : L.kind), u = L.N * A * 1e-4;
    return { F: F, s: s, tau: tau, V: g.p * u, D: g.d * u, G: g.g * u, Vg: g.v * u, Th: g.th * u };
  }
  function openLegs(md, c, d, dir, o) {
    return c.legs(d).map(function (sp) {
      var L = { c: sp.c, kind: sp.kind, w: sp.w, d0: d };
      if (sp.kind === "fut") { L.inst = sp.inst; L.x = sp.x; L.N = dir * sp.w * o.dv01; L.exp = d + 1e6; L.h = 0; L.last = mark(md, L, d); return L; }
      var e = ET.indexOf(sp.E), F, s, A;
      L.E = sp.E; L.t = sp.t; L.t2 = sp.t2; L.exp = d + Math.round(sp.E * 252);
      if (sp.prod === "so") { L.prod = "so"; L.H = sp.H; F = stir(md, sp.c, d, sp.H); A = 1; L.K = F + (sp.off || 0); s = Math.max(1, soVol(md, sp.c, d, sp.H, sp.E)); }
      else if (sp.kind === "spread") { F = md.F[sp.c][IX(d, e, sp.t2)] - md.F[sp.c][IX(d, e, sp.t)]; s = md.spread[sp.c][d * NE + e]; A = 1; L.K = F; }
      else { var x = IX(d, e, sp.t), off = sp.off || 0; F = md.F[sp.c][x]; A = md.A[sp.c][x]; L.K = F + off; s = Math.max(1, md.V[sp.c][x] + md.S[sp.c][x] * off + md.C[sp.c][x] * off * off); }
      var z = (F - L.K) / (s * Math.sqrt(sp.E)), vpn = (sp.kind === "straddle" || sp.kind === "spread" ? 2 : 1) * Math.sqrt(sp.E) * R.pdf(z) * A * 1e-4;
      L.N = sp.size === "dv01" ? dir * sp.w * o.dv01 / (A * 1e-4) : dir * sp.w * o.vega / vpn;
      L.last = mark(md, L, d); if (sp.hedge === false) { L.unh = true; L.h = 0; } else L.h = -L.last.D; return L;
    });
  }
  var COMP = ["theta", "gamma", "vega", "resid", "hedge", "rates", "carry", "cost"];
  function stepLeg(md, L, d, o, costs) { // P&L of one leg from d-1 to d, then rehedge
    var p0 = L.last, p1 = mark(md, L, d), r = {};
    if (L.kind === "fut") {
      var dr = p1.F - p0.F, carry = 0;
      if (L.inst === "bond" || L.inst === "swap") carry = L.N * (p0.F - repo(md, L.c, d - 1)) / (252 * dur(p0.F, Math.max(L.x - (d - 1 - L.d0) / 252, 0.5)));
      r.rates = -L.N * dr; r.carry = carry; r.tot = r.rates + carry; L.last = p1; return r;
    }
    var dF = p1.F - p0.F, th = p0.Th / 252, ga = 0.5 * p0.G * dF * dF, ve = p0.Vg * (p1.s - p0.s), de = p0.D * dF;
    if (L.unh) { r.theta = th; r.gamma = ga; r.vega = ve; r.rates = de; r.resid = (p1.V - p0.V) - (th + ga + ve + de); r.tot = p1.V - p0.V; L.last = p1; return r; }
    var nh = -p1.D, c = costs ? Math.abs(nh - L.h) * 0.1 * o.cost : 0;
    r.theta = th; r.gamma = ga; r.vega = ve; r.resid = (p1.V - p0.V) - (th + ga + ve + de); r.hedge = de + L.h * dF; r.cost = -c;
    r.tot = p1.V - p0.V + L.h * dF - c; L.h = nh; L.last = p1; return r;
  }
  function tradeCost(L, o) { return L.kind === "fut" ? Math.abs(L.N) * halfBO(L) * o.cost : (Math.abs(L.last.Vg) * halfBO(L) + (L.unh ? 0 : Math.abs(L.h) * 0.1)) * o.cost; }

  function backtest(md, c, o) {
    if (!c.score) { c.score = c.compute(); var ls = R.lastScore(); if (ls) { c.gap = ls.gap; c.mode = ls.mode; c.gm = ls.m; c.gs = ls.s; } }
    var sc = c.score, n = md.n, daily = new Float64Array(n), cost = new Float64Array(n), comp = {}, trades = [], pos = null;
    COMP.forEach(function (k) { comp[k] = 0; });
    for (var d = 1; d < n; d++) {
      if (pos) {
        pos.legs.forEach(function (L) {
          var r = stepLeg(md, L, d, o, true);
          COMP.forEach(function (k) { if (r[k]) comp[k] += r[k]; });
          daily[d] += r.tot; if (r.cost) cost[d] += r.cost; pos.pnl += r.tot;
        });
        var s = sc[d], held = d - pos.d0, minTau = Math.min.apply(null, pos.legs.map(function (L) { return L.exp - d; })), why = null;
        if (s === s && pos.dir * s < o.zout) why = "signal"; else if (held >= o.hold) why = "max hold"; else if (minTau <= 5) why = "expiry";
        if (why || d === n - 1) {
          var xc = pos.legs.reduce(function (a, L) { return a + tradeCost(L, o); }, 0);
          daily[d] -= xc; cost[d] -= xc; comp.cost -= xc; pos.pnl -= xc;
          trades.push({ d0: pos.d0, d1: d, dir: pos.dir, pnl: pos.pnl, why: why || "end", s0: pos.s0, s1: s }); pos = null;
        }
      }
      if (!pos && d >= o.from && d < n - 1) {
        var s2 = sc[d];
        if (s2 === s2 && Math.abs(s2) >= o.zin) {
          var dir = s2 > 0 ? 1 : -1, legs = null;
          try { legs = openLegs(md, c, d, dir, o); } catch (err) { legs = null; }
          if (legs && legs.length && legs.every(function (L) { return isFinite(L.N) && isFinite(L.last.F) && isFinite(L.last.V); })) {
            var ec = legs.reduce(function (a, L) { return a + tradeCost(L, o); }, 0);
            pos = { legs: legs, dir: dir, d0: d, pnl: -ec, s0: s2 }; daily[d] -= ec; cost[d] -= ec; comp.cost -= ec;
          }
        }
      }
    }
    return { daily: daily, cost: cost, comp: comp, trades: trades, score: sc };
  }
  function benchmark(md, c, o, kind) {
    var b = kind === "dur" ? { id: "BMD." + c, compute: function () { var a = new Float64Array(md.n); a.fill(10); return a; }, legs: function () { return [futLeg(c, "bond", 10, 1)]; } }
      : { id: "BMV." + c, compute: function () { var a = new Float64Array(md.n); a.fill(-10); return a; }, legs: function () { return [optLeg(c, 1, 1, 1)]; } };
    if (kind === "dur" && !(md.bond && md.bond[c] && md.bt[c].indexOf(10) >= 0)) return new Float64Array(md.n);
    return backtest(md, b, { zin: 1, zout: -1e9, hold: o.hold, vega: o.vega, dv01: o.dv01, cost: o.cost, from: o.from }).daily;
  }
  function unitForward(md, c, o) {
    var out = [], H = [5, 10, 20];
    for (var d = o.from; d < md.n - 21; d += 5) {
      var s = c.score[d]; if (!(s === s)) continue;
      var legs; try { legs = openLegs(md, c, d, 1, o); } catch (e) { continue; }
      var cum = 0, rec = { s: s };
      for (var h = 1; h <= 20; h++) { legs.forEach(function (L) { cum += stepLeg(md, L, d + h, o, false).tot; }); if (H.indexOf(h) >= 0) rec["h" + h] = cum; }
      if (isFinite(cum)) out.push(rec);
    }
    return out;
  }

  W.RVX = { HS: HS, BT: BT, BNAME: BNAME, SNAME: SNAME, FAMX: FAMX, hLbl: hLbl, stir: stir, bond: bond, repo: repo, dur: dur, rvSeries: rvSeries,
    genFutures: genFutures, futuresFromCSV: futuresFromCSV, candidatesExt: candidatesExt, backtest: backtest, benchmark: benchmark, unitForward: unitForward,
    surfacePCA: surfacePCA, pcaFlyWeights: pcaFlyWeights, jacobi: jacobi,
    OT: OT, swapR: swapR, soVol: soVol, optPrice: optPrice, openLegs: openLegs, stepLeg: stepLeg, mark: mark, tradeCost: tradeCost, halfBO: halfBO, lin: lin, dStir: dStir, dBond: dBond, cache: cache, nanArr: nanArr, cand: cand, optLeg: optLeg, futLeg: futLeg, COMP: COMP };
})(window);
