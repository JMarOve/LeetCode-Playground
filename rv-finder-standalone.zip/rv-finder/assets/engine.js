// RV Finder engine: data, signals, delta-hedged backtest and statistics.
// Every formula here is written out on the page (Method section); the section
// numbers in comments match the page.
(function (W) {
  "use strict";
  var EXPN = ["1m", "3m", "6m", "1y", "2y", "5y", "10y"], ET = [1 / 12, 0.25, 0.5, 1, 2, 5, 10], TAILS = [1, 2, 5, 10, 30];
  var NE = 7, NT = 5, CCYS = ["GBP", "EUR", "USD"], CB = { GBP: "MPC", EUR: "ECB", USD: "FOMC" };
  var LEVELS = { // anchor levels shared with the grid screener (illustrative, not market data)
    USD: { rate: 3.9, grid: [[88, 104, 112, 108, 98], [92, 104, 113, 109, 99], [95, 105, 112, 108, 98], [98, 106, 110, 106, 96], [101, 105, 106, 102, 92], [99, 100, 99, 95, 85], [90, 90, 88, 84, 76]] },
    EUR: { rate: 2.4, grid: [[62, 74, 82, 80, 70], [66, 76, 83, 80, 71], [70, 78, 83, 80, 70], [74, 80, 84, 82, 69], [78, 81, 80, 77, 67], [79, 79, 77, 73, 64], [74, 73, 71, 67, 58]] },
    GBP: { rate: 4.0, grid: [[82, 92, 98, 95, 90], [85, 94, 99, 96, 91], [88, 95, 99, 95, 90], [90, 96, 97, 94, 88], [92, 95, 94, 91, 85], [89, 89, 88, 85, 78], [82, 81, 80, 77, 70]] }
  };
  var FAM = {
    S1: "Implied vs forecast realised", S2: "Smile-adjusted breakeven", S3: "Grid carry and roll-down",
    S4: "Forward vs spot vol", S5x: "Cross-currency vol ratio", S5t: "Tail (curve) vol ratio",
    S6: "Implied vs realised correlation", S7: "Event premium", S8: "Vol vs curve residual"
  };
  var IX = function (d, e, t) { return (d * NE + e) * NT + t; };
  var nodeName = function (e, t) { return EXPN[e] + TAILS[t] + "y"; };
  function fmt(v, d) {
    if (!isFinite(v)) return "–";
    var s = Math.abs(v).toFixed(d == null ? 2 : d), p = s.split(".");
    p[0] = p[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    return (v < 0 ? "−" : "") + p.join(".");
  }
  function rng(seed) { // mulberry32 with a polar-method normal
    var s = seed >>> 0;
    var u = function () { s += 0x6D2B79F5; var t = s; t = Math.imul(t ^ t >>> 15, t | 1); t ^= t + Math.imul(t ^ t >>> 7, t | 61); return ((t ^ t >>> 14) >>> 0) / 4294967296; };
    var spare = null;
    u.normal = function () {
      if (spare !== null) { var v = spare; spare = null; return v; }
      var a, b2, m; do { a = 2 * u() - 1; b2 = 2 * u() - 1; m = a * a + b2 * b2; } while (m >= 1 || m === 0);
      var f = Math.sqrt(-2 * Math.log(m) / m); spare = b2 * f; return a * f;
    };
    return u;
  }
  // ------------------------------------------------------------ maths
  var SQ2PI = Math.sqrt(2 * Math.PI);
  function pdf(x) { return Math.exp(-0.5 * x * x) / SQ2PI; }
  function cdf(x) { // Abramowitz–Stegun 26.2.17, |err| < 7.5e-8
    var z = Math.abs(x), t = 1 / (1 + 0.2316419 * z);
    var p = 1 - pdf(z) * t * (0.319381530 + t * (-0.356563782 + t * (1.781477937 + t * (-1.821255978 + t * 1.330274429))));
    return x >= 0 ? p : 1 - p;
  }
  function strad(F, K, s, tau) { // ATM-or-not straddle per unit annuity, bp units
    if (tau <= 0 || s <= 0) return { p: Math.abs(F - K), d: F > K ? 1 : F < K ? -1 : 0, g: 0, v: 0, th: 0 };
    var sq = Math.sqrt(tau), sd = s * sq, x = (F - K) / sd, n = pdf(x), N = cdf(x), g = 2 * n / sd;
    return { p: (F - K) * (2 * N - 1) + 2 * sd * n, d: 2 * N - 1, g: g, v: 2 * sq * n, th: -0.5 * s * s * g };
  }
  function interp(xs, ys, x) {
    if (x <= xs[0]) return ys[0];
    for (var i = 1; i < xs.length; i++) if (x <= xs[i]) return ys[i - 1] + (ys[i] - ys[i - 1]) * (x - xs[i - 1]) / (xs[i] - xs[i - 1]);
    return ys[ys.length - 1];
  }
  function nanArr(n) { var a = new Float64Array(n); a.fill(NaN); return a; }
  function roll(x, w, minp) { // trailing mean and sd, skipping NaN
    var n = x.length, m = nanArr(n), s = nanArr(n), a = 0, b = 0, k = 0;
    for (var i = 0; i < n; i++) {
      var v = x[i]; if (v === v) { a += v; b += v * v; k++; }
      if (i >= w) { var y = x[i - w]; if (y === y) { a -= y; b -= y * y; k--; } }
      if (k >= minp) { var mu = a / k; m[i] = mu; s[i] = k > 1 ? Math.sqrt(Math.max(0, (b - k * mu * mu) / (k - 1))) : NaN; }
    }
    return { m: m, s: s };
  }
  var LAST = null; // gap series, mode and rolling stats of the most recent score (read by backtest)
  function scoreFrom(gap, mode) {
    var r = roll(gap, 252, 60), out = nanArr(gap.length);
    LAST = { gap: gap, mode: mode, m: r.m, s: r.s };
    for (var i = 0; i < gap.length; i++) { var sd = r.s[i]; if (mode === "raw") out[i] = gap[i]; else if (sd > 0) out[i] = mode === "level" ? gap[i] / sd : (gap[i] - r.m[i]) / sd; }
    return out;
  }
  function rollBeta(a, b, w) { // slope of daily changes of a on b
    var n = a.length, out = nanArr(n), da = nanArr(n), db = nanArr(n);
    for (var i = 1; i < n; i++) { da[i] = a[i] - a[i - 1]; db[i] = b[i] - b[i - 1]; }
    var sx = 0, sy = 0, sxy = 0, sxx = 0, k = 0;
    for (var j = 0; j < n; j++) {
      if (da[j] === da[j] && db[j] === db[j]) { sx += db[j]; sy += da[j]; sxy += da[j] * db[j]; sxx += db[j] * db[j]; k++; }
      if (j >= w) { var p = j - w; if (da[p] === da[p] && db[p] === db[p]) { sx -= db[p]; sy -= da[p]; sxy -= da[p] * db[p]; sxx -= db[p] * db[p]; k--; } }
      if (k >= 40) { var vx = sxx - sx * sx / k; if (vx > 0) out[j] = Math.max(0.2, Math.min(3, (sxy - sx * sy / k) / vx)); }
    }
    return out;
  }
  function rollCorr(a, b, w) {
    var n = a.length, out = nanArr(n), sx = 0, sy = 0, sxy = 0, sxx = 0, syy = 0, k = 0;
    for (var j = 0; j < n; j++) {
      if (a[j] === a[j] && b[j] === b[j]) { sx += a[j]; sy += b[j]; sxy += a[j] * b[j]; sxx += a[j] * a[j]; syy += b[j] * b[j]; k++; }
      if (j >= w) { var p = j - w; if (a[p] === a[p] && b[p] === b[p]) { sx -= a[p]; sy -= b[p]; sxy -= a[p] * b[p]; sxx -= a[p] * a[p]; syy -= b[p] * b[p]; k--; } }
      if (k >= 30) { var cv = sxy - sx * sy / k, vx = sxx - sx * sx / k, vy = syy - sy * sy / k; if (vx > 0 && vy > 0) out[j] = cv / Math.sqrt(vx * vy); }
    }
    return out;
  }

  // ------------------------------------------------------------ data
  function newMD(dates, source) {
    var n = dates.length, md = { dates: dates, n: n, source: source, ccys: [], F: {}, V: {}, A: {}, S: {}, C: {}, spread: {}, ev: {}, evx: {}, cache: {} };
    return md;
  }
  function loadings(m) { return [0.75 + 0.25 * Math.exp(-m / 8), Math.exp(-m / 3) - 0.35]; }

  function generate(seed) {
    var r = rng(seed || 27), n = 252 * 6, dates = [], day = new Date(Date.UTC(2026, 10, 6));
    while (dates.length < n) { var w = day.getUTCDay(); if (w !== 0 && w !== 6) dates.push(day.toISOString().slice(0, 10)); day = new Date(day.getTime() - 864e5); }
    dates.reverse();
    var md = newMD(dates, "illustrative"), dt = 1 / 252, sq = Math.sqrt(dt);
    var common = []; for (var i = 0; i < n; i++) common.push([r.normal(), r.normal(), r.normal()]);
    CCYS.forEach(function (c, k) {
      var Lv = LEVELS[c], lv = new Float64Array(n), evx = new Uint8Array(n + 260), off = 5 + ((seed + 7 * k) % 25);
      for (var e0 = off; e0 < n + 260; e0 += 31) evx[e0] = 1;
      var ev = evx.subarray(0, n);
      for (i = 1; i < n; i++) { lv[i] = lv[i - 1] - 3 * dt * (lv[i - 1] + 0.12) + 0.9 * sq * (0.6 * common[i][2] + 0.8 * r.normal()); if (r() < 1.2 / 252) lv[i] += 0.4 + 0.4 * r(); }
      var L = new Float64Array(n), S = new Float64Array(n);
      for (i = 1; i < n; i++) {
        var m = Math.exp(lv[i]), bo = ev[i] ? 2.6 : 1;
        L[i] = L[i - 1] * 0.998 + m * sq * bo * (0.55 * common[i][0] + 0.835 * r.normal());
        S[i] = S[i - 1] * 0.998 + 0.45 * m * sq * (ev[i] ? 1.8 : 1) * (0.55 * common[i][1] + 0.835 * r.normal());
      }
      var F = new Float64Array(n * NE * NT), V = new Float64Array(n * NE * NT), A = new Float64Array(n * NE * NT), Sk = new Float64Array(n * NE * NT), Cv = new Float64Array(n * NE * NT);
      // planted, mean-reverting dislocations (what an RV screen should find)
      var disl = function (e, t) {
        if (c === "GBP" && t === 4) return 0.06;              // long-tail receiver demand (LDI)
        if (c === "EUR" && e === 3 && t === 3) return 0.04;   // 1y10y rich
        if (c === "USD" && e >= 5 && t >= 3) return -0.05;    // vega supply, lower right cheap
        return 0;
      };
      var ou = new Float64Array(NE * NT), noise = new Float64Array(NE * NT), vrp = 0.07;
      for (i = 0; i < n; i++) {
        vrp += -dt * 2 * (vrp - 0.07) + 0.08 * sq * r.normal();
        var smileS = 0.04 + 0.02 * Math.sin(i / 90 + k), smileC = 1.5e-4 * (1 + 0.3 * Math.sin(i / 140 + 2 * k));
        for (var e = 0; e < NE; e++) {
          var E = ET[e], decay = (1 - Math.exp(-3 * E)) / (3 * E), nIn = 0;
          if (E <= 0.5) { for (var q = i + 1, h = Math.round(E * 252); q <= i + h; q++) if (evx[q]) nIn++; }
          else nIn = 8 * E;
          var evShare = 1 + nIn * 1.25 * (2.6 * 2.6 - 1) / (252 * E);
          for (var t = 0; t < NT; t++) {
            var mm = E + TAILS[t] / 2, ld = loadings(mm), unit = Math.sqrt(ld[0] * ld[0] + 0.2025 * ld[1] * ld[1]);
            var target = Lv.grid[e][t] / 1.12 / Math.sqrt(1 + 8 * (2.6 * 2.6 - 1) / 252), kk = target / unit, j = e * NT + t;
            var x = IX(i, e, t);
            F[x] = Lv.rate * 100 - 30 + 60 * (1 - Math.exp(-mm / 5)) + kk * (ld[0] * L[i] + ld[1] * S[i]);
            ou[j] += -dt * 6 * ou[j] + 0.07 * sq * r.normal();
            noise[j] = 0.94 * noise[j] + 0.45 * r.normal();
            V[x] = Math.max(8, target * Math.exp(lv[i] * decay + (1 - decay) * 0.18) * Math.sqrt(evShare) * (1 + vrp) * (1 + disl(e, t) + ou[j] * (disl(e, t) ? 1 : 0.25)) + noise[j]);
            var rr = F[x] / 1e4, a = 0; for (var y = 1; y <= TAILS[t]; y++) a += Math.exp(-rr * (E + y));
            A[x] = a; Sk[x] = smileS; Cv[x] = smileC;
          }
        }
      }
      // 2s10s spread-option vols with a correlation premium
      var sp = new Float64Array(n * NE);
      for (i = 0; i < n; i++) for (e = 0; e < NE; e++) {
        var la = loadings(ET[e] + 1), lb = loadings(ET[e] + 5), ua = Math.sqrt(la[0] * la[0] + 0.2025 * la[1] * la[1]), ub = Math.sqrt(lb[0] * lb[0] + 0.2025 * lb[1] * lb[1]);
        var rho = (la[0] * lb[0] + 0.2025 * la[1] * lb[1]) / (ua * ub) - (0.05 + 0.04 * Math.sin(i / 120 + 2 * k));
        var sa = V[IX(i, e, 1)], sb = V[IX(i, e, 3)];
        sp[i * NE + e] = Math.sqrt(Math.max(1, sa * sa + sb * sb - 2 * rho * sa * sb));
      }
      md.ccys.push(c); md.F[c] = F; md.V[c] = V; md.A[c] = A; md.S[c] = Sk; md.C[c] = Cv; md.spread[c] = sp; md.ev[c] = ev; md.evx[c] = evx;
      md.fac = md.fac || {}; md.fac[c] = { L: L, S: S, lv: lv, common: common };
    });
    md.hasSmile = true;
    return md;
  }

  function parseCSV(txt) {
    var lines = String(txt).replace(/\r/g, "").split("\n").filter(function (l) { return l.trim(); });
    var head = lines.shift().split(",").map(function (h) { return h.trim().toLowerCase(); });
    return lines.map(function (l) { var p = l.split(","), o = {}; head.forEach(function (h, i) { o[h] = (p[i] || "").trim(); }); return o; });
  }
  function tenorY(s) { s = String(s).trim().toUpperCase(); var u = s.slice(-1), v = parseFloat(s); return u === "M" ? v / 12 : u === "W" ? v * 7 / 365 : u === "Y" ? v : parseFloat(s); }
  function gridIdx(arr, y) { for (var i = 0; i < arr.length; i++) if (Math.abs(arr[i] - y) < 1e-3) return i; return -1; }

  function fromCSV(surfTxt, evTxt, spTxt) {
    var rows = parseCSV(surfTxt);
    var pick = function (o, names) { for (var i = 0; i < names.length; i++) if (o[names[i]] !== undefined && o[names[i]] !== "") return o[names[i]]; return ""; };
    var dset = {}; rows.forEach(function (o) { dset[o.date] = 1; });
    var dates = Object.keys(dset).sort(), di = {}; dates.forEach(function (d, i) { di[d] = i; });
    var md = newMD(dates, "your data"), n = dates.length, smile = false;
    var ccys = {}; rows.forEach(function (o) { ccys[String(o.ccy).toUpperCase()] = 1; });
    Object.keys(ccys).forEach(function (c) {
      var arr = {}; ["F", "V", "A", "S", "C"].forEach(function (k) { arr[k] = nanArr(n * NE * NT); });
      rows.forEach(function (o) {
        if (String(o.ccy).toUpperCase() !== c) return;
        var e = gridIdx(ET, tenorY(o.expiry)), t = gridIdx(TAILS, tenorY(o.tail)); if (e < 0 || t < 0) return;
        var x = IX(di[o.date], e, t), f = parseFloat(pick(o, ["fwd_pct", "fwd", "forward"]));
        arr.F[x] = f * 100; arr.V[x] = parseFloat(pick(o, ["vol_bp", "vol", "normal_vol"]));
        var a = parseFloat(pick(o, ["annuity"])); arr.A[x] = a;
        var s = parseFloat(pick(o, ["skew"])), cv = parseFloat(pick(o, ["curv", "curvature"]));
        arr.S[x] = isFinite(s) ? s : 0; arr.C[x] = isFinite(cv) ? cv : 0; if (isFinite(cv) && cv !== 0) smile = true;
      });
      for (var e = 0; e < NE; e++) for (var t = 0; t < NT; t++) { // forward-fill, then back-fill each node
        ["F", "V", "A", "S", "C"].forEach(function (k) {
          var a = arr[k], last = NaN, first = NaN, i;
          for (i = 0; i < n; i++) { var x = IX(i, e, t); if (a[x] === a[x]) { last = a[x]; if (first !== first) first = last; } else a[x] = last; }
          for (i = 0; i < n && a[IX(i, e, t)] !== a[IX(i, e, t)]; i++) a[IX(i, e, t)] = first;
        });
      }
      ["F", "V", "A", "S", "C"].forEach(function (k) { // expiries never quoted: take the nearest quoted expiry on the same tail
        var a = arr[k];
        for (var t = 0; t < NT; t++) for (var e = 0; e < NE; e++) {
          if (a[IX(0, e, t)] === a[IX(0, e, t)]) continue;
          for (var dd = 1; dd < NE; dd++) {
            var src = [e - dd, e + dd].filter(function (q) { return q >= 0 && q < NE && a[IX(0, q, t)] === a[IX(0, q, t)]; })[0];
            if (src !== undefined) { for (var i = 0; i < n; i++) a[IX(i, e, t)] = a[IX(i, src, t)]; break; }
          }
        }
      });
      for (var i = 0; i < n; i++) for (e = 0; e < NE; e++) for (t = 0; t < NT; t++) { // annuity from forward if missing
        var x = IX(i, e, t); if (!(arr.A[x] > 0) && arr.F[x] === arr.F[x]) { var rr = arr.F[x] / 1e4, a = 0; for (var y = 1; y <= TAILS[t]; y++) a += Math.exp(-rr * (ET[e] + y)); arr.A[x] = a; }
      }
      md.ccys.push(c); md.F[c] = arr.F; md.V[c] = arr.V; md.A[c] = arr.A; md.S[c] = arr.S; md.C[c] = arr.C;
      md.evx[c] = new Uint8Array(n + 260); md.ev[c] = md.evx[c].subarray(0, n);
    });
    md.hasSmile = smile; md.hasEvents = false;
    if (evTxt) {
      var lastD = new Date(dates[n - 1] + "T00:00:00Z");
      parseCSV(evTxt).forEach(function (o) {
        var c = String(o.ccy).toUpperCase(); if (!md.evx[c]) return;
        var k = di[o.date];
        if (k === undefined && o.date > dates[n - 1]) { // future meeting: count business days after the last date
          var x = new Date(o.date + "T00:00:00Z"), b = 0; for (var q = new Date(lastD.getTime() + 864e5); q <= x; q = new Date(q.getTime() + 864e5)) { var w = q.getUTCDay(); if (w && w !== 6) b++; }
          k = n - 1 + b;
        }
        if (k !== undefined && k < n + 260) { md.evx[c][k] = 1; md.hasEvents = true; }
      });
    }
    if (spTxt) {
      parseCSV(spTxt).forEach(function (o) {
        var c = String(o.ccy).toUpperCase(), e = gridIdx(ET, tenorY(o.expiry)); if (!md.V[c] || e < 0 || di[o.date] === undefined) return;
        if (!md.spread[c]) md.spread[c] = nanArr(n * NE);
        md.spread[c][di[o.date] * NE + e] = parseFloat(o.spread_vol_bp || o.spread_vol || o.vol);
      });
    }
    return md;
  }

  // ------------------------------------------------------------ market access
  function col(md, arr, c, d, t) { var a = arr[c], o = new Array(NE); for (var e = 0; e < NE; e++) o[e] = a[IX(d, e, t)]; return o; }
  function nodeAt(md, c, d, tau, t) {
    return { F: interp(ET, col(md, md.F, c, d, t), tau), V: interp(ET, col(md, md.V, c, d, t), tau), A: interp(ET, col(md, md.A, c, d, t), tau),
      S: interp(ET, col(md, md.S, c, d, t), tau), C: interp(ET, col(md, md.C, c, d, t), tau) };
  }
  function series(md, arr, c, e, t) { var o = new Float64Array(md.n); for (var d = 0; d < md.n; d++) o[d] = arr[c][IX(d, e, t)]; return o; }
  function dFixed(md, c) { // change of the fixed forward an option at grid expiry e sits on
    var k = "dF" + c; if (md.cache[k]) return md.cache[k];
    var out = nanArr(md.n * NE * NT), dt = 1 / 252;
    for (var d = 1; d < md.n; d++) for (var t = 0; t < NT; t++) {
      var colF = col(md, md.F, c, d, t);
      for (var e = 0; e < NE; e++) out[IX(d, e, t)] = interp(ET, colF, Math.max(ET[e] - dt, 0)) - md.F[c][IX(d - 1, e, t)];
    }
    return (md.cache[k] = out);
  }
  function realised(md, c, e, t, w, exEvents) {
    var k = "rv" + c + e + t + w + (exEvents ? "x" : ""); if (md.cache[k]) return md.cache[k];
    var dF = dFixed(md, c), sq = new Float64Array(md.n), ev = md.ev[c];
    for (var d = 0; d < md.n; d++) { var v = dF[IX(d, e, t)]; sq[d] = exEvents && ev[d] ? NaN : v * v; }
    var m = roll(sq, w, Math.max(5, w >> 1)).m, o = new Float64Array(md.n);
    for (d = 0; d < md.n; d++) o[d] = Math.sqrt(252 * m[d]);
    return (md.cache[k] = o);
  }
  function forecast(md, c, e, t) {
    var k = "har" + c + e + t; if (md.cache[k]) return md.cache[k];
    var a = realised(md, c, e, t, 5), b = realised(md, c, e, t, 22), g = realised(md, c, e, t, 66), o = new Float64Array(md.n);
    for (var d = 0; d < md.n; d++) o[d] = Math.sqrt(0.3 * a[d] * a[d] + 0.4 * b[d] * b[d] + 0.3 * g[d] * g[d]);
    return (md.cache[k] = o);
  }

  // ------------------------------------------------------------ candidates
  // score > 0 means buy the "long" structure; legs are the long structure in vega units.
  function leg(c, e, t, w, kind) { return { c: c, E: ET[e], t: t, w: w, kind: kind || "straddle" }; }
  function candidates(md) {
    var C = [], sp = function (o) { C.push(o); };
    md.ccys.forEach(function (c) {
      for (var e = 0; e <= 5; e++) for (var t = 0; t < NT; t++) (function (e, t) {
        sp({ id: "S1." + c + nodeName(e, t), fam: "S1", ccy: c, name: c + " " + nodeName(e, t) + " straddle vs forecast realised", longTxt: "buy " + c + " " + nodeName(e, t) + " straddle", shortTxt: "sell " + c + " " + nodeName(e, t) + " straddle", node: [e, t],
          compute: function () { var v = series(md, md.V, c, e, t), f = forecast(md, c, e, t), g = new Float64Array(md.n); for (var d = 0; d < md.n; d++) g[d] = f[d] - v[d]; return scoreFrom(g, "level"); },
          legs: function () { return [leg(c, e, t, 1)]; },
          why: function (d) { var v = md.V[c][IX(d, e, t)], f = forecast(md, c, e, t)[d]; return "Implied " + fmt(v, 1) + "bp against a realised forecast of " + fmt(f, 1) + "bp on the fixed forward (blend of 5, 22 and 66-day realised): a gap of " + fmt(v - f, 1) + "bp."; } });
        if (md.hasSmile) sp({ id: "S2." + c + nodeName(e, t), fam: "S2", ccy: c, name: c + " " + nodeName(e, t) + " straddle vs smile-adjusted breakeven", longTxt: "buy " + c + " " + nodeName(e, t) + " straddle", shortTxt: "sell " + c + " " + nodeName(e, t) + " straddle", node: [e, t],
          compute: function () { var f = forecast(md, c, e, t), g = new Float64Array(md.n); for (var d = 0; d < md.n; d++) { var x = IX(d, e, t), v = md.V[c][x]; g[d] = f[d] - v / Math.sqrt(1 + 2 * md.C[c][x] * v * ET[e]); } return scoreFrom(g, "level"); },
          legs: function () { return [leg(c, e, t, 1)]; },
          why: function (d) { var x = IX(d, e, t), v = md.V[c][x], be = v / Math.sqrt(1 + 2 * md.C[c][x] * v * ET[e]); return "Implied " + fmt(v, 1) + "bp, but with smile curvature " + fmt(md.C[c][x] * 1e4, 2) + "bp per 100bp² a fixed-strike straddle only needs " + fmt(be, 1) + "bp realised to break even (σ/√(1+2cσT)). Forecast realised: " + fmt(forecast(md, c, e, t)[d], 1) + "bp."; } });
      })(e, t);
      // S3 grid carry
      (function () {
        var carry = null, calc = function () {
          if (carry) return carry; carry = nanArr(md.n * NE * NT);
          for (var d = 0; d < md.n; d++) for (var e = 1; e <= 5; e++) for (var t = 0; t < NT; t++) {
            var x = IX(d, e, t), v = md.V[c][x], f = forecast(md, c, e, t)[d], vp = md.V[c][IX(d, e - 1, t)];
            carry[x] = ((f * f - v * v) / (2 * v * ET[e]) - (v - vp) / (ET[e] - ET[e - 1])) / 252;
          }
          return carry;
        };
        var best = function (d) { var cr = calc(), hi = -1e9, lo = 1e9, bh, bl; for (var e = 1; e <= 5; e++) for (var t = 0; t < NT; t++) { var v = cr[IX(d, e, t)]; if (!(v === v)) continue; if (v > hi) { hi = v; bh = [e, t]; } if (v < lo) { lo = v; bl = [e, t]; } } return { hi: hi, lo: lo, h: bh, l: bl }; };
        sp({ id: "S3." + c, fam: "S3", ccy: c, name: c + " grid carry: best long-vol cell vs worst", longTxt: "buy the top-carry cell, sell the bottom-carry cell (vega-neutral)", shortTxt: "sell the top-carry cell, buy the bottom-carry cell",
          compute: function () { var g = nanArr(md.n); for (var d = 0; d < md.n; d++) { var b = best(d); if (b.h) g[d] = b.hi - b.lo; } return scoreFrom(g, "level"); },
          legs: function (d) { var b = best(d); return [leg(c, b.h[0], b.h[1], 1), leg(c, b.l[0], b.l[1], -1)]; },
          why: function (d) { var b = best(d); return b.h ? "Expected daily carry of a long delta-hedged straddle, per unit of vega (gamma minus theta at the realised forecast, plus roll-down): best " + nodeName(b.h[0], b.h[1]) + " at " + fmt(b.hi * 100, 2) + " vol bp per 100 days, worst " + nodeName(b.l[0], b.l[1]) + " at " + fmt(b.lo * 100, 2) + "." : ""; } });
      })();
      // S4 forward vs spot vol
      for (var t4 = 0; t4 < NT; t4++) for (var e4 = 1; e4 <= 4; e4++) (function (e1, e2, t) {
        var fv = function (d) { var s1 = md.V[c][IX(d, e1, t)], s2 = md.V[c][IX(d, e2, t)]; return Math.sqrt(Math.max(1, (s2 * s2 * ET[e2] - s1 * s1 * ET[e1]) / (ET[e2] - ET[e1]))); };
        var spot = function (d) { return interp(ET, col(md, md.V, c, d, t), ET[e2] - ET[e1]); };
        sp({ id: "S4." + c + EXPN[e1] + EXPN[e2] + TAILS[t], fam: "S4", ccy: c, name: c + " " + EXPN[e1] + "→" + EXPN[e2] + " forward vol on the " + TAILS[t] + "y tail", longTxt: "buy " + nodeName(e2, t) + ", sell " + nodeName(e1, t) + " (long forward vol)", shortTxt: "sell " + nodeName(e2, t) + ", buy " + nodeName(e1, t) + " (short forward vol)",
          compute: function () { var g = new Float64Array(md.n); for (var d = 0; d < md.n; d++) g[d] = spot(d) - fv(d); return scoreFrom(g, "z"); },
          legs: function () { return [leg(c, e2, t, 1), leg(c, e1, t, -1)]; },
          why: function (d) { return "Forward vol from " + EXPN[e1] + " to " + EXPN[e2] + " is " + fmt(fv(d), 1) + "bp against " + fmt(spot(d), 1) + "bp spot vol for the same gap today, measured against its own one-year history."; } });
      })(e4, e4 + 1, t4);
      // S5t tail pairs
      for (var e5 = 1; e5 <= 5; e5++) for (var t5 = 0; t5 < NT - 1; t5++) sp(ratioPair(md, [c, e5, t5 + 1], [c, e5, t5], "S5t"));
      // S6 implied correlation
      if (md.spread[c]) for (var e6 = 1; e6 <= 4; e6++) (function (e) {
        var rr = null, rho = function (d) { var sa = md.V[c][IX(d, e, 1)], sb = md.V[c][IX(d, e, 3)], ss = md.spread[c][d * NE + e]; return (sa * sa + sb * sb - ss * ss) / (2 * sa * sb); };
        var real = function () { if (rr) return rr; var dF = dFixed(md, c), a = new Float64Array(md.n), b = new Float64Array(md.n); for (var d = 0; d < md.n; d++) { a[d] = dF[IX(d, e, 1)]; b[d] = dF[IX(d, e, 3)]; } return (rr = rollCorr(a, b, 66)); };
        sp({ id: "S6." + c + EXPN[e], fam: "S6", ccy: c, name: c + " " + EXPN[e] + " 2s10s implied vs realised correlation", longTxt: "buy " + EXPN[e] + " 2s10s spread straddle, sell leg straddles", shortTxt: "sell " + EXPN[e] + " 2s10s spread straddle, buy leg straddles",
          compute: function () { var g = new Float64Array(md.n), r = real(); for (var d = 0; d < md.n; d++) g[d] = rho(d) - r[d]; return scoreFrom(g, "level"); },
          legs: function (d) { var sa = md.V[c][IX(d, e, 1)], sb = md.V[c][IX(d, e, 3)], ss = md.spread[c][d * NE + e], r = rho(d); return [{ c: c, E: ET[e], t: 1, t2: 3, w: 1, kind: "spread" }, leg(c, e, 1, -(sa - r * sb) / ss), leg(c, e, 3, -(sb - r * sa) / ss)]; },
          why: function (d) { return "Spread-option vol implies a 2y/10y correlation of " + fmt(rho(d), 3) + " against " + fmt(real()[d], 3) + " realised over 66 days."; } });
      })(e6);
      // S7 event premium
      if (md.hasEvents !== false) [0, 1].forEach(function (t) {
        var g = null, calc = function () {
          if (g) return g; var base = realised(md, c, 0, t, 66, true), dF = dFixed(md, c), ev = md.ev[c], last = [], es = nanArr(md.n);
          for (var d = 0; d < md.n; d++) { if (ev[d] && dF[IX(d, 0, t)] === dF[IX(d, 0, t)]) { last.push(dF[IX(d, 0, t)] * dF[IX(d, 0, t)]); if (last.length > 8) last.shift(); } if (last.length >= 3) es[d] = last.reduce(function (a, b) { return a + b; }, 0) / last.length; }
          g = nanArr(md.n); var nIn = new Int32Array(md.n);
          for (d = 0; d < md.n; d++) { var k = 0, evx = md.evx[c]; for (var q = d + 1; q <= d + 21; q++) if (evx[q]) k++; nIn[d] = k; var fc = base[d] * base[d] / 252 * Math.max(21 - k, 1) + k * es[d], iv = md.V[c][IX(d, 0, t)]; g[d] = Math.log(fc / (iv * iv / 12)); }
          g.nIn = nIn; g.es = es; return g;
        };
        sp({ id: "S7." + c + TAILS[t], fam: "S7", ccy: c, name: c + " 1m" + TAILS[t] + "y event premium (" + CB[c] + ")", longTxt: "buy " + c + " 1m" + TAILS[t] + "y straddle", shortTxt: "sell " + c + " 1m" + TAILS[t] + "y straddle", node: [0, t],
          compute: function () { return scoreFrom(calc(), "level"); },
          legs: function () { return [leg(c, 0, t, 1)]; },
          why: function (d) { var x = calc(); return x.nIn[d] + " event day" + (x.nIn[d] === 1 ? "" : "s") + " in the next month. Past event days moved " + fmt(Math.sqrt(x.es[d]), 1) + "bp (root mean square of the last 8); implied 1m vol is " + fmt(md.V[c][IX(d, 0, t)], 1) + "bp."; } });
      });
      // S8 vol vs curve residual
      [[1, 1], [1, 3], [3, 1], [3, 3]].forEach(function (p) {
        var e = p[0], t = p[1], res = null, calc = function () {
          if (res) return res; res = nanArr(md.n); var W = 252, s = new Float64Array(9), xs = [], v = series(md, md.V, c, e, t);
          var X1 = series(md, md.F, c, e, t), X2 = new Float64Array(md.n); for (var d = 0; d < md.n; d++) X2[d] = md.F[c][IX(d, e, 3)] - md.F[c][IX(d, e, 1)];
          var add = function (d, sg) { var a = X1[d], b = X2[d], y = v[d]; s[0] += sg; s[1] += sg * a; s[2] += sg * b; s[3] += sg * a * a; s[4] += sg * a * b; s[5] += sg * b * b; s[6] += sg * y; s[7] += sg * a * y; s[8] += sg * b * y; };
          for (d = 0; d < md.n; d++) {
            if (d >= W) {
              var M = [[s[0], s[1], s[2]], [s[1], s[3], s[4]], [s[2], s[4], s[5]]], rhs = [s[6], s[7], s[8]], beta = solve3(M, rhs);
              if (beta) res[d] = v[d] - (beta[0] + beta[1] * X1[d] + beta[2] * X2[d]);
              add(d - W, -1);
            }
            add(d, 1);
          }
          return res;
        };
        sp({ id: "S8." + c + nodeName(e, t), fam: "S8", ccy: c, name: c + " " + nodeName(e, t) + " vol vs rate level and 2s10s", longTxt: "buy " + c + " " + nodeName(e, t) + " straddle", shortTxt: "sell " + c + " " + nodeName(e, t) + " straddle", node: [e, t],
          compute: function () { var r = calc(), g = new Float64Array(md.n); for (var d = 0; d < md.n; d++) g[d] = -r[d]; return scoreFrom(g, "z"); },
          legs: function () { return [leg(c, e, t, 1)]; },
          why: function (d) { return "After a one-year regression of " + nodeName(e, t) + " vol on the forward level and the 2s10s slope, vol sits " + fmt(calc()[d], 1) + "bp " + (calc()[d] > 0 ? "above" : "below") + " the fitted value."; } });
      });
    });
    // S5x cross-currency pairs
    for (var a = 0; a < md.ccys.length; a++) for (var b = a + 1; b < md.ccys.length; b++) for (var e = 1; e <= 5; e++) for (var t = 0; t < NT; t++) C.push(ratioPair(md, [md.ccys[a], e, t], [md.ccys[b], e, t], "S5x"));
    return C;
  }
  function solve3(M, b) {
    var det = function (m) { return m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1]) - m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0]) + m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0]); };
    var D = det(M); if (Math.abs(D) < 1e-9) return null;
    return [0, 1, 2].map(function (k) { var m = M.map(function (r, i) { return r.map(function (v, j) { return j === k ? b[i] : v; }); }); return det(m) / D; });
  }
  function ratioPair(md, A, B, fam) {
    var ca = A[0], ea = A[1], ta = A[2], cb = B[0], eb = B[1], tb = B[2], beta = null;
    var la = ca + " " + nodeName(ea, ta), lb = cb + " " + nodeName(eb, tb);
    var getBeta = function () { return beta || (beta = rollBeta(series(md, md.V, ca, ea, ta), series(md, md.V, cb, eb, tb), 120)); };
    return { id: fam + "." + la + "/" + lb, fam: fam, ccy: ca === cb ? ca : ca + "/" + cb, name: la + " vs " + lb + " vol ratio", longTxt: "buy " + la + ", sell " + lb + " (beta-weighted vega)", shortTxt: "sell " + la + ", buy " + lb + " (beta-weighted vega)", pair: [A, B],
      compute: function () {
        var ra = realised(md, ca, ea, ta, 66), rb = realised(md, cb, eb, tb, 66), g = new Float64Array(md.n);
        for (var d = 0; d < md.n; d++) g[d] = Math.log(md.V[cb][IX(d, eb, tb)] / md.V[ca][IX(d, ea, ta)]) - Math.log(rb[d] / ra[d]);
        return scoreFrom(g, "z");
      },
      legs: function (d) { var b = getBeta()[d]; return [leg(ca, ea, ta, 1), leg(cb, eb, tb, -(b === b ? b : 1))]; },
      why: function (d) { var va = md.V[ca][IX(d, ea, ta)], vb = md.V[cb][IX(d, eb, tb)], ra = realised(md, ca, ea, ta, 66)[d], rb = realised(md, cb, eb, tb, 66)[d]; return "Implied ratio " + fmt(va / vb, 3) + " (" + fmt(va, 1) + "/" + fmt(vb, 1) + "bp) against a 66-day realised ratio of " + fmt(ra / rb, 3) + ". Vol beta of " + la + " on " + lb + ": " + fmt(getBeta()[d], 2) + "."; } };
  }

  // ------------------------------------------------------------ engine
  function halfBO(L) { var bo = L.E >= 2 ? 0.7 : 0.4; if (TAILS[L.t] >= 30) bo += 0.3; return L.kind === "spread" ? bo * 1.5 : bo; }
  function legMark(md, L, d) {
    var tau = (L.exp - d) / 252, F, s, A;
    if (L.kind === "spread") {
      F = interp(ET, col(md, md.F, L.c, d, L.t2), Math.max(tau, 0)) - interp(ET, col(md, md.F, L.c, d, L.t), Math.max(tau, 0));
      var sv = []; for (var e = 0; e < NE; e++) sv.push(md.spread[L.c][d * NE + e]); s = interp(ET, sv, Math.max(tau, 0)); A = 1;
    } else {
      var nd = nodeAt(md, L.c, d, Math.max(tau, 0), L.t), m = L.K - nd.F; F = nd.F; A = nd.A; s = Math.max(1, nd.V + nd.S * m + nd.C * m * m);
    }
    var g = strad(F, L.K, s, tau), u = L.N * A * 1e-4;
    return { F: F, s: s, tau: tau, V: g.p * u, D: g.d * u, G: g.g * u, Vg: g.v * u, Th: g.th * u };
  }
  function openLegs(md, cand, d, dir, vega) {
    return cand.legs(d).map(function (spec) {
      var F, s, A;
      if (spec.kind === "spread") { F = md.F[spec.c][IX(d, ET.indexOf(spec.E), spec.t2)] - md.F[spec.c][IX(d, ET.indexOf(spec.E), spec.t)]; s = md.spread[spec.c][d * NE + ET.indexOf(spec.E)]; A = 1; }
      else { var x = IX(d, ET.indexOf(spec.E), spec.t); F = md.F[spec.c][x]; s = md.V[spec.c][x]; A = md.A[spec.c][x]; }
      var vpn = 2 * Math.sqrt(spec.E) * pdf(0) * A * 1e-4;
      var L = { c: spec.c, E: spec.E, t: spec.t, t2: spec.t2, kind: spec.kind, K: F, exp: d + Math.round(spec.E * 252), N: dir * spec.w * vega / vpn, s0: s };
      L.last = legMark(md, L, d); L.h = -L.last.D; return L;
    });
  }
  function backtest(md, cand, o) {
    if (!cand.score) { cand.score = cand.compute(); if (LAST) { cand.gap = LAST.gap; cand.mode = LAST.mode; cand.gm = LAST.m; cand.gs = LAST.s; } }
    var sc = cand.score, n = md.n, daily = new Float64Array(n), cost = new Float64Array(n);
    var comp = { theta: 0, gamma: 0, vega: 0, resid: 0, hedge: 0, cost: 0 }, trades = [], pos = null, hc = 0.1 * o.cost;
    var exitCost = function (p) { return p.legs.reduce(function (a, L) { return a + (Math.abs(L.last.Vg) * halfBO(L) + Math.abs(L.h) * 0.1) * o.cost; }, 0); };
    for (var d = 1; d < n; d++) {
      if (pos) {
        pos.legs.forEach(function (L) {
          var p0 = L.last, p1 = legMark(md, L, d), dF = p1.F - p0.F, th = p0.Th / 252, ga = 0.5 * p0.G * dF * dF, ve = p0.Vg * (p1.s - p0.s), de = p0.D * dF;
          var tot = p1.V - p0.V + L.h * dF, nh = -p1.D, c = Math.abs(nh - L.h) * hc;
          comp.theta += th; comp.gamma += ga; comp.vega += ve; comp.resid += (p1.V - p0.V) - (th + ga + ve + de); comp.hedge += de + L.h * dF; comp.cost -= c;
          daily[d] += tot - c; cost[d] -= c; pos.pnl += tot - c; L.h = nh; L.last = p1;
        });
        var s = sc[d], held = d - pos.d0, minTau = Math.min.apply(null, pos.legs.map(function (L) { return L.exp - d; })), why = null;
        if (s === s && pos.dir * s < o.zout) why = "signal"; else if (held >= o.hold) why = "max hold"; else if (minTau <= 5) why = "expiry";
        if (why || d === n - 1) {
          var xc = exitCost(pos); daily[d] -= xc; cost[d] -= xc; comp.cost -= xc; pos.pnl -= xc;
          trades.push({ d0: pos.d0, d1: d, dir: pos.dir, pnl: pos.pnl, why: why || "end", s0: pos.s0, s1: s }); pos = null;
        }
      }
      if (!pos && d >= o.from && d < n - 1) {
        var s2 = sc[d];
        if (s2 === s2 && Math.abs(s2) >= o.zin) {
          var dir = s2 > 0 ? 1 : -1, legs;
          try { legs = openLegs(md, cand, d, dir, o.vega); } catch (err) { legs = null; }
          if (legs && legs.every(function (L) { return isFinite(L.N) && isFinite(L.last.V); })) {
            var ec = legs.reduce(function (a, L) { return a + (Math.abs(L.last.Vg) * halfBO(L) + Math.abs(L.h) * 0.1) * o.cost; }, 0);
            pos = { legs: legs, dir: dir, d0: d, pnl: -ec, s0: s2 }; daily[d] -= ec; cost[d] -= ec; comp.cost -= ec;
          }
        }
      }
    }
    return { daily: daily, cost: cost, comp: comp, trades: trades, score: sc };
  }
  function benchmark(md, c, o) { // rolling short 3m2y straddle
    var b = { id: "BM." + c, compute: function () { var a = new Float64Array(md.n); a.fill(-10); return a; }, legs: function () { return [leg(c, 1, 1, 1)]; } };
    return backtest(md, b, { zin: 1, zout: -1e9, hold: o.hold, vega: o.vega, cost: o.cost, from: o.from }).daily;
  }
  function unitForward(md, cand, o) { // for the information coefficient (gate 1)
    var out = [], H = [5, 10, 20];
    for (var d = o.from; d < md.n - 21; d += 5) {
      var s = cand.score[d]; if (!(s === s)) continue;
      var legs; try { legs = openLegs(md, cand, d, 1, o.vega); } catch (e) { continue; }
      var cum = 0, rec = { s: s };
      for (var h = 1; h <= 20; h++) {
        legs.forEach(function (L) { var p1 = legMark(md, L, d + h); cum += p1.V - L.last.V + L.h * (p1.F - L.last.F); L.h = -p1.D; L.last = p1; });
        if (H.indexOf(h) >= 0) rec["h" + h] = cum;
      }
      if (isFinite(cum)) out.push(rec);
    }
    return out;
  }
  function spearman(x, y) {
    var rk = function (a) { var idx = a.map(function (v, i) { return i; }).sort(function (i, j) { return a[i] - a[j]; }), r = new Array(a.length); idx.forEach(function (i, k) { r[i] = k; }); return r; };
    var rx = rk(x), ry = rk(y), n = x.length, mx = (n - 1) / 2, sxy = 0, sxx = 0;
    for (var i = 0; i < n; i++) { sxy += (rx[i] - mx) * (ry[i] - mx); sxx += (rx[i] - mx) * (rx[i] - mx); }
    return sxx > 0 ? sxy / sxx : NaN;
  }

  // ------------------------------------------------------------ statistics
  function stats(md, bt, bench, o) {
    var p = Array.prototype.slice.call(bt.daily, o.from), n = p.length, mu = 0, i;
    for (i = 0; i < n; i++) mu += p[i]; mu /= n;
    var v = 0; for (i = 0; i < n; i++) v += (p[i] - mu) * (p[i] - mu); v /= (n - 1);
    var sd = Math.sqrt(v), sharpe = sd > 0 ? mu / sd * Math.sqrt(252) : NaN;
    var nw = function (x) { var m = 0, k, L = 10; for (k = 0; k < x.length; k++) m += x[k]; m /= x.length; var s = 0; for (k = 0; k < x.length; k++) s += (x[k] - m) * (x[k] - m); s /= x.length; for (var l = 1; l <= L; l++) { var c = 0; for (k = l; k < x.length; k++) c += (x[k] - m) * (x[k - l] - m); s += 2 * (1 - l / (L + 1)) * c / x.length; } return s > 0 ? m / Math.sqrt(s / x.length) : NaN; };
    var cum = 0, peak = 0, dd = 0, w20 = 0, run = 0;
    for (i = 0; i < n; i++) { cum += p[i]; peak = Math.max(peak, cum); dd = Math.min(dd, cum - peak); run += p[i]; if (i >= 20) run -= p[i - 20]; if (i >= 19) w20 = Math.min(w20, run); }
    var b = Array.prototype.slice.call(bench, o.from), mb = 0; for (i = 0; i < n; i++) mb += b[i]; mb /= n;
    var sxy = 0, sxx = 0; for (i = 0; i < n; i++) { sxy += (b[i] - mb) * (p[i] - mu); sxx += (b[i] - mb) * (b[i] - mb); }
    var beta = sxx > 0 ? sxy / sxx : 0, resid = p.map(function (x, k) { return x - beta * b[k]; });
    var byYear = {}; for (i = 0; i < n; i++) { var y = md.dates[i + o.from].slice(0, 4); byYear[y] = (byYear[y] || 0) + p[i]; }
    var tot = cum, maxYear = tot > 0 ? Math.max.apply(null, Object.keys(byYear).map(function (y) { return byYear[y] / tot; })) : NaN;
    var trades = bt.trades, wins = trades.filter(function (t) { return t.pnl > 0; }).length;
    var tail = mu > 0 ? -w20 / (mu * 21) : Infinity, t2x = tot + bt.comp.cost;
    var s = { total: tot, sharpe: sharpe, nwt: nw(p), dd: dd, w20: w20, beta: beta, alphaT: nw(resid), maxYear: maxYear, t2x: t2x, n: trades.length, hit: trades.length ? wins / trades.length : NaN, tail: tail };
    s.g = [null, s.nwt > 2, s.alphaT > 2, t2x > 0 && maxYear <= 0.6, tail < 6];
    s.passed = s.g.filter(Boolean).length;
    return s;
  }
  function invN(p) { // Acklam
    var a = [-39.69683028665376, 220.9460984245205, -275.9285104469687, 138.357751867269, -30.66479806614716, 2.506628277459239], b = [-54.47609879822406, 161.5858368580409, -155.6989798598866, 66.80131188771972, -13.28068155288572], c = [-0.007784894002430293, -0.3223964580411365, -2.400758277161838, -2.549732539343734, 4.374664141464968, 2.938163982698783], d = [0.007784695709041462, 0.3224671290700398, 2.445134137142996, 3.754408661907416];
    var q, r;
    if (p < 0.02425) { q = Math.sqrt(-2 * Math.log(p)); return (((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1); }
    if (p > 1 - 0.02425) { q = Math.sqrt(-2 * Math.log(1 - p)); return -(((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1); }
    q = p - 0.5; r = q * q; return (((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r + a[4]) * r + a[5]) * q / (((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r + b[4]) * r + 1);
  }
  function luckSharpe(N, T) { // expected best annualised Sharpe from N skill-less trials of T days
    if (N < 2) return 0; var g = 0.5772156649, sd = 1 / Math.sqrt(T);
    return sd * ((1 - g) * invN(1 - 1 / N) + g * invN(1 - 1 / (N * Math.E))) * Math.sqrt(252);
  }
  function dsr(sharpeAnn, T, N) { var sr = sharpeAnn / Math.sqrt(252), sr0 = luckSharpe(N, T) / Math.sqrt(252); return cdf((sr - sr0) * Math.sqrt(T - 1)); }

  W.RVF = { EXPN: EXPN, ET: ET, TAILS: TAILS, NE: NE, NT: NT, CCYS: CCYS, CB: CB, FAM: FAM, IX: IX, nodeName: nodeName, fmt: fmt,
    generate: generate, fromCSV: fromCSV, candidates: candidates, backtest: backtest, benchmark: benchmark, stats: stats,
    unitForward: unitForward, spearman: spearman, luckSharpe: luckSharpe, dsr: dsr, realised: realised, forecast: forecast,
    roll: roll, cdf: cdf, pdf: pdf, interp: interp, dFixed: dFixed, rollCorr: rollCorr, series: series, rollBeta: rollBeta, scoreFrom: scoreFrom, nodeAt: nodeAt, col: col, strad: strad, LEVELS: LEVELS, loadings: loadings, rng: rng, halfBO: halfBO,
    lastScore: function () { return LAST; } };
})(window);
